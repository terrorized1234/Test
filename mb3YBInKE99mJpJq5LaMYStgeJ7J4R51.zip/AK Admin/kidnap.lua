local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
local Player = Players.LocalPlayer
local Character, Humanoid, RootPart
local Camera = workspace.CurrentCamera

local IsMathing = false
local MathConnection = nil
local OriginalCameraSubject = nil
local SittingCheckConnection = nil
local CurrentTarget = nil

local SittingState = {clickPosition = nil}

local OrbitState = {
    angle = 0,
    spinAngle = 0,
    orbitRadius = 5,
    orbitSpeed = 0.3,
    spinSpeed = 0.8
}

workspace.FallenPartsDestroyHeight = math.huge * -1

local INITIAL_POSITION = CFrame.new(668, 21, 95)
local TELEPORT_POSITION = CFrame.new(628, 8152, 3489)

local Config = {
    FLING = {
        STRENGTH = 500000,
        MOVEMENT_DELTA = 0.1
    }
}
local State = {
    isAlive = true,
    isResetting = false,
    flingEnabled = false,
    character = nil,
    root = nil,
    humanoid = nil,
    velocity = nil,
    sitDetectionEnabled = true,
    teleportEnabled = false
}

local ScreenGui, MainFrame, ScrollFrame, StatusLabel, StopButton, CloseButton, MinimizeButton, SearchBox, DeathTrapButton, SitToggleButton, TeleportToggleButton, UIListLayout
local isMinimized = false
local isClosed = false
local allPlayers = {}
local deathTrapConnection = nil
local lastSearchText = ""

-- Store original dimensions
local ORIGINAL_SIZE = UDim2.new(0, 250, 0, 320)
local MINIMIZED_SIZE = UDim2.new(0, 250, 0, 28)

local function setupCharacter()
    State.character = Player.Character
    if State.character then
        State.root = State.character:FindFirstChild("HumanoidRootPart")
        State.humanoid = State.character:FindFirstChild("Humanoid")
        
        if State.humanoid then
            State.humanoid.Died:Connect(function()
                State.isAlive = false
            end)
        end
    end
end

local function handleFling()
    if not State.flingEnabled or State.isResetting or not State.isAlive then 
        return 
    end
    
    if not (State.character and State.character.Parent and State.root and State.root.Parent) then 
        return 
    end
    
    if not State.humanoid or State.humanoid.Health <= 0 then
        State.isAlive = false
        return
    end
    
    State.velocity = State.root.Velocity
    State.root.Velocity = State.velocity * Config.FLING.STRENGTH + Vector3.new(0, Config.FLING.STRENGTH, 0)
    RunService.RenderStepped:Wait()
    
    if State.character and State.character.Parent and State.root and State.root.Parent then
        State.root.Velocity = State.velocity
    end
    
    RunService.Stepped:Wait()
    
    if State.character and State.character.Parent and State.root and State.root.Parent then
        State.root.Velocity = State.velocity + Vector3.new(0, Config.FLING.MOVEMENT_DELTA, 0)
        Config.FLING.MOVEMENT_DELTA = Config.FLING.MOVEMENT_DELTA * -1
    end
end

local function toggleDeathTrap()
    State.flingEnabled = not State.flingEnabled
    if State.flingEnabled then
        DeathTrapButton.BackgroundColor3 = Color3.fromRGB(220, 53, 69)
        StatusLabel.Text = "💀 Death Trap: ON"
        StatusLabel.TextColor3 = Color3.fromRGB(220, 53, 69)
    else
        DeathTrapButton.BackgroundColor3 = Color3.fromRGB(138, 43, 226)
        StatusLabel.Text = "💀 Death Trap: OFF"
        StatusLabel.TextColor3 = Color3.fromRGB(138, 43, 226)
    end
end

local function toggleSitDetection()
    State.sitDetectionEnabled = not State.sitDetectionEnabled
    if State.sitDetectionEnabled then
        SitToggleButton.BackgroundColor3 = Color3.fromRGB(40, 167, 69)
        StatusLabel.Text = "🪑 Sit Detection: ON"
        StatusLabel.TextColor3 = Color3.fromRGB(40, 167, 69)
    else
        SitToggleButton.BackgroundColor3 = Color3.fromRGB(108, 117, 125)
        StatusLabel.Text = "🪑 Sit Detection: OFF"
        StatusLabel.TextColor3 = Color3.fromRGB(108, 117, 125)
    end
end

local function toggleTeleport()
    State.teleportEnabled = not State.teleportEnabled
    if State.teleportEnabled then
        TeleportToggleButton.BackgroundColor3 = Color3.fromRGB(40, 167, 69)
        StatusLabel.Text = "🌌 Heaven Kidnap: ON"
        StatusLabel.TextColor3 = Color3.fromRGB(40, 167, 69)
        Character = Player.Character
        if Character and Character:FindFirstChild("HumanoidRootPart") then
            Character.HumanoidRootPart.CFrame = TELEPORT_POSITION
            task.wait(0.2)
            if Character:FindFirstChild("Humanoid") then
                Character.Humanoid.Jump = true
            end
        end
    else
        TeleportToggleButton.BackgroundColor3 = Color3.fromRGB(108, 117, 125)
        StatusLabel.Text = "🌌 Heaven Kidnap: OFF"
        StatusLabel.TextColor3 = Color3.fromRGB(108, 117, 125)
        Character = Player.Character
        if Character and Character:FindFirstChild("HumanoidRootPart") then
            if SittingState.clickPosition then
                Character.HumanoidRootPart.CFrame = SittingState.clickPosition
            else
                Character.HumanoidRootPart.CFrame = INITIAL_POSITION
            end
            task.wait(0.2)
            if Character:FindFirstChild("Humanoid") then
                Character.Humanoid.Jump = true
            end
        end
    end
end

local function CheckIfSitting()
    if Player.Character and Player.Character:FindFirstChild("Humanoid") then
        return Player.Character.Humanoid.Sit
    end
    return false
end

local function CheckTargetSitting(targetPlayer)
    if not targetPlayer or not targetPlayer.Parent or not targetPlayer.Character or not targetPlayer.Character:FindFirstChild("Humanoid") then
        return false
    end
    return targetPlayer.Character.Humanoid.Sit
end

local function StartSpectating(targetPlayer)
    if targetPlayer and targetPlayer.Character and targetPlayer.Character:FindFirstChild("Humanoid") then
        OriginalCameraSubject = Camera.CameraSubject
        Camera.CameraSubject = targetPlayer.Character.Humanoid
    end
end

local function StopSpectating()
    if OriginalCameraSubject then
        Camera.CameraSubject = OriginalCameraSubject
        OriginalCameraSubject = nil
    elseif Player.Character and Player.Character:FindFirstChild("Humanoid") then
        Camera.CameraSubject = Player.Character.Humanoid
    end
end

local function OnSuccessfulFling()
    StatusLabel.Text = "Kidnap successful! Returning..."
    StatusLabel.TextColor3 = Color3.fromRGB(100, 255, 100)
    task.wait(1)
    Character = Player.Character
    if Character and Character:FindFirstChild("HumanoidRootPart") then
        if State.teleportEnabled then
            Character.HumanoidRootPart.CFrame = TELEPORT_POSITION
        elseif SittingState.clickPosition then
            Character.HumanoidRootPart.CFrame = SittingState.clickPosition
        else
            Character.HumanoidRootPart.CFrame = INITIAL_POSITION
        end
        task.wait(0.2)
        if Character:FindFirstChild("Humanoid") then
            Character.Humanoid.Jump = true
        end
    end
    StopMathing()
end

local function WaitForSitting()
    StatusLabel.Text = "Waiting for you to sit..."
    StatusLabel.TextColor3 = Color3.fromRGB(255, 255, 100)
    while not CheckIfSitting() do
        task.wait(0.1)
    end
    return true
end

local function PerformFling(targetPlayer)
    if not targetPlayer or not targetPlayer.Parent or not targetPlayer.Character or not targetPlayer.Character:FindFirstChild("HumanoidRootPart") then
        return false
    end
    
    Character = Player.Character
    if not Character or not Character:FindFirstChild("HumanoidRootPart") then
        return false
    end
    
    local targetRoot = targetPlayer.Character.HumanoidRootPart
    
    OrbitState.angle = OrbitState.angle + OrbitState.orbitSpeed
    OrbitState.spinAngle = OrbitState.spinAngle + OrbitState.spinSpeed
    
    local orbitX = math.cos(OrbitState.angle) * OrbitState.orbitRadius
    local orbitZ = math.sin(OrbitState.angle) * OrbitState.orbitRadius
    
    local orbitPosition = targetRoot.Position + Vector3.new(orbitX, 1, orbitZ)
    
    local lookDirection = (targetRoot.Position - orbitPosition).Unit
    local baseCFrame = CFrame.lookAt(orbitPosition, targetRoot.Position)
    local spinCFrame = CFrame.Angles(0, OrbitState.spinAngle, 0)
    local newCFrame = baseCFrame * spinCFrame
    
    Character.HumanoidRootPart.CFrame = newCFrame
    return true
end

local function StartMathing(targetPlayer)
    if IsMathing or not targetPlayer or not targetPlayer.Parent then return end
    
    CurrentTarget = targetPlayer
    Character = Player.Character
    if Character and Character:FindFirstChild("HumanoidRootPart") then
        Character.HumanoidRootPart.CFrame = INITIAL_POSITION
    end
    task.wait(0.5)
    if not WaitForSitting() then
        StatusLabel.Text = "Failed to detect sitting!"
        StatusLabel.TextColor3 = Color3.fromRGB(255, 100, 100)
        return
    end
    IsMathing = true
    StopButton.Visible = true
    StatusLabel.Text = "Kidnap: " .. targetPlayer.DisplayName
    StatusLabel.TextColor3 = Color3.fromRGB(255, 100, 100)
    StartSpectating(targetPlayer)
    
    if State.sitDetectionEnabled then
        SittingCheckConnection = RunService.Stepped:Connect(function()
            if not IsMathing or not CurrentTarget then return end
            if CheckTargetSitting(CurrentTarget) then
                OnSuccessfulFling()
            end
        end)
    end
    
    MathConnection = RunService.Heartbeat:Connect(function()
        if not IsMathing or not CurrentTarget then return end
        PerformFling(CurrentTarget)
    end)
end

function StopMathing()
    if MathConnection then
        MathConnection:Disconnect()
        MathConnection = nil
    end
    if SittingCheckConnection then
        SittingCheckConnection:Disconnect()
        SittingCheckConnection = nil
    end
    IsMathing = false
    CurrentTarget = nil
    StopButton.Visible = false
    StatusLabel.Text = "Status: Ready"
    StatusLabel.TextColor3 = Color3.fromRGB(180, 180, 180)
    Character = Player.Character
    if Character and Character:FindFirstChild("HumanoidRootPart") then
        if State.teleportEnabled then
            Character.HumanoidRootPart.CFrame = TELEPORT_POSITION
        elseif SittingState.clickPosition then
            Character.HumanoidRootPart.CFrame = SittingState.clickPosition
        else
            Character.HumanoidRootPart.CFrame = INITIAL_POSITION
        end
        task.wait(0.2)
        if Character:FindFirstChild("Humanoid") then
            Character.Humanoid.Jump = true
        end
    end
    SittingState.clickPosition = nil
    StopSpectating()
end

local function FilterPlayers(searchText)
    local filtered = {}
    for _, player in pairs(allPlayers) do
        if player ~= Player then
            local displayName = player.DisplayName:lower()
            local userName = player.Name:lower()
            local search = searchText:lower()
            if displayName:find(search, 1, true) or userName:find(search, 1, true) then
                table.insert(filtered, player)
            end
        end
    end
    return filtered
end

local function UpdatePlayerList(playersToShow)
    for _, child in pairs(ScrollFrame:GetChildren()) do
        if child:IsA("Frame") and child.Name ~= "UIListLayout" then
            child:Destroy()
        end
    end
    
    local players = playersToShow or allPlayers
    for _, targetPlayer in pairs(players) do
        if targetPlayer ~= Player then
            local PlayerFrame = Instance.new("Frame")
            local PlayerCorner = Instance.new("UICorner")
            local PlayerButton = Instance.new("TextButton")
            local AvatarImage = Instance.new("ImageLabel")
            local AvatarCorner = Instance.new("UICorner")
            local DisplayNameLabel = Instance.new("TextLabel")
            local UsernameLabel = Instance.new("TextLabel")
            
            PlayerFrame.Parent = ScrollFrame
            PlayerFrame.Name = targetPlayer.Name .. "Frame"
            PlayerFrame.Size = UDim2.new(1, -8, 0, 36)
            PlayerFrame.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
            PlayerFrame.BackgroundTransparency = 0.6
            PlayerFrame.BorderSizePixel = 0
            
            PlayerCorner.CornerRadius = UDim.new(0, 8)
            PlayerCorner.Parent = PlayerFrame
            
            PlayerButton.Parent = PlayerFrame
            PlayerButton.Name = targetPlayer.Name
            PlayerButton.Size = UDim2.new(1, 0, 1, 0)
            PlayerButton.BackgroundTransparency = 1
            PlayerButton.Text = ""
            
            AvatarImage.Parent = PlayerFrame
            AvatarImage.Size = UDim2.new(0, 24, 0, 24)
            AvatarImage.Position = UDim2.new(0, 6, 0.5, -12)
            AvatarImage.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
            AvatarImage.BackgroundTransparency = 0.7
            AvatarImage.BorderSizePixel = 0
            AvatarImage.Image = "https://www.roblox.com/headshot-thumbnail/image?userId=" .. targetPlayer.UserId .. "&width=150&height=150&format=png"
            
            AvatarCorner.CornerRadius = UDim.new(0, 12)
            AvatarCorner.Parent = AvatarImage
            
            DisplayNameLabel.Parent = PlayerFrame
            DisplayNameLabel.Size = UDim2.new(1, -38, 0, 12)
            DisplayNameLabel.Position = UDim2.new(0, 34, 0, 4)
            DisplayNameLabel.BackgroundTransparency = 1
            DisplayNameLabel.Text = targetPlayer.DisplayName
            DisplayNameLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
            DisplayNameLabel.Font = Enum.Font.GothamBold
            DisplayNameLabel.TextSize = 11
            DisplayNameLabel.TextXAlignment = Enum.TextXAlignment.Left
            DisplayNameLabel.TextTruncate = Enum.TextTruncate.AtEnd
            
            UsernameLabel.Parent = PlayerFrame
            UsernameLabel.Size = UDim2.new(1, -38, 0, 10)
            UsernameLabel.Position = UDim2.new(0, 34, 0, 18)
            UsernameLabel.BackgroundTransparency = 1
            UsernameLabel.Text = "@" .. targetPlayer.Name
            UsernameLabel.TextColor3 = Color3.fromRGB(150, 150, 150)
            UsernameLabel.Font = Enum.Font.Gotham
            UsernameLabel.TextSize = 9
            UsernameLabel.TextXAlignment = Enum.TextXAlignment.Left
            UsernameLabel.TextTruncate = Enum.TextTruncate.AtEnd
            
            PlayerButton.MouseEnter:Connect(function()
                PlayerFrame.BackgroundTransparency = 0.4
            end)
            
            PlayerButton.MouseLeave:Connect(function()
                PlayerFrame.BackgroundTransparency = 0.6
            end)
            
            PlayerButton.MouseButton1Click:Connect(function()
                if not IsMathing then
                    StartMathing(targetPlayer)
                end
            end)
        end
    end
    ScrollFrame.CanvasSize = UDim2.new(0, 0, 0, UIListLayout.AbsoluteContentSize.Y + 15)
end

local function CreateGUI()
    if ScreenGui then return end
    
    ScreenGui = Instance.new("ScreenGui")
    MainFrame = Instance.new("Frame")
    local MainCorner = Instance.new("UICorner")
    local TitleLabel = Instance.new("TextLabel")
    ScrollFrame = Instance.new("ScrollingFrame")
    local ScrollCorner = Instance.new("UICorner")
    UIListLayout = Instance.new("UIListLayout")
    CloseButton = Instance.new("TextButton")
    MinimizeButton = Instance.new("TextButton")
    StopButton = Instance.new("TextButton")
    local StopCorner = Instance.new("UICorner")
    DeathTrapButton = Instance.new("TextButton")
    local DeathTrapCorner = Instance.new("UICorner")
    SitToggleButton = Instance.new("TextButton")
    local SitToggleCorner = Instance.new("UICorner")
    TeleportToggleButton = Instance.new("TextButton")
    local TeleportToggleCorner = Instance.new("UICorner")
    StatusLabel = Instance.new("TextLabel")
    SearchBox = Instance.new("TextBox")
    local SearchCorner = Instance.new("UICorner")

    ScreenGui.Parent = game:GetService("CoreGui")
    ScreenGui.Name = "KidnapGui"
    ScreenGui.ResetOnSpawn = false
    
    MainFrame.Parent = ScreenGui
    MainFrame.Size = ORIGINAL_SIZE
    MainFrame.Position = UDim2.new(0.5, -125, 0.5, -160)
    MainFrame.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
    MainFrame.BackgroundTransparency = 0.5
    MainFrame.BorderSizePixel = 0

    MainCorner.CornerRadius = UDim.new(0, 12)
    MainCorner.Parent = MainFrame

    TitleLabel.Parent = MainFrame
    TitleLabel.Size = UDim2.new(1, -40, 0, 25)
    TitleLabel.Position = UDim2.new(0, 20, 0, 3)
    TitleLabel.BackgroundTransparency = 1
    TitleLabel.Text = "Kidnap"
    TitleLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
    TitleLabel.Font = Enum.Font.GothamBold
    TitleLabel.TextSize = 14
    TitleLabel.TextXAlignment = Enum.TextXAlignment.Center

    MinimizeButton.Parent = MainFrame
    MinimizeButton.Size = UDim2.new(0, 16, 0, 16)
    MinimizeButton.Position = UDim2.new(1, -36, 0, 6)
    MinimizeButton.BackgroundTransparency = 1
    MinimizeButton.BorderSizePixel = 0
    MinimizeButton.Text = "−"
    MinimizeButton.TextColor3 = Color3.fromRGB(255, 193, 7)
    MinimizeButton.Font = Enum.Font.GothamBold
    MinimizeButton.TextSize = 14

    CloseButton.Parent = MainFrame
    CloseButton.Size = UDim2.new(0, 16, 0, 16)
    CloseButton.Position = UDim2.new(1, -18, 0, 6)
    CloseButton.BackgroundTransparency = 1
    CloseButton.BorderSizePixel = 0
    CloseButton.Text = "×"
    CloseButton.TextColor3 = Color3.fromRGB(220, 53, 69)
    CloseButton.Font = Enum.Font.GothamBold
    CloseButton.TextSize = 14

    SearchBox.Parent = MainFrame
    SearchBox.Size = UDim2.new(1, -16, 0, 22)
    SearchBox.Position = UDim2.new(0, 8, 0, 32)
    SearchBox.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
    SearchBox.BackgroundTransparency = 0.6
    SearchBox.BorderSizePixel = 0
    SearchBox.Text = "Search players..."
    SearchBox.TextColor3 = Color3.fromRGB(255, 255, 255)
    SearchBox.Font = Enum.Font.Gotham
    SearchBox.TextSize = 11
    SearchBox.PlaceholderText = "Search players..."
    SearchBox.PlaceholderColor3 = Color3.fromRGB(150, 150, 150)

    SearchCorner.CornerRadius = UDim.new(0, 6)
    SearchCorner.Parent = SearchBox

    StopButton.Parent = MainFrame
    StopButton.Size = UDim2.new(1, -16, 0, 22)
    StopButton.Position = UDim2.new(0, 8, 0, 62)
    StopButton.BackgroundColor3 = Color3.fromRGB(220, 53, 69)
    StopButton.BackgroundTransparency = 0.2
    StopButton.BorderSizePixel = 0
    StopButton.Text = "STOP KIDNAP"
    StopButton.TextColor3 = Color3.fromRGB(255, 255, 255)
    StopButton.Font = Enum.Font.GothamBold
    StopButton.TextSize = 11
    StopButton.Visible = false

    StopCorner.CornerRadius = UDim.new(0, 6)
    StopCorner.Parent = StopButton

    -- Fixed button positioning to be perfectly centered
    local buttonWidth = 48
    local buttonHeight = 22
    local totalButtonsWidth = buttonWidth * 3 + 16 * 2  -- 3 buttons + 2 gaps of 16 pixels each
    local startX = (250 - totalButtonsWidth) / 2  -- Center the buttons within the 250px wide frame

    DeathTrapButton.Parent = MainFrame
    DeathTrapButton.Size = UDim2.new(0, buttonWidth, 0, buttonHeight)
    DeathTrapButton.Position = UDim2.new(0, startX, 0, 92)
    DeathTrapButton.BackgroundColor3 = Color3.fromRGB(138, 43, 226)
    DeathTrapButton.BackgroundTransparency = 0.2
    DeathTrapButton.BorderSizePixel = 0
    DeathTrapButton.Text = "💀"
    DeathTrapButton.TextColor3 = Color3.fromRGB(255, 255, 255)
    DeathTrapButton.Font = Enum.Font.GothamBold
    DeathTrapButton.TextSize = 12

    DeathTrapCorner.CornerRadius = UDim.new(0, 6)
    DeathTrapCorner.Parent = DeathTrapButton

    SitToggleButton.Parent = MainFrame
    SitToggleButton.Size = UDim2.new(0, buttonWidth, 0, buttonHeight)
    SitToggleButton.Position = UDim2.new(0, startX + buttonWidth + 16, 0, 92)
    SitToggleButton.BackgroundColor3 = Color3.fromRGB(40, 167, 69)
    SitToggleButton.BackgroundTransparency = 0.2
    SitToggleButton.BorderSizePixel = 0
    SitToggleButton.Text = "🪑"
    SitToggleButton.TextColor3 = Color3.fromRGB(255, 255, 255)
    SitToggleButton.Font = Enum.Font.GothamBold
    SitToggleButton.TextSize = 12

    SitToggleCorner.CornerRadius = UDim.new(0, 6)
    SitToggleCorner.Parent = SitToggleButton

    TeleportToggleButton.Parent = MainFrame
    TeleportToggleButton.Size = UDim2.new(0, buttonWidth, 0, buttonHeight)
    TeleportToggleButton.Position = UDim2.new(0, startX + buttonWidth * 2 + 16 * 2, 0, 92)
    TeleportToggleButton.BackgroundColor3 = Color3.fromRGB(108, 117, 125)
    TeleportToggleButton.BackgroundTransparency = 0.2
    TeleportToggleButton.BorderSizePixel = 0
    TeleportToggleButton.Text = "🌌"
    TeleportToggleButton.TextColor3 = Color3.fromRGB(255, 255, 255)
    TeleportToggleButton.Font = Enum.Font.GothamBold
    TeleportToggleButton.TextSize = 12

    TeleportToggleCorner.CornerRadius = UDim.new(0, 6)
    TeleportToggleCorner.Parent = TeleportToggleButton

    StatusLabel.Parent = MainFrame
    StatusLabel.Size = UDim2.new(1, -16, 0, 18)
    StatusLabel.Position = UDim2.new(0, 8, 0, 122)
    StatusLabel.BackgroundTransparency = 1
    StatusLabel.Text = "Status: Ready"
    StatusLabel.TextColor3 = Color3.fromRGB(180, 180, 180)
    StatusLabel.Font = Enum.Font.Gotham
    StatusLabel.TextSize = 10
    StatusLabel.TextXAlignment = Enum.TextXAlignment.Left

    ScrollFrame.Parent = MainFrame
    ScrollFrame.Size = UDim2.new(1, -16, 1, -150)
    ScrollFrame.Position = UDim2.new(0, 8, 0, 142)
    ScrollFrame.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
    ScrollFrame.BackgroundTransparency = 0.7
    ScrollFrame.BorderSizePixel = 0
    ScrollFrame.ScrollBarThickness = 3
    ScrollFrame.ScrollBarImageColor3 = Color3.fromRGB(100, 100, 100)

    ScrollCorner.CornerRadius = UDim.new(0, 8)
    ScrollCorner.Parent = ScrollFrame

    UIListLayout.Parent = ScrollFrame
    UIListLayout.SortOrder = Enum.SortOrder.Name
    UIListLayout.Padding = UDim.new(0, 5)

    local dragging = false
    local dragStart = nil
    local startPos = nil

    local function updateInput(input)
        local delta = input.Position - dragStart
        MainFrame.Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + delta.X, startPos.Y.Scale, startPos.Y.Offset + delta.Y)
    end

    MainFrame.InputBegan:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
            dragging = true
            dragStart = input.Position
            startPos = MainFrame.Position
            input.Changed:Connect(function()
                if input.UserInputState == Enum.UserInputState.End then
                    dragging = false
                end
            end)
        end
    end)

    MainFrame.InputChanged:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch then
            if dragging then
                updateInput(input)
            end
        end
    end)

    CloseButton.MouseButton1Click:Connect(function()
        MainFrame.Visible = false
        isClosed = true
    end)

    MinimizeButton.MouseButton1Click:Connect(function()
        if isMinimized then
            -- Restore to original size
            MainFrame.Size = ORIGINAL_SIZE
            ScrollFrame.Visible = true
            StatusLabel.Visible = true
            StopButton.Visible = IsMathing
            SearchBox.Visible = true
            DeathTrapButton.Visible = true
            SitToggleButton.Visible = true
            TeleportToggleButton.Visible = true
            MinimizeButton.Text = "−"  -- Em dash character
            isMinimized = false
        else
            -- Minimize to header only
            MainFrame.Size = MINIMIZED_SIZE
            ScrollFrame.Visible = false
            StatusLabel.Visible = false
            StopButton.Visible = false
            SearchBox.Visible = false
            DeathTrapButton.Visible = false
            SitToggleButton.Visible = false
            TeleportToggleButton.Visible = false
            MinimizeButton.Text = "+"
            isMinimized = true
        end
    end)

    StopButton.MouseButton1Click:Connect(function()
        StopMathing()
    end)

    DeathTrapButton.MouseButton1Click:Connect(function()
        toggleDeathTrap()
    end)

    SitToggleButton.MouseButton1Click:Connect(function()
        toggleSitDetection()
    end)

    TeleportToggleButton.MouseButton1Click:Connect(function()
        toggleTeleport()
    end)

    SearchBox.FocusLost:Connect(function()
        lastSearchText = SearchBox.Text
        if SearchBox.Text == "" or SearchBox.Text == "Search players..." then
            UpdatePlayerList()
        else
            local filtered = FilterPlayers(SearchBox.Text)
            UpdatePlayerList(filtered)
        end
    end)

    SearchBox:GetPropertyChangedSignal("Text"):Connect(function()
        lastSearchText = SearchBox.Text
        if SearchBox.Text == "" or SearchBox.Text == "Search players..." then
            UpdatePlayerList()
        else
            local filtered = FilterPlayers(SearchBox.Text)
            UpdatePlayerList(filtered)
        end
    end)

    allPlayers = Players:GetPlayers()
    UpdatePlayerList()
end

if not ScreenGui then
    setupCharacter()
    CreateGUI()
end

Player.CharacterAdded:Connect(function(newCharacter)
    State.isResetting = true
    task.wait(0.2)
    
    if newCharacter == Player.Character then
        setupCharacter()
        State.isAlive = true
        SittingState.clickPosition = nil
        if ScreenGui and MainFrame and not isClosed then
            MainFrame.Visible = true
        end
        allPlayers = Players:GetPlayers()
        if lastSearchText == "" or lastSearchText == "Search players..." then
            UpdatePlayerList()
        else
            local filtered = FilterPlayers(lastSearchText)
            UpdatePlayerList(filtered)
        end
    end
    
    State.isResetting = false
end)

RunService.Heartbeat:Connect(handleFling)

Players.PlayerAdded:Connect(function()
    allPlayers = Players:GetPlayers()
    if lastSearchText == "" or lastSearchText == "Search players..." then
        UpdatePlayerList()
    else
        local filtered = FilterPlayers(lastSearchText)
        UpdatePlayerList(filtered)
    end
end)

Players.PlayerRemoving:Connect(function()
    allPlayers = Players:GetPlayers()
    if lastSearchText == "" or lastSearchText == "Search players..." then
        UpdatePlayerList()
    else
        local filtered = FilterPlayers(lastSearchText)
        UpdatePlayerList(filtered)
    end
end)
