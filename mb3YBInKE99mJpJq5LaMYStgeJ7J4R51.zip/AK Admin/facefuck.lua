local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
local TweenService = game:GetService("TweenService")

local LocalPlayer = Players.LocalPlayer
local PlayerGui = LocalPlayer:WaitForChild("PlayerGui")
local Character = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()
local HumanoidRootPart = Character:WaitForChild("HumanoidRootPart")
local targetHead = nil
local targetPlayer = nil

local FOLLOW_DISTANCE = -0.7
local HEIGHT_OFFSET = 0.8
local MOVEMENT_SPEED = 0.8
local THRUST_SPEED = 0.8
local THRUST_DISTANCE = 1.9

local THRUST_FORWARD_TIME = 0.1
local THRUST_BACKWARD_TIME = 0.1

getgenv().facefuckactive = false

local function disableAllAnimations(character)
    if not character then return end
    
    local animate = character:FindFirstChild("Animate")
    if animate then
        animate.Disabled = true
    end
    
    local humanoid = character:FindFirstChild("Humanoid")
    if humanoid then
        for _, track in ipairs(humanoid:GetPlayingAnimationTracks()) do
            track:Stop()
            track:Destroy()
        end
        humanoid.PlatformStand = true
        humanoid.AutoRotate = false
        humanoid:ChangeState(Enum.HumanoidStateType.Physics)
    end
    
    workspace.Gravity = 0
end

local function enableAllAnimations(character)
    if not character then return end
    
    local animate = character:FindFirstChild("Animate")
    if animate then
        animate.Disabled = false
    end
    
    local humanoid = character:FindFirstChild("Humanoid")
    if humanoid then
        humanoid.PlatformStand = false
        humanoid.AutoRotate = true
        humanoid:ChangeState(Enum.HumanoidStateType.GettingUp)
    end
    
    workspace.Gravity = 192.2
end

local function setupCharacterTracking()
    LocalPlayer.CharacterAdded:Connect(function(newCharacter)
        Character = newCharacter
        HumanoidRootPart = newCharacter:WaitForChild("HumanoidRootPart")
        
        if getgenv().facefuckactive then
            disableAllAnimations(newCharacter)
            targetHead = findNearestPlayer()
            if targetHead then
                task.spawn(function()
                    faceBang(targetHead)
                end)
            end
        end
    end)
end

local function findNearestPlayer()
    if targetPlayer and targetPlayer.Character and targetPlayer.Character:FindFirstChild("Head") then
        return targetPlayer.Character.Head
    end

    local nearestPlayer = nil
    local shortestDistance = math.huge

    for _, player in ipairs(Players:GetPlayers()) do
        if player ~= LocalPlayer and player.Character and player.Character:FindFirstChild("Humanoid") and player.Character.Humanoid.Health > 0 then
            local head = player.Character:FindFirstChild("Head")
            if head then
                local distance = (HumanoidRootPart.Position - head.Position).Magnitude
                if distance < shortestDistance then
                    shortestDistance = distance
                    nearestPlayer = head
                    targetPlayer = player
                end
            end
        end
    end

    if targetPlayer then
        targetPlayer.CharacterAdded:Connect(function(newCharacter)
            if getgenv().facefuckactive then
                local head = newCharacter:WaitForChild("Head")
                targetHead = head
                faceBang(head)
            end
        end)
    end

    return nearestPlayer
end

local function setupAnimationPrevention()
    RunService.Heartbeat:Connect(function()
        if getgenv().facefuckactive and LocalPlayer.Character then
            local humanoid = LocalPlayer.Character:FindFirstChild("Humanoid")
            if humanoid then
                for _, track in ipairs(humanoid:GetPlayingAnimationTracks()) do
                    track:Stop()
                end
                humanoid.PlatformStand = true
                humanoid:ChangeState(Enum.HumanoidStateType.Physics)
            end
        end
    end)
end

local function easeInOutSine(t)
    return -(math.cos(math.pi * t) - 1) / 2
end

local function smoothLerp(start, target, alpha, easingFunc)
    local easedAlpha = easingFunc(alpha)
    return start:Lerp(target, easedAlpha)
end

local function faceBang(head)
    while getgenv().facefuckactive do
        if not head or not head:IsDescendantOf(workspace) then
            if targetPlayer and targetPlayer.Character then
                head = targetPlayer.Character:WaitForChild("Head")
                targetHead = head
            else
                head = findNearestPlayer()
                if not head then
                    task.wait(1)
                    continue
                end
            end
        end

        disableAllAnimations(LocalPlayer.Character)

        local distanceToTarget = (head.Position - HumanoidRootPart.Position).Magnitude
        local isTooFar = distanceToTarget > 10
        
        if isTooFar then
            local approachCFrame = head.CFrame * CFrame.new(0, HEIGHT_OFFSET, FOLLOW_DISTANCE + 1) * CFrame.Angles(0, math.rad(180), 0)
            HumanoidRootPart.CFrame = approachCFrame
            RunService.RenderStepped:Wait()
            continue
        end
        
        local basePosition = head.CFrame * CFrame.new(0, HEIGHT_OFFSET, FOLLOW_DISTANCE) * CFrame.Angles(0, math.rad(180), 0)
        local thrustPosition = head.CFrame * CFrame.new(0, HEIGHT_OFFSET, FOLLOW_DISTANCE - THRUST_DISTANCE) * CFrame.Angles(0, math.rad(180), 0)
        
        local thrustStartTime = tick()
        local thrustDuration = THRUST_FORWARD_TIME
        while (tick() - thrustStartTime) < thrustDuration and getgenv().facefuckactive do
            basePosition = head.CFrame * CFrame.new(0, HEIGHT_OFFSET, FOLLOW_DISTANCE) * CFrame.Angles(0, math.rad(180), 0)
            thrustPosition = head.CFrame * CFrame.new(0, HEIGHT_OFFSET, FOLLOW_DISTANCE - THRUST_DISTANCE) * CFrame.Angles(0, math.rad(180), 0)
            
            local progress = math.min((tick() - thrustStartTime) / thrustDuration, 1)
            local currentThrust = smoothLerp(basePosition, thrustPosition, progress, easeInOutSine)
            HumanoidRootPart.CFrame = currentThrust
            
            RunService.RenderStepped:Wait()
        end
        
        local returnStartTime = tick()
        local returnDuration = THRUST_BACKWARD_TIME
        while (tick() - returnStartTime) < returnDuration and getgenv().facefuckactive do
            basePosition = head.CFrame * CFrame.new(0, HEIGHT_OFFSET, FOLLOW_DISTANCE) * CFrame.Angles(0, math.rad(180), 0)
            thrustPosition = head.CFrame * CFrame.new(0, HEIGHT_OFFSET, FOLLOW_DISTANCE - THRUST_DISTANCE) * CFrame.Angles(0, math.rad(180), 0)
            
            local progress = math.min((tick() - returnStartTime) / returnDuration, 1)
            local currentReturn = smoothLerp(thrustPosition, basePosition, progress, easeInOutSine)
            HumanoidRootPart.CFrame = currentReturn
            
            RunService.RenderStepped:Wait()
        end
    end

    enableAllAnimations(LocalPlayer.Character)
end

local function toggleMovement()
    if not getgenv().facefuckactive then
        targetPlayer = nil
        targetHead = findNearestPlayer()
        
        if targetHead then
            getgenv().facefuckactive = true
            disableAllAnimations(LocalPlayer.Character)
            task.spawn(function()
                faceBang(targetHead)
            end)
        end
    else
        getgenv().facefuckactive = false
        targetPlayer = nil
        targetHead = nil
        enableAllAnimations(LocalPlayer.Character)
    end
end

local function createGUI()
    if PlayerGui:FindFirstChild("FaceBangGui") then
        PlayerGui.FaceBangGui:Destroy()
    end

    local screengui = Instance.new("ScreenGui")
    screengui.Name = "FaceBangGui"
    screengui.ResetOnSpawn = false
    screengui.Parent = PlayerGui

    local mainContainer = Instance.new("Frame")
    mainContainer.Name = "MainContainer"
    mainContainer.Size = UDim2.new(0, 120, 0, 50)
    mainContainer.Position = UDim2.new(0.95, -60, 0.05, 25)
    mainContainer.BackgroundTransparency = 1
    mainContainer.Parent = screengui

    local toggleButton = Instance.new("TextButton")
    toggleButton.Name = "ToggleButton"
    toggleButton.Size = UDim2.new(0, 50, 0, 50)
    toggleButton.Position = UDim2.new(0, 0, 0, 0)
    toggleButton.BackgroundColor3 = Color3.fromRGB(45, 45, 65)
    toggleButton.BorderColor3 = Color3.fromRGB(100, 100, 140)
    toggleButton.BorderSizePixel = 2
    toggleButton.TextColor3 = Color3.fromRGB(255, 255, 255)
    toggleButton.Text = "😏"
    toggleButton.TextSize = 24
    toggleButton.Font = Enum.Font.Gotham
    toggleButton.Parent = mainContainer

    local toggleCorner = Instance.new("UICorner")
    toggleCorner.CornerRadius = UDim.new(0, 12)
    toggleCorner.Parent = toggleButton

    local toggleGradient = Instance.new("UIGradient")
    toggleGradient.Color = ColorSequence.new{
        ColorSequenceKeypoint.new(0, Color3.fromRGB(55, 55, 75)),
        ColorSequenceKeypoint.new(1, Color3.fromRGB(35, 35, 55))
    }
    toggleGradient.Rotation = 90
    toggleGradient.Parent = toggleButton

    local settingsButton = Instance.new("TextButton")
    settingsButton.Name = "SettingsButton"
    settingsButton.Size = UDim2.new(0, 50, 0, 50)
    settingsButton.Position = UDim2.new(0, 60, 0, 0)
    settingsButton.BackgroundColor3 = Color3.fromRGB(45, 45, 65)
    settingsButton.BorderColor3 = Color3.fromRGB(100, 100, 140)
    settingsButton.BorderSizePixel = 2
    settingsButton.TextColor3 = Color3.fromRGB(255, 255, 255)
    settingsButton.Text = "⚙️"
    settingsButton.TextSize = 24
    settingsButton.Font = Enum.Font.Gotham
    settingsButton.Parent = mainContainer

    local settingsCorner = Instance.new("UICorner")
    settingsCorner.CornerRadius = UDim.new(0, 12)
    settingsCorner.Parent = settingsButton

    local settingsGradient = Instance.new("UIGradient")
    settingsGradient.Color = ColorSequence.new{
        ColorSequenceKeypoint.new(0, Color3.fromRGB(55, 55, 75)),
        ColorSequenceKeypoint.new(1, Color3.fromRGB(35, 35, 55))
    }
    settingsGradient.Rotation = 90
    settingsGradient.Parent = settingsButton

    local settingsFrame = Instance.new("Frame")
    settingsFrame.Name = "SettingsFrame"
    settingsFrame.Size = UDim2.new(0, 250, 0, 150)
    settingsFrame.Position = UDim2.new(0, -140, 0, 60)
    settingsFrame.BackgroundColor3 = Color3.fromRGB(30, 30, 45)
    settingsFrame.BorderColor3 = Color3.fromRGB(80, 80, 120)
    settingsFrame.BorderSizePixel = 2
    settingsFrame.Visible = false
    settingsFrame.Parent = mainContainer

    local settingsFrameCorner = Instance.new("UICorner")
    settingsFrameCorner.CornerRadius = UDim.new(0, 12)
    settingsFrameCorner.Parent = settingsFrame

    local frameGradient = Instance.new("UIGradient")
    frameGradient.Color = ColorSequence.new{
        ColorSequenceKeypoint.new(0, Color3.fromRGB(40, 40, 55)),
        ColorSequenceKeypoint.new(1, Color3.fromRGB(20, 20, 35))
    }
    frameGradient.Rotation = 135
    frameGradient.Parent = settingsFrame

    local speedLabel = Instance.new("TextLabel")
    speedLabel.Name = "SpeedLabel"
    speedLabel.Size = UDim2.new(0, 100, 0, 30)
    speedLabel.Position = UDim2.new(0, 10, 0, 15)
    speedLabel.BackgroundTransparency = 1
    speedLabel.TextColor3 = Color3.fromRGB(220, 220, 255)
    speedLabel.Text = "Speed: 0.1"
    speedLabel.TextSize = 14
    speedLabel.Font = Enum.Font.GothamBold
    speedLabel.TextXAlignment = Enum.TextXAlignment.Left
    speedLabel.Parent = settingsFrame

    local speedSlider = Instance.new("Frame")
    speedSlider.Name = "SpeedSlider"
    speedSlider.Size = UDim2.new(0, 200, 0, 20)
    speedSlider.Position = UDim2.new(0, 25, 0, 45)
    speedSlider.BackgroundColor3 = Color3.fromRGB(50, 50, 70)
    speedSlider.BorderColor3 = Color3.fromRGB(80, 80, 110)
    speedSlider.BorderSizePixel = 1
    speedSlider.Parent = settingsFrame

    local speedSliderCorner = Instance.new("UICorner")
    speedSliderCorner.CornerRadius = UDim.new(0, 10)
    speedSliderCorner.Parent = speedSlider

    local speedHandle = Instance.new("TextButton")
    speedHandle.Name = "SpeedHandle"
    speedHandle.Size = UDim2.new(0, 16, 0, 16)
    speedHandle.Position = UDim2.new(0, 2, 0, 2)
    speedHandle.BackgroundColor3 = Color3.fromRGB(120, 120, 160)
    speedHandle.BorderColor3 = Color3.fromRGB(160, 160, 200)
    speedHandle.BorderSizePixel = 1
    speedHandle.Text = ""
    speedHandle.Parent = speedSlider

    local speedHandleCorner = Instance.new("UICorner")
    speedHandleCorner.CornerRadius = UDim.new(0, 8)
    speedHandleCorner.Parent = speedHandle

    local distanceLabel = Instance.new("TextLabel")
    distanceLabel.Name = "DistanceLabel"
    distanceLabel.Size = UDim2.new(0, 100, 0, 30)
    distanceLabel.Position = UDim2.new(0, 10, 0, 75)
    distanceLabel.BackgroundTransparency = 1
    distanceLabel.TextColor3 = Color3.fromRGB(220, 220, 255)
    distanceLabel.Text = "Distance: 1.9"
    distanceLabel.TextSize = 14
    distanceLabel.Font = Enum.Font.GothamBold
    distanceLabel.TextXAlignment = Enum.TextXAlignment.Left
    distanceLabel.Parent = settingsFrame

    local distanceSlider = Instance.new("Frame")
    distanceSlider.Name = "DistanceSlider"
    distanceSlider.Size = UDim2.new(0, 200, 0, 20)
    distanceSlider.Position = UDim2.new(0, 25, 0, 105)
    distanceSlider.BackgroundColor3 = Color3.fromRGB(50, 50, 70)
    distanceSlider.BorderColor3 = Color3.fromRGB(80, 80, 110)
    distanceSlider.BorderSizePixel = 1
    distanceSlider.Parent = settingsFrame

    local distanceSliderCorner = Instance.new("UICorner")
    distanceSliderCorner.CornerRadius = UDim.new(0, 10)
    distanceSliderCorner.Parent = distanceSlider

    local distanceHandle = Instance.new("TextButton")
    distanceHandle.Name = "DistanceHandle"
    distanceHandle.Size = UDim2.new(0, 16, 0, 16)
    distanceHandle.Position = UDim2.new(0, 2, 0, 2)
    distanceHandle.BackgroundColor3 = Color3.fromRGB(120, 120, 160)
    distanceHandle.BorderColor3 = Color3.fromRGB(160, 160, 200)
    distanceHandle.BorderSizePixel = 1
    distanceHandle.Text = ""
    distanceHandle.Parent = distanceSlider

    local distanceHandleCorner = Instance.new("UICorner")
    distanceHandleCorner.CornerRadius = UDim.new(0, 8)
    distanceHandleCorner.Parent = distanceHandle

    local function updateSlider(slider, handle, value, minValue, maxValue)
        local percentage = (value - minValue) / (maxValue - minValue)
        local newPosition = math.clamp(percentage * (slider.AbsoluteSize.X - handle.AbsoluteSize.X), 0, slider.AbsoluteSize.X - handle.AbsoluteSize.X)
        handle.Position = UDim2.new(0, newPosition, 0, 2)
    end

    local function setupSlider(slider, handle, minValue, maxValue, initialValue, callback)
        local dragging = false
        
        handle.InputBegan:Connect(function(input)
            if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
                dragging = true
            end
        end)
        
        UserInputService.InputEnded:Connect(function(input)
            if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
                dragging = false
            end
        end)
        
        UserInputService.InputChanged:Connect(function(input)
            if dragging and (input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch) then
                local relativeX = input.Position.X - slider.AbsolutePosition.X
                local percentage = math.clamp(relativeX / slider.AbsoluteSize.X, 0, 1)
                local value = minValue + (maxValue - minValue) * percentage
                
                updateSlider(slider, handle, value, minValue, maxValue)
                callback(value)
            end
        end)
        
        updateSlider(slider, handle, initialValue, minValue, maxValue)
    end

    setupSlider(speedSlider, speedHandle, 0.01, 0.5, THRUST_FORWARD_TIME, function(value)
        THRUST_FORWARD_TIME = value
        THRUST_BACKWARD_TIME = value
        speedLabel.Text = "Speed: " .. string.format("%.2f", value)
    end)

    setupSlider(distanceSlider, distanceHandle, 0.5, 5.0, THRUST_DISTANCE, function(value)
        THRUST_DISTANCE = value
        distanceLabel.Text = "Distance: " .. string.format("%.1f", value)
    end)

    toggleButton.MouseButton1Click:Connect(function()
        toggleMovement()
        if getgenv().facefuckactive then
            toggleButton.BackgroundColor3 = Color3.fromRGB(60, 85, 60)
            toggleGradient.Color = ColorSequence.new{
                ColorSequenceKeypoint.new(0, Color3.fromRGB(70, 95, 70)),
                ColorSequenceKeypoint.new(1, Color3.fromRGB(50, 75, 50))
            }
        else
            toggleButton.BackgroundColor3 = Color3.fromRGB(45, 45, 65)
            toggleGradient.Color = ColorSequence.new{
                ColorSequenceKeypoint.new(0, Color3.fromRGB(55, 55, 75)),
                ColorSequenceKeypoint.new(1, Color3.fromRGB(35, 35, 55))
            }
        end
    end)

    settingsButton.MouseButton1Click:Connect(function()
        settingsFrame.Visible = not settingsFrame.Visible
    end)

    local dragStart
    local startPos
    local dragging = false
    
    mainContainer.InputBegan:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
            dragging = true
            dragStart = input.Position
            startPos = mainContainer.Position
        end
    end)
    
    UserInputService.InputEnded:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
            dragging = false
        end
    end)
    
    UserInputService.InputChanged:Connect(function(input)
        if dragging and (input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch) then
            local delta = input.Position - dragStart
            mainContainer.Position = UDim2.new(
                startPos.X.Scale, 
                startPos.X.Offset + delta.X,
                startPos.Y.Scale,
                startPos.Y.Offset + delta.Y
            )
        end
    end)
end

UserInputService.InputBegan:Connect(function(input, gameProcessed)
    if not gameProcessed and input.KeyCode == Enum.KeyCode.Z then
        toggleMovement()
        
        local gui = PlayerGui:FindFirstChild("FaceBangGui")
        if gui then
            local toggleButton = gui.MainContainer.ToggleButton
            local toggleGradient = toggleButton.UIGradient
            if getgenv().facefuckactive then
                toggleButton.BackgroundColor3 = Color3.fromRGB(60, 85, 60)
                toggleGradient.Color = ColorSequence.new{
                    ColorSequenceKeypoint.new(0, Color3.fromRGB(70, 95, 70)),
                    ColorSequenceKeypoint.new(1, Color3.fromRGB(50, 75, 50))
                }
            else
                toggleButton.BackgroundColor3 = Color3.fromRGB(45, 45, 65)
                toggleGradient.Color = ColorSequence.new{
                    ColorSequenceKeypoint.new(0, Color3.fromRGB(55, 55, 75)),
                    ColorSequenceKeypoint.new(1, Color3.fromRGB(35, 35, 55))
                }
            end
        end
    end
end)

setupCharacterTracking()
setupAnimationPrevention()
createGUI()
