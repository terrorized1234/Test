local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local RunService = game:GetService("RunService")
local SoundService = game:GetService("SoundService")

local FREE_API_URL = "https://leakcheck.io/api/public?check="

local COLOR_NO_LEAKS = Color3.fromRGB(0, 255, 100) 
local COLOR_LEAKS = Color3.fromRGB(255, 50, 50) 
local COLOR_ERROR = Color3.fromRGB(255, 200, 0) 
local COLOR_ACCENT = Color3.fromRGB(0, 200, 255) 
local WINDOW_BG = Color3.fromRGB(20, 20, 20) 
local COLOR_TEXT = Color3.fromRGB(255, 255, 255) 
local COLOR_COPIED = Color3.fromRGB(0, 255, 100) 
local COLOR_HOVER = Color3.fromRGB(135, 206, 250) 

local SCAN_DISTANCE = 20

local EMOJI_GLOBE = "🌐"
local EMOJI_CALENDAR = "📅"
local EMOJI_GREEN = "🟢"
local EMOJI_RED = "🔴"

local LEAK_FOUND_SOUND_ID = "rbxassetid://140419294351439"

local ScreenGui = Instance.new("ScreenGui")
ScreenGui.Name = "WatchDogsScanner"
ScreenGui.ResetOnSpawn = false
ScreenGui.Parent = game:GetService("CoreGui")

local playerScanButtons = {}
local playerResultWindows = {}

local StatusFrame = Instance.new("Frame")
StatusFrame.Size = UDim2.new(0, 220, 0, 110)
StatusFrame.Position = UDim2.new(1, -230, 0, -110) 
StatusFrame.BackgroundColor3 = WINDOW_BG
StatusFrame.BackgroundTransparency = 0.3 
StatusFrame.Parent = ScreenGui

local StatusCorner = Instance.new("UICorner")
StatusCorner.CornerRadius = UDim.new(0, 8)
StatusCorner.Parent = StatusFrame

local StatusEmoji = Instance.new("TextLabel")
StatusEmoji.Size = UDim2.new(0, 20, 0, 20)
StatusEmoji.Position = UDim2.new(0, 10, 0, 10)
StatusEmoji.BackgroundTransparency = 1
StatusEmoji.Text = EMOJI_GREEN
StatusEmoji.TextSize = 16
StatusEmoji.TextTransparency = 1
StatusEmoji.Parent = StatusFrame

local StatusTitle = Instance.new("TextLabel")
StatusTitle.Size = UDim2.new(1, 0, 0, 30)
StatusTitle.Position = UDim2.new(0, 0, 0, 0)
StatusTitle.BackgroundTransparency = 1
StatusTitle.Text = "Leak Scan"
StatusTitle.TextColor3 = COLOR_ACCENT
StatusTitle.TextSize = 20
StatusTitle.Font = Enum.Font.GothamBlack
StatusTitle.TextXAlignment = Enum.TextXAlignment.Center
StatusTitle.TextTransparency = 1
StatusTitle.Parent = StatusFrame

local StatusProviderLabel = Instance.new("TextLabel")
StatusProviderLabel.Size = UDim2.new(1, 0, 0, 20)
StatusProviderLabel.Position = UDim2.new(0, 0, 0, 35)
StatusProviderLabel.BackgroundTransparency = 1
StatusProviderLabel.Text = "Provided by leakcheck.io"
StatusProviderLabel.TextColor3 = COLOR_ACCENT
StatusProviderLabel.TextSize = 16
StatusProviderLabel.Font = Enum.Font.Gotham
StatusProviderLabel.TextXAlignment = Enum.TextXAlignment.Center
StatusProviderLabel.TextTransparency = 1
StatusProviderLabel.Parent = StatusFrame

local StatusButton = Instance.new("TextButton")
StatusButton.Size = UDim2.new(0, 80, 0, 30)
StatusButton.Position = UDim2.new(0.5, -40, 0, 65)
StatusButton.BackgroundColor3 = COLOR_ACCENT
StatusButton.BackgroundTransparency = 0.2
StatusButton.Text = "Stop"
StatusButton.TextColor3 = COLOR_TEXT
StatusButton.TextSize = 16
StatusButton.Font = Enum.Font.GothamBold
StatusButton.TextTransparency = 1
StatusButton.Parent = StatusFrame

local StatusButtonCorner = Instance.new("UICorner")
StatusButtonCorner.CornerRadius = UDim.new(0, 8)
StatusButtonCorner.Parent = StatusButton

local CloseButton = Instance.new("TextButton")
CloseButton.Size = UDim2.new(0, 30, 0, 30)
CloseButton.Position = UDim2.new(1, -40, 0, 5)
CloseButton.BackgroundTransparency = 1
CloseButton.Text = "X"
CloseButton.TextColor3 = COLOR_TEXT
CloseButton.TextSize = 16
CloseButton.Font = Enum.Font.GothamBold
CloseButton.TextTransparency = 1
CloseButton.Parent = StatusFrame

CloseButton.MouseEnter:Connect(function()
    TweenService:Create(CloseButton, TweenInfo.new(0.2), { TextColor3 = COLOR_HOVER }):Play()
end)
CloseButton.MouseLeave:Connect(function()
    TweenService:Create(CloseButton, TweenInfo.new(0.2), { TextColor3 = COLOR_TEXT }):Play()
end)

local function animateGuiAppearance()
    local tweenInfo = TweenInfo.new(0.5, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
    local tween = TweenService:Create(StatusFrame, tweenInfo, {
        Position = UDim2.new(1, -230, 0, 0),
        BackgroundTransparency = 0.3
    })
    TweenService:Create(StatusEmoji, tweenInfo, { TextTransparency = 0 }):Play()
    TweenService:Create(StatusTitle, tweenInfo, { TextTransparency = 0 }):Play()
    TweenService:Create(StatusProviderLabel, tweenInfo, { TextTransparency = 0 }):Play()
    TweenService:Create(StatusButton, tweenInfo, { TextTransparency = 0, BackgroundTransparency = 0.2 }):Play()
    TweenService:Create(CloseButton, tweenInfo, { TextTransparency = 0 }):Play()
    tween:Play()
end

animateGuiAppearance()

local isAnimating = false
local function animateStatusEmoji()
    if isAnimating then return end
    isAnimating = true
    while StatusButton.Text == "Stop" do
        local fadeIn = TweenService:Create(StatusEmoji, TweenInfo.new(1, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), { TextTransparency = 0 })
        local fadeOut = TweenService:Create(StatusEmoji, TweenInfo.new(1, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), { TextTransparency = 1 })
        fadeIn:Play()
        fadeIn.Completed:Wait()
        if StatusButton.Text ~= "Stop" then break end
        fadeOut:Play()
        fadeOut.Completed:Wait()
        if StatusButton.Text ~= "Stop" then break end
    end
    isAnimating = false
end

local scanCooldown = false
local cooldownEndTime = 0

local function updateAllButtonsCooldown()
    if not scanCooldown then return end

    local timeLeft = cooldownEndTime - tick()
    if timeLeft <= 0 then
        scanCooldown = false
        for _, data in pairs(playerScanButtons) do
            local button = data.button
            button.BackgroundColor3 = COLOR_ACCENT
            button.Text = "Scan"

            if button.Visible then
                TweenService:Create(button, TweenInfo.new(0.2), { BackgroundTransparency = 0.2, TextTransparency = 0 }):Play()
            end
        end
    else
        local countdown = math.ceil(timeLeft)
        for _, data in pairs(playerScanButtons) do
            local button = data.button
            button.BackgroundColor3 = Color3.fromRGB(100, 100, 100) 
            button.Text = tostring(countdown)
        end
    end
end

local isScanningEnabled = true

StatusButton.MouseButton1Click:Connect(function()
    isScanningEnabled = not isScanningEnabled
    if isScanningEnabled then
        StatusButton.Text = "Stop"
        StatusEmoji.Text = EMOJI_GREEN
        local tween = TweenService:Create(StatusEmoji, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), { TextTransparency = 0 })
        tween:Play()
        tween.Completed:Connect(function()
            if StatusButton.Text == "Stop" then
                coroutine.wrap(animateStatusEmoji)()
            end
        end)
        for _, data in pairs(playerScanButtons) do
            data.button.Visible = true
        end
    else
        StatusButton.Text = "Start"
        isAnimating = false
        local tween = TweenService:Create(StatusEmoji, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), { TextTransparency = 0 })
        StatusEmoji.Text = EMOJI_RED
        tween:Play()
        for _, data in pairs(playerScanButtons) do
            local fadeOut = TweenService:Create(data.button, TweenInfo.new(0.2), { BackgroundTransparency = 1, TextTransparency = 1 })
            fadeOut:Play()
            fadeOut.Completed:Connect(function()
                data.button.Visible = false
            end)
        end
    end
end)

coroutine.wrap(animateStatusEmoji)()

local function cleanupAll()
    isAnimating = false
    for player, data in pairs(playerScanButtons) do
        if data.connection then
            data.connection:Disconnect()
        end
        if data.button then
            data.button:Destroy()
        end
    end
    playerScanButtons = {}
    for player, data in pairs(playerResultWindows) do
        if data.connection then
            data.connection:Disconnect()
        end
        if data.frame then
            data.frame:Destroy()
        end
    end
    playerResultWindows = {}
    local tweenInfo = TweenInfo.new(0.2)
    TweenService:Create(StatusFrame, tweenInfo, { BackgroundTransparency = 1 }):Play()
    TweenService:Create(StatusEmoji, tweenInfo, { TextTransparency = 1 }):Play()
    TweenService:Create(StatusTitle, tweenInfo, { TextTransparency = 1 }):Play()
    TweenService:Create(StatusProviderLabel, tweenInfo, { TextTransparency = 1 }):Play()
    TweenService:Create(StatusButton, tweenInfo, { TextTransparency = 1, BackgroundTransparency = 1 }):Play()
    TweenService:Create(CloseButton, tweenInfo, { TextTransparency = 1 }):Play()
    task.delay(0.2, function()
        if ScreenGui then
            ScreenGui:Destroy()
        end
    end)
end

CloseButton.MouseButton1Click:Connect(cleanupAll)

local function capitalize(str)
    if not str or str == "" then return str end
    return str:sub(1, 1):upper() .. str:sub(2):lower()
end

local function checkLeakCheckFree(username)
    local success, response = pcall(function()
        local url = FREE_API_URL .. HttpService:UrlEncode(username)
        return game:HttpGet(url)
    end)

    if not success then
        return { status = "error", text = "Network error: " .. tostring(response), color = COLOR_ERROR }
    end

    local data
    local decodeSuccess, decodeResult = pcall(function()
        return HttpService:JSONDecode(response)
    end)

    if not decodeSuccess then
        return { status = "error", text = "Error: Invalid API response format", color = COLOR_ERROR }
    end

    data = decodeResult

    if not data.success then
        return { status = "no_leaks", text = "No leaks found", color = COLOR_NO_LEAKS }
    end

    local found = data.found or 0
    local breaches = data.sources or {}

    if found > 0 then
        -- Play sound when leaks are found
        local leakSound = Instance.new("Sound")
        leakSound.SoundId = LEAK_FOUND_SOUND_ID
        leakSound.Volume = 2
        leakSound.Parent = SoundService
        leakSound:Play()
        leakSound.Ended:Connect(function()
            leakSound:Destroy()
        end)
        
        -- Format the leaks data for GUI display
        local leaks = {}
        for _, breach in ipairs(breaches) do
            local leakData = {
                source = breach.name or "Unknown",
                date = breach.date or "Unknown date"
            }
            table.insert(leaks, leakData)
        end
        
        local resultText = found .. " leaks found"
        return { status = "leaks", text = resultText, color = COLOR_LEAKS, leaks = leaks, found = found }
    else
        return { status = "no_leaks", text = "No leaks found", color = COLOR_NO_LEAKS }
    end
end

local function showResult(player, result)
    if playerResultWindows[player] then
        local frame = playerResultWindows[player].frame
        local resultList = frame:FindFirstChild("ResultList")
        local leaksFoundLabel = frame:FindFirstChild("LeaksFoundLabel")
        local resultTitle = frame:FindFirstChild("ResultTitle")
        local closeButton = frame:FindFirstChild("CloseButton")
        local currentLeakIndex = playerResultWindows[player].currentLeakIndex or 1
        local leaks = result.leaks or playerResultWindows[player].leaks or {}

        for _, child in ipairs(resultList:GetChildren()) do
            if child:IsA("TextButton") then
                child:Destroy()
            end
        end
        for _, child in ipairs(frame:GetChildren()) do
            if child:IsA("TextButton") and child.Name ~= "CloseButton" then
                child:Destroy()
            end
        end

        if resultList then
            if result.status == "leaks" and #leaks > 0 then
                local leak = leaks[currentLeakIndex]
                local fieldsList = {
                    { field = "Source", value = leak.source, emoji = EMOJI_GLOBE },
                    { field = "Date", value = leak.date, emoji = EMOJI_CALENDAR }
                }

                for _, entry in ipairs(fieldsList) do
                    local fieldLabel = Instance.new("TextButton")
                    fieldLabel.Size = UDim2.new(1, 0, 0, 20)
                    fieldLabel.BackgroundTransparency = 1
                    fieldLabel.Text = (entry.emoji or "") .. " " .. capitalize(entry.field)
                    fieldLabel.TextColor3 = COLOR_TEXT
                    fieldLabel.TextSize = 14
                    fieldLabel.Font = Enum.Font.GothamBold
                    fieldLabel.TextXAlignment = Enum.TextXAlignment.Left
                    fieldLabel.TextTransparency = 1
                    fieldLabel.AutoButtonColor = false
                    fieldLabel.Parent = resultList
                    fieldLabel.MouseEnter:Connect(function()
                        TweenService:Create(fieldLabel, TweenInfo.new(0.2), { TextColor3 = Color3.fromRGB(200, 200, 200) }):Play()
                    end)
                    fieldLabel.MouseLeave:Connect(function()
                        TweenService:Create(fieldLabel, TweenInfo.new(0.2), { TextColor3 = COLOR_TEXT }):Play()
                    end)

                    local valueButton = Instance.new("TextButton")
                    valueButton.Size = UDim2.new(1, 0, 0, 20)
                    valueButton.BackgroundTransparency = 1
                    valueButton.Text = "  " .. entry.value
                    valueButton.TextColor3 = COLOR_TEXT
                    valueButton.TextSize = 14
                    valueButton.Font = Enum.Font.Gotham
                    valueButton.TextXAlignment = Enum.TextXAlignment.Left
                    valueButton.TextTransparency = 1
                    valueButton.AutoButtonColor = false
                    valueButton.Parent = resultList
                    valueButton.MouseButton1Click:Connect(function()
                        setclipboard(entry.value)
                        TweenService:Create(valueButton, TweenInfo.new(0.2), { TextColor3 = COLOR_COPIED }):Play()
                        task.delay(0.2, function()
                            TweenService:Create(valueButton, TweenInfo.new(1.8), { TextColor3 = COLOR_TEXT }):Play()
                        end)
                    end)
                    valueButton.MouseEnter:Connect(function()
                        TweenService:Create(valueButton, TweenInfo.new(0.2), { TextColor3 = Color3.fromRGB(200, 200, 200) }):Play()
                    end)
                    valueButton.MouseLeave:Connect(function()
                        TweenService:Create(valueButton, TweenInfo.new(0.2), { TextColor3 = COLOR_TEXT }):Play()
                    end)
                end

                leaksFoundLabel.Text = #leaks == 1 and "Leak Found" or tostring(#leaks) .. " Leaks Found"
                leaksFoundLabel.Visible = true
            else
                local textButton = Instance.new("TextButton")
                textButton.Size = UDim2.new(1, 0, 0, 20)
                textButton.Position = UDim2.new(0, 0, 0, 40)
                textButton.BackgroundTransparency = 1
                textButton.Text = result.text or "No leaks found"
                textButton.TextColor3 = result.color or COLOR_NO_LEAKS
                textButton.TextSize = 16
                textButton.Font = Enum.Font.GothamBold
                textButton.TextXAlignment = Enum.TextXAlignment.Center
                textButton.TextWrapped = true
                textButton.TextTransparency = 0
                textButton.AutoButtonColor = false
                textButton.Parent = frame
                textButton.Visible = true
                textButton.MouseButton1Click:Connect(function()
                    setclipboard(result.text or "No leaks found")
                    TweenService:Create(textButton, TweenInfo.new(0.2), { TextColor3 = COLOR_COPIED }):Play()
                    task.delay(0.2, function()
                        TweenService:Create(textButton, TweenInfo.new(1.8), { TextColor3 = result.color or COLOR_NO_LEAKS }):Play()
                    end)
                end)
                textButton.MouseEnter:Connect(function()
                    local r, g, b = (result.color or COLOR_NO_LEAKS).R * 255, (result.color or COLOR_NO_LEAKS).G * 255, (result.color or COLOR_NO_LEAKS).B * 255
                    local brighter = Color3.fromRGB(math.min(r + 50, 255), math.min(g + 50, 255), math.min(b + 50, 255))
                    TweenService:Create(textButton, TweenInfo.new(0.2), { TextColor3 = brighter }):Play()
                end)
                textButton.MouseLeave:Connect(function()
                    TweenService:Create(textButton, TweenInfo.new(0.2), { TextColor3 = result.color or COLOR_NO_LEAKS }):Play()
                end)
                leaksFoundLabel.Visible = false
            end
        end

        frame.Visible = true
        TweenService:Create(frame, TweenInfo.new(0.2), { BackgroundTransparency = 0.1 }):Play()
        TweenService:Create(resultTitle, TweenInfo.new(0.2), { TextTransparency = 0 }):Play()
        TweenService:Create(leaksFoundLabel, TweenInfo.new(0.2), { TextTransparency = 0 }):Play()
        TweenService:Create(closeButton, TweenInfo.new(0.2), { BackgroundTransparency = 0.2, TextTransparency = 0 }):Play()
        for _, child in ipairs(resultList:GetChildren()) do
            if child:IsA("TextButton") then
                TweenService:Create(child, TweenInfo.new(0.2), { TextTransparency = 0 }):Play()
            end
        end
        for _, child in ipairs(frame:GetChildren()) do
            if child:IsA("TextButton") and child.Name ~= "CloseButton" then
                TweenService:Create(child, TweenInfo.new(0.2), { TextTransparency = 0 }):Play()
            end
        end

        playerResultWindows[player].leaks = leaks
        playerResultWindows[player].currentLeakIndex = currentLeakIndex
        return
    end

    local ResultFrame = Instance.new("Frame")
    ResultFrame.Size = UDim2.new(0, 350, 0, 250)
    ResultFrame.BackgroundColor3 = WINDOW_BG
    ResultFrame.BackgroundTransparency = 1
    ResultFrame.Visible = false
    ResultFrame.Name = "ResultFrame_" .. player.Name
    ResultFrame.Parent = ScreenGui

    local ResultCorner = Instance.new("UICorner")
    ResultCorner.CornerRadius = UDim.new(0, 12)
    ResultCorner.Parent = ResultFrame

    local ResultTitle = Instance.new("TextLabel")
    ResultTitle.Name = "ResultTitle"
    ResultTitle.Size = UDim2.new(1, 0, 0, 40)
    ResultTitle.BackgroundTransparency = 1
    ResultTitle.Text = player.Name
    ResultTitle.TextColor3 = COLOR_ACCENT
    ResultTitle.TextSize = 20
    ResultTitle.Font = Enum.Font.GothamBlack
    ResultTitle.TextTransparency = 1
    ResultTitle.Parent = ResultFrame

    local LeaksFoundLabel = Instance.new("TextLabel")
    LeaksFoundLabel.Name = "LeaksFoundLabel"
    LeaksFoundLabel.Size = UDim2.new(1, 0, 0, 20)
    LeaksFoundLabel.Position = UDim2.new(0, 0, 0, 40)
    LeaksFoundLabel.BackgroundTransparency = 1
    LeaksFoundLabel.Text = (result.leaks and #result.leaks or 0) .. " Leaks Found"
    LeaksFoundLabel.TextColor3 = COLOR_LEAKS
    LeaksFoundLabel.TextSize = 16
    LeaksFoundLabel.Font = Enum.Font.GothamBold
    LeaksFoundLabel.TextTransparency = 1
    LeaksFoundLabel.Visible = result.status == "leaks" and result.leaks and #result.leaks > 0
    LeaksFoundLabel.Parent = ResultFrame

    local ResultScroll = Instance.new("ScrollingFrame")
    ResultScroll.Name = "ResultScroll"
    ResultScroll.Size = UDim2.new(0.9, 0, 0.8, 0)
    ResultScroll.Position = UDim2.new(0.05, 0, 0.15, 0)
    ResultScroll.BackgroundTransparency = 1
    ResultScroll.BorderSizePixel = 0
    ResultScroll.ScrollBarThickness = 4
    ResultScroll.CanvasSize = UDim2.new(0, 0, 0, 0)
    ResultScroll.Parent = ResultFrame

    local ResultList = Instance.new("Frame")
    ResultList.Name = "ResultList"
    ResultList.Size = UDim2.new(1, 0, 1, 0)
    ResultList.BackgroundTransparency = 1
    ResultList.Parent = ResultScroll

    local ListLayout = Instance.new("UIListLayout")
    ListLayout.SortOrder = Enum.SortOrder.LayoutOrder
    ListLayout.Padding = UDim.new(0, 5)
    ListLayout.Parent = ResultList

    ListLayout:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
        ResultScroll.CanvasSize = UDim2.new(0, 0, 0, ListLayout.AbsoluteContentSize.Y)
    end)

    local CloseButton = Instance.new("TextButton")
    CloseButton.Name = "CloseButton"
    CloseButton.Size = UDim2.new(0, 30, 0, 30)
    CloseButton.Position = UDim2.new(1, -40, 0, 10)
    CloseButton.BackgroundColor3 = COLOR_ACCENT
    CloseButton.BackgroundTransparency = 1
    CloseButton.Text = "X"
    CloseButton.TextColor3 = Color3.fromRGB(255, 255, 255)
    CloseButton.TextSize = 16
    CloseButton.Font = Enum.Font.GothamBold
    CloseButton.TextTransparency = 1
    CloseButton.Parent = ResultFrame

    local CloseCorner = Instance.new("UICorner")
    CloseCorner.CornerRadius = UDim.new(0, 8)
    CloseCorner.Parent = CloseButton

    playerResultWindows[player] = {
        frame = ResultFrame,
        connection = nil,
        currentLeakIndex = 1,
        leaks = result.leaks or {}
    }

    if result.status == "leaks" and result.leaks and #result.leaks > 0 then
        for _, leak in ipairs(result.leaks) do
            local fieldsList = {
                { field = "Source", value = leak.source, emoji = EMOJI_GLOBE },
                { field = "Date", value = leak.date, emoji = EMOJI_CALENDAR }
            }

            for _, entry in ipairs(fieldsList) do
                local fieldLabel = Instance.new("TextButton")
                fieldLabel.Size = UDim2.new(1, 0, 0, 20)
                fieldLabel.BackgroundTransparency = 1
                fieldLabel.Text = (entry.emoji or "") .. " " .. capitalize(entry.field)
                fieldLabel.TextColor3 = COLOR_TEXT
                fieldLabel.TextSize = 14
                fieldLabel.Font = Enum.Font.GothamBold
                fieldLabel.TextXAlignment = Enum.TextXAlignment.Left
                fieldLabel.TextTransparency = 1
                fieldLabel.AutoButtonColor = false
                fieldLabel.Parent = ResultList
                fieldLabel.MouseEnter:Connect(function()
                    TweenService:Create(fieldLabel, TweenInfo.new(0.2), { TextColor3 = Color3.fromRGB(200, 200, 200) }):Play()
                end)
                fieldLabel.MouseLeave:Connect(function()
                    TweenService:Create(fieldLabel, TweenInfo.new(0.2), { TextColor3 = COLOR_TEXT }):Play()
                end)

                local valueButton = Instance.new("TextButton")
                valueButton.Size = UDim2.new(1, 0, 0, 20)
                valueButton.BackgroundTransparency = 1
                valueButton.Text = "  " .. entry.value
                valueButton.TextColor3 = COLOR_TEXT
                valueButton.TextSize = 14
                valueButton.Font = Enum.Font.Gotham
                valueButton.TextXAlignment = Enum.TextXAlignment.Left
                valueButton.TextTransparency = 1
                valueButton.AutoButtonColor = false
                valueButton.Parent = ResultList
                valueButton.MouseButton1Click:Connect(function()
                    setclipboard(entry.value)
                    TweenService:Create(valueButton, TweenInfo.new(0.2), { TextColor3 = COLOR_COPIED }):Play()
                    task.delay(0.2, function()
                        TweenService:Create(valueButton, TweenInfo.new(1.8), { TextColor3 = COLOR_TEXT }):Play()
                    end)
                end)
                valueButton.MouseEnter:Connect(function()
                    TweenService:Create(valueButton, TweenInfo.new(0.2), { TextColor3 = Color3.fromRGB(200, 200, 200) }):Play()
                end)
                valueButton.MouseLeave:Connect(function()
                    TweenService:Create(valueButton, TweenInfo.new(0.2), { TextColor3 = COLOR_TEXT }):Play()
                end)
            end
        end
        LeaksFoundLabel.Text = #result.leaks == 1 and "Leak Found" or tostring(#result.leaks) .. " Leaks Found"
    else
        local textButton = Instance.new("TextButton")
        textButton.Size = UDim2.new(1, 0, 0, 20)
        textButton.Position = UDim2.new(0, 0, 0, 40)
        textButton.BackgroundTransparency = 1
        textButton.Text = result.text or "No leaks found"
        textButton.TextColor3 = result.color or COLOR_NO_LEAKS
        textButton.TextSize = 16
        textButton.Font = Enum.Font.GothamBold
        textButton.TextXAlignment = Enum.TextXAlignment.Center
        textButton.TextWrapped = true
        textButton.TextTransparency = 0
        textButton.AutoButtonColor = false
        textButton.Parent = ResultFrame
        textButton.Visible = true
        textButton.MouseButton1Click:Connect(function()
            setclipboard(result.text or "No leaks found")
            TweenService:Create(textButton, TweenInfo.new(0.2), { TextColor3 = COLOR_COPIED }):Play()
            task.delay(0.2, function()
                TweenService:Create(textButton, TweenInfo.new(1.8), { TextColor3 = result.color or COLOR_NO_LEAKS }):Play()
            end)
        end)
        textButton.MouseEnter:Connect(function()
            local r, g, b = (result.color or COLOR_NO_LEAKS).R * 255, (result.color or COLOR_NO_LEAKS).G * 255, (result.color or COLOR_NO_LEAKS).B * 255
            local brighter = Color3.fromRGB(math.min(r + 50, 255), math.min(g + 50, 255), math.min(b + 50, 255))
            TweenService:Create(textButton, TweenInfo.new(0.2), { TextColor3 = brighter }):Play()
        end)
        textButton.MouseLeave:Connect(function()
            TweenService:Create(textButton, TweenInfo.new(0.2), { TextColor3 = result.color or COLOR_NO_LEAKS }):Play()
        end)
    end

    CloseButton.MouseButton1Click:Connect(function()
        local fadeOut = TweenService:Create(ResultFrame, TweenInfo.new(0.2), { BackgroundTransparency = 1 })
        local titleFadeOut = TweenService:Create(ResultTitle, TweenInfo.new(0.2), { TextTransparency = 1 })
        local leaksFadeOut = TweenService:Create(LeaksFoundLabel, TweenInfo.new(0.2), { TextTransparency = 1 })
        local closeFadeOut = TweenService:Create(CloseButton, TweenInfo.new(0.2), { BackgroundTransparency = 1, TextTransparency = 1 })
        fadeOut:Play()
        titleFadeOut:Play()
        leaksFadeOut:Play()
        closeFadeOut:Play()
        for _, child in ipairs(ResultList:GetChildren()) do
            if child:IsA("TextButton") then
                TweenService:Create(child, TweenInfo.new(0.2), { TextTransparency = 1 }):Play()
            end
        end
        for _, child in ipairs(ResultFrame:GetChildren()) do
            if child:IsA("TextButton") and child.Name ~= "CloseButton" then
                TweenService:Create(child, TweenInfo.new(0.2), { TextTransparency = 1 }):Play()
            end
        end
        fadeOut.Completed:Connect(function()
            ResultFrame.Visible = false
            if playerResultWindows[player] then
                if playerResultWindows[player].connection then
                    playerResultWindows[player].connection:Disconnect()
                end
                ResultFrame:Destroy()
                playerResultWindows[player] = nil
            end
        end)
    end)

    local resultDragging, resultDragInput, resultDragStart, resultStartPos
    ResultFrame.InputBegan:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton1 then
            resultDragging = true
            resultDragStart = input.Position
            resultStartPos = ResultFrame.Position
            if playerResultWindows[player] and playerResultWindows[player].connection then
                playerResultWindows[player].connection:Disconnect()
                playerResultWindows[player].connection = nil
            end
            input.Changed:Connect(function()
                if input.UserInputState == Enum.UserInputState.End then
                    resultDragging = false
                end
            end)
        end
    end)

    ResultFrame.InputChanged:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseMovement then
            resultDragInput = input
        end
    end)

    UserInputService.InputChanged:Connect(function(input)
        if input == resultDragInput and resultDragging then
            local delta = input.Position - resultDragStart
            ResultFrame.Position = UDim2.new(resultStartPos.X.Scale, resultStartPos.X.Offset + delta.X, resultStartPos.Y.Scale, resultStartPos.Y.Offset + delta.Y)
        end
    end)

    ResultFrame.Visible = true
    TweenService:Create(ResultFrame, TweenInfo.new(0.2), { BackgroundTransparency = 0.1 }):Play()
    TweenService:Create(ResultTitle, TweenInfo.new(0.2), { TextTransparency = 0 }):Play()
    TweenService:Create(LeaksFoundLabel, TweenInfo.new(0.2), { TextTransparency = 0 }):Play()
    TweenService:Create(CloseButton, TweenInfo.new(0.2), { BackgroundTransparency = 0.2, TextTransparency = 0 }):Play()
    for _, child in ipairs(ResultList:GetChildren()) do
        if child:IsA("TextButton") then
            TweenService:Create(child, TweenInfo.new(0.2), { TextTransparency = 0 }):Play()
        end
    end
    for _, child in ipairs(ResultFrame:GetChildren()) do
        if child:IsA("TextButton") and child.Name ~= "CloseButton" then
            TweenService:Create(child, TweenInfo.new(0.2), { TextTransparency = 0 }):Play()
        end
    end

    local isFadingOut = false
    local lastDistance = math.huge
    playerResultWindows[player].connection = RunService.Heartbeat:Connect(function()
        if player and player.Character and player.Character:FindFirstChild("HumanoidRootPart") and player.Character:FindFirstChild("Head") then
            local head = player.Character.Head
            local localPlayer = Players.LocalPlayer
            if localPlayer and localPlayer.Character and localPlayer.Character:FindFirstChild("HumanoidRootPart") then
                local distance = (player.Character.HumanoidRootPart.Position - localPlayer.Character.HumanoidRootPart.Position).Magnitude
                local screenPos, onScreen = workspace.CurrentCamera:WorldToViewportPoint(head.Position + Vector3.new(0, 3, 0))

                local viewportSize = workspace.CurrentCamera.ViewportSize
                local frameWidth = 350
                local frameHeight = 250
                local posX = math.clamp(screenPos.X - 175, 0, viewportSize.X - frameWidth)
                local posY = math.clamp(screenPos.Y - 200, 0, viewportSize.Y - frameHeight)
                ResultFrame.Position = UDim2.new(0, posX, 0, posY)

                if onScreen and distance <= SCAN_DISTANCE then
                    if isFadingOut or ResultFrame.BackgroundTransparency > 0.1 then
                        isFadingOut = false
                        TweenService:Create(ResultFrame, TweenInfo.new(0.2), { BackgroundTransparency = 0.1 }):Play()
                        TweenService:Create(ResultTitle, TweenInfo.new(0.2), { TextTransparency = 0 }):Play()
                        TweenService:Create(LeaksFoundLabel, TweenInfo.new(0.2), { TextTransparency = 0 }):Play()
                        TweenService:Create(CloseButton, TweenInfo.new(0.2), { BackgroundTransparency = 0.2, TextTransparency = 0 }):Play()
                        for _, child in ipairs(ResultList:GetChildren()) do
                            if child:IsA("TextButton") then
                                TweenService:Create(child, TweenInfo.new(0.2), { TextTransparency = 0 }):Play()
                            end
                        end
                        for _, child in ipairs(ResultFrame:GetChildren()) do
                            if child:IsA("TextButton") and child.Name ~= "CloseButton" then
                                TweenService:Create(child, TweenInfo.new(0.2), { TextTransparency = 0 }):Play()
                            end
                        end
                    end
                    ResultFrame.Visible = true
                else
                    if not isFadingOut and ResultFrame.BackgroundTransparency < 1 then
                        isFadingOut = true
                        TweenService:Create(ResultFrame, TweenInfo.new(0.2), { BackgroundTransparency = 1 }):Play()
                        TweenService:Create(ResultTitle, TweenInfo.new(0.2), { TextTransparency = 1 }):Play()
                        TweenService:Create(LeaksFoundLabel, TweenInfo.new(0.2), { TextTransparency = 1 }):Play()
                        TweenService:Create(CloseButton, TweenInfo.new(0.2), { BackgroundTransparency = 1, TextTransparency = 1 }):Play()
                        for _, child in ipairs(ResultList:GetChildren()) do
                            if child:IsA("TextButton") then
                                TweenService:Create(child, TweenInfo.new(0.2), { TextTransparency = 1 }):Play()
                            end
                        end
                        for _, child in ipairs(ResultFrame:GetChildren()) do
                            if child:IsA("TextButton") and child.Name ~= "CloseButton" then
                                TweenService:Create(child, TweenInfo.new(0.2), { TextTransparency = 1 }):Play()
                            end
                        end
                    end
                    ResultFrame.Visible = ResultFrame.BackgroundTransparency < 1
                end
                lastDistance = distance
            end
        else
            ResultFrame.Visible = false
        end
    end)
end

local function createScanButton(player)
    if playerScanButtons[player] then
        return
    end

    local button = Instance.new("TextButton")
    button.Size = UDim2.new(0, 80, 0, 30)
    button.BackgroundColor3 = COLOR_ACCENT
    button.BackgroundTransparency = 1
    button.Text = "Scan"
    button.TextColor3 = Color3.fromRGB(255, 255, 255)
    button.TextSize = 16
    button.Font = Enum.Font.GothamBold
    button.TextTransparency = 1
    button.Visible = false
    button.Parent = ScreenGui

    local buttonCorner = Instance.new("UICorner")
    buttonCorner.CornerRadius = UDim.new(0, 8)
    buttonCorner.Parent = button

    playerScanButtons[player] = {
        button = button,
        connection = nil
    }

    local function updateButton()
        if not player or not player.Character or not player.Character:FindFirstChild("HumanoidRootPart") or not player.Character:FindFirstChild("Head") then
            button.Visible = false
            return
        end

        local head = player.Character.Head
        local localPlayer = Players.LocalPlayer
        if not localPlayer or not localPlayer.Character or not localPlayer.Character:FindFirstChild("HumanoidRootPart") then
            button.Visible = false
            return
        end

        local distance = (player.Character.HumanoidRootPart.Position - localPlayer.Character.HumanoidRootPart.Position).Magnitude
        local screenPos, onScreen = workspace.CurrentCamera:WorldToViewportPoint(head.Position + Vector3.new(0, 3, 0))

        if onScreen and distance <= SCAN_DISTANCE and isScanningEnabled then
            button.Position = UDim2.new(0, screenPos.X - 40, 0, screenPos.Y)
            if button.BackgroundTransparency > 0 and not scanCooldown then
                TweenService:Create(button, TweenInfo.new(0.2), { BackgroundTransparency = 0.2, TextTransparency = 0 }):Play()
            end
            button.Visible = true
        else
            if button.BackgroundTransparency < 1 then
                local fadeOut = TweenService:Create(button, TweenInfo.new(0.2), { BackgroundTransparency = 1, TextTransparency = 1 })
                fadeOut:Play()
                fadeOut.Completed:Connect(function()
                    button.Visible = false
                end)
            else
                button.Visible = false
            end
        end
    end

    playerScanButtons[player].connection = RunService.Heartbeat:Connect(updateButton)

    button.MouseButton1Click:Connect(function()
        if not isScanningEnabled or scanCooldown then
            return
        end

        scanCooldown = true
        cooldownEndTime = tick() + 3 

        local result = checkLeakCheckFree(player.Name)
        showResult(player, result)
    end)
end

RunService.Heartbeat:Connect(updateAllButtonsCooldown)

for _, player in ipairs(Players:GetPlayers()) do
    if player ~= Players.LocalPlayer then
        createScanButton(player)
    end
end

Players.PlayerAdded:Connect(function(player)
    if player ~= Players.LocalPlayer then
        createScanButton(player)
    end
end)

Players.PlayerRemoving:Connect(function(player)
    if playerScanButtons[player] then
        if playerScanButtons[player].connection then
            playerScanButtons[player].connection:Disconnect()
        end
        if playerScanButtons[player].button then
            playerScanButtons[player].button:Destroy()
        end
        playerScanButtons[player] = nil
    end
    if playerResultWindows[player] then
        if playerResultWindows[player].connection then
            playerResultWindows[player].connection:Disconnect()
        end
        if playerResultWindows[player].frame then
            playerResultWindows[player].frame:Destroy()
        end
        playerResultWindows[player] = nil
    end
end)
