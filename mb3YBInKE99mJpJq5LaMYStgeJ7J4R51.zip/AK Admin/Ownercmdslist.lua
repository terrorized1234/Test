local Players = game:GetService("Players")
local UserInputService = game:GetService("UserInputService")
local lp = Players.LocalPlayer

local gui = Instance.new("ScreenGui")
gui.Name = "BotCommandsGUI"
gui.Parent = lp.PlayerGui
gui.ResetOnSpawn = false

local mainFrame = Instance.new("Frame")
mainFrame.Name = "MainFrame"
mainFrame.Parent = gui
mainFrame.Size = UDim2.new(0, 300, 0, 400)
mainFrame.Position = UDim2.new(0.5, -150, 0.5, -200)
mainFrame.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
mainFrame.BackgroundTransparency = 0.4
mainFrame.BorderSizePixel = 0

local corner = Instance.new("UICorner")
corner.CornerRadius = UDim.new(0, 8)
corner.Parent = mainFrame

local titleLabel = Instance.new("TextLabel")
titleLabel.Name = "TitleLabel"
titleLabel.Parent = mainFrame
titleLabel.Size = UDim2.new(1, -60, 0, 25)
titleLabel.Position = UDim2.new(0, 30, 0, 8)
titleLabel.BackgroundTransparency = 1
titleLabel.Text = "Bot Commands"
titleLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
titleLabel.TextSize = 16
titleLabel.Font = Enum.Font.SourceSans
titleLabel.TextXAlignment = Enum.TextXAlignment.Center

local minimizeBtn = Instance.new("TextButton")
minimizeBtn.Name = "MinimizeBtn"
minimizeBtn.Parent = mainFrame
minimizeBtn.Size = UDim2.new(0, 20, 0, 20)
minimizeBtn.Position = UDim2.new(1, -50, 0, 8)
minimizeBtn.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
minimizeBtn.BackgroundTransparency = 0.5
minimizeBtn.BorderSizePixel = 0
minimizeBtn.Text = "-"
minimizeBtn.TextColor3 = Color3.fromRGB(200, 200, 200)
minimizeBtn.TextSize = 12
minimizeBtn.Font = Enum.Font.SourceSans

local minCorner = Instance.new("UICorner")
minCorner.CornerRadius = UDim.new(0, 4)
minCorner.Parent = minimizeBtn

local closeBtn = Instance.new("TextButton")
closeBtn.Name = "CloseBtn"
closeBtn.Parent = mainFrame
closeBtn.Size = UDim2.new(0, 20, 0, 20)
closeBtn.Position = UDim2.new(1, -25, 0, 8)
closeBtn.BackgroundColor3 = Color3.fromRGB(40, 20, 20)
closeBtn.BackgroundTransparency = 0.5
closeBtn.BorderSizePixel = 0
closeBtn.Text = "X"
closeBtn.TextColor3 = Color3.fromRGB(255, 100, 100)
closeBtn.TextSize = 12
closeBtn.Font = Enum.Font.SourceSans

local closeCorner = Instance.new("UICorner")
closeCorner.CornerRadius = UDim.new(0, 4)
closeCorner.Parent = closeBtn

local contentFrame = Instance.new("Frame")
contentFrame.Name = "ContentFrame"
contentFrame.Parent = mainFrame
contentFrame.Size = UDim2.new(1, -20, 1, -45)
contentFrame.Position = UDim2.new(0, 10, 0, 37)
contentFrame.BackgroundTransparency = 1

local scrollFrame = Instance.new("ScrollingFrame")
scrollFrame.Name = "ScrollFrame"
scrollFrame.Parent = contentFrame
scrollFrame.Size = UDim2.new(1, 0, 1, 0)
scrollFrame.BackgroundTransparency = 1
scrollFrame.BorderSizePixel = 0
scrollFrame.ScrollBarThickness = 4
scrollFrame.ScrollBarImageColor3 = Color3.fromRGB(60, 60, 60)
scrollFrame.ScrollBarImageTransparency = 0.6
scrollFrame.CanvasSize = UDim2.new(0, 0, 0, 0)
scrollFrame.AutomaticCanvasSize = Enum.AutomaticSize.Y

local listLayout = Instance.new("UIListLayout")
listLayout.Parent = scrollFrame
listLayout.SortOrder = Enum.SortOrder.LayoutOrder
listLayout.Padding = UDim.new(0, 4)

local commands = {
    {".kick [reason] | .ban", "Kicks bot from game with optional reason", "Control"},
    {".crash", "Crashes the bot with infinite loop", "Control"},
    {".reset | .re", "Kills and respawns bot at same position", "Control"},
    {".bring | .br", "Brings bot to command sender", "Movement"},
    {".come [target] [dest]", "Teleports target to destination", "Movement"},
    {".goto <x> <y> <z> [target]", "Teleport to specific coordinates", "Movement"},
    {".follow [target]", "Makes bot follow a player", "Movement"},
    {".unfollow", "Stops following any player", "Movement"},
    {".walkto [target] [dest]", "Makes target walk to destination", "Movement"},
    {".jump | .jmp | .unsit", "Makes bot jump and stand up", "Animation"},
    {".sit", "Makes bot sit down", "Animation"},
    {".dance [target]", "Performs dance animation", "Animation"},
    {".spin [target]", "Spins target in place", "Animation"},
    {".circle [target]", "Makes target move in circle", "Animation"},
    {".orbit [target] [center]", "Makes target orbit around player", "Animation"},
    {".trip", "Makes bot trip and fall", "Animation"},
    {".freeze | .lock", "Freezes bot in place", "Physical"},
    {".thaw | .unfreeze | .unlock", "Unfreezes the bot", "Physical"},
    {".stun [target]", "Stuns target (PlatformStand)", "Physical"},
    {".unstun [target]", "Removes stun from target", "Physical"},
    {".speed <value> [target]", "Sets walkspeed for target", "Physical"},
    {".kill", "Kills the bot", "Combat"},
    {".fling", "Flings bot with random velocity", "Combat"},
    {".fling2", "Flings bot with stronger velocity", "Combat"},
    {".loopkill [target]", "Continuously kills target", "Combat"},
    {".unloopkill [target]", "Stops loop killing target", "Combat"},
    {".creepy | .shiver | .xd", "Plays creepy sound effect", "Audio"},
    {".knock | .xd2", "Plays knocking sound effect", "Audio"},
    {".jumpscare | .jp | .js | .lol", "Displays jumpscare with sound", "Visual"},
    {".jumpscare2 | .jp2 | .js2 | .lol2", "Alternative jumpscare effect", "Visual"},
    {".jumpscarefast | .jpf | .lol3", "Quick random jumpscare", "Visual"},
    {".chat [message] | .ch", "Makes bot send chat message", "Communication"},
    {".say [target] <message>", "Makes target say message", "Communication"},
    {".invert [target]", "Inverts movement controls", "Special"},
    {".usecmd [target] <command>", "Executes external command", "Special"},
    {".cmds [target]", "Loads command list GUI", "Special"}
}

local categories = {"Control", "Movement", "Animation", "Physical", "Combat", "Audio", "Visual", "Communication", "Special"}
local categoryColors = {
    Control = Color3.fromRGB(220, 53, 69),
    Movement = Color3.fromRGB(40, 167, 69),
    Animation = Color3.fromRGB(255, 193, 7),
    Physical = Color3.fromRGB(23, 162, 184),
    Combat = Color3.fromRGB(220, 53, 69),
    Audio = Color3.fromRGB(138, 43, 226),
    Visual = Color3.fromRGB(255, 20, 147),
    Communication = Color3.fromRGB(32, 201, 151),
    Special = Color3.fromRGB(255, 140, 0)
}

for _, category in ipairs(categories) do
    local categoryHeader = Instance.new("Frame")
    categoryHeader.Size = UDim2.new(1, 0, 0, 25)
    categoryHeader.BackgroundColor3 = categoryColors[category]
    categoryHeader.BackgroundTransparency = 0.8
    categoryHeader.BorderSizePixel = 0
    categoryHeader.Parent = scrollFrame
    
    local categoryCorner = Instance.new("UICorner")
    categoryCorner.CornerRadius = UDim.new(0, 4)
    categoryCorner.Parent = categoryHeader
    
    local categoryLabel = Instance.new("TextLabel")
    categoryLabel.Parent = categoryHeader
    categoryLabel.Size = UDim2.new(1, -10, 1, 0)
    categoryLabel.Position = UDim2.new(0, 5, 0, 0)
    categoryLabel.BackgroundTransparency = 1
    categoryLabel.Text = category .. " Commands"
    categoryLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
    categoryLabel.TextSize = 14
    categoryLabel.Font = Enum.Font.SourceSansBold
    categoryLabel.TextXAlignment = Enum.TextXAlignment.Left
    
    for _, cmd in ipairs(commands) do
        if cmd[3] == category then
            local entry = Instance.new("Frame")
            entry.Size = UDim2.new(1, 0, 0, 42)
            entry.BackgroundColor3 = Color3.fromRGB(10, 10, 10)
            entry.BackgroundTransparency = 0.6
            entry.BorderSizePixel = 0
            entry.Parent = scrollFrame
            
            local entryCorner = Instance.new("UICorner")
            entryCorner.CornerRadius = UDim.new(0, 4)
            entryCorner.Parent = entry
            
            local categoryIndicator = Instance.new("Frame")
            categoryIndicator.Size = UDim2.new(0, 3, 1, 0)
            categoryIndicator.Position = UDim2.new(0, 0, 0, 0)
            categoryIndicator.BackgroundColor3 = categoryColors[category]
            categoryIndicator.BorderSizePixel = 0
            categoryIndicator.Parent = entry
            
            local indicatorCorner = Instance.new("UICorner")
            indicatorCorner.CornerRadius = UDim.new(0, 2)
            indicatorCorner.Parent = categoryIndicator
            
            local commandLabel = Instance.new("TextLabel")
            commandLabel.Parent = entry
            commandLabel.Size = UDim2.new(1, -15, 0, 18)
            commandLabel.Position = UDim2.new(0, 8, 0, 3)
            commandLabel.BackgroundTransparency = 1
            commandLabel.Text = cmd[1]
            commandLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
            commandLabel.TextSize = 12
            commandLabel.Font = Enum.Font.SourceSans
            commandLabel.TextXAlignment = Enum.TextXAlignment.Left
            
            local descLabel = Instance.new("TextLabel")
            descLabel.Parent = entry
            descLabel.Size = UDim2.new(1, -15, 0, 16)
            descLabel.Position = UDim2.new(0, 8, 0, 22)
            descLabel.BackgroundTransparency = 1
            descLabel.Text = cmd[2]
            descLabel.TextColor3 = Color3.fromRGB(180, 180, 180)
            descLabel.TextSize = 10
            descLabel.Font = Enum.Font.SourceSans
            descLabel.TextXAlignment = Enum.TextXAlignment.Left
        end
    end
end

local isDragging = false
local dragStart = nil
local startPos = nil

mainFrame.InputBegan:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
        isDragging = true
        dragStart = input.Position
        startPos = mainFrame.Position
        
        input.Changed:Connect(function()
            if input.UserInputState == Enum.UserInputState.End then
                isDragging = false
            end
        end)
    end
end)

UserInputService.InputChanged:Connect(function(input)
    if isDragging and (input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch) then
        local delta = input.Position - dragStart
        local newPos = UDim2.new(startPos.X.Scale, startPos.X.Offset + delta.X, startPos.Y.Scale, startPos.Y.Offset + delta.Y)
        mainFrame.Position = newPos
    end
end)

local isMinimized = false

minimizeBtn.MouseButton1Click:Connect(function()
    isMinimized = not isMinimized
    if isMinimized then
        contentFrame.Visible = false
        mainFrame.Size = UDim2.new(0, 300, 0, 40)
        minimizeBtn.Text = "+"
    else
        contentFrame.Visible = true
        mainFrame.Size = UDim2.new(0, 300, 0, 400)
        minimizeBtn.Text = "-"
    end
end)

closeBtn.MouseButton1Click:Connect(function()
    gui:Destroy()
end)
