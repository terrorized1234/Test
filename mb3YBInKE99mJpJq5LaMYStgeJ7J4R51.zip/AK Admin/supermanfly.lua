local Players = game:GetService("Players")
local UserInputService = game:GetService("UserInputService")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")

local player = Players.LocalPlayer
local character = player.Character or player.CharacterAdded:Wait()
local humanoid = character:WaitForChild("Humanoid")
local rootPart = character:WaitForChild("HumanoidRootPart")
local originalGravity = Workspace.Gravity

local flying = false
local flySpeed = 120 -- Default speed
local isMinimized = false

local currentAnim = nil
local currentAnimTrack = nil
local lastDirection = "none"
local animateScriptDisabled = false

local dragging = false
local dragStartPos, dragStartMousePos
local sliderDragging = false

local function createElement(className, properties, parent)
	local obj = Instance.new(className)
	for prop, val in pairs(properties) do
		obj[prop] = val
	end
	if parent then
		obj.Parent = parent
	end
	return obj
end

local function PlayAnim(id, time, speed)
	pcall(function()
		-- Stop current animation first
		if currentAnimTrack then
			currentAnimTrack:Stop(0.1)
			currentAnimTrack = nil
		end
		
		-- Disable animate script only once when flying starts
		if not animateScriptDisabled and flying then
			if player.Character:FindFirstChild("Animate") then
				player.Character.Animate.Disabled = true
				animateScriptDisabled = true
			end
		end
		
		-- Stop all playing animations
		local animTracks = humanoid:GetPlayingAnimationTracks()
		for i, track in pairs(animTracks) do
			track:Stop(0.1)
		end
		
		-- Create and play new animation
		local anim = Instance.new("Animation")
		anim.AnimationId = "rbxassetid://" .. tostring(id)
		
		local animTrack = humanoid:LoadAnimation(anim)
		animTrack:Play()
		
		if time then
			animTrack.TimePosition = time
		end
		if speed then
			animTrack:AdjustSpeed(speed)
		end
		
		currentAnimTrack = animTrack
		currentAnim = anim
		
		-- Clean up when animation stops
		animTrack.Stopped:Connect(function()
			if currentAnimTrack == animTrack then
				currentAnimTrack = nil
			end
		end)
	end)
end

local function StopAnim()
	-- Stop current custom animation
	if currentAnimTrack then
		currentAnimTrack:Stop(0.1)
		currentAnimTrack = nil
	end
	
	-- Re-enable animate script
	if animateScriptDisabled and player.Character:FindFirstChild("Animate") then
		player.Character.Animate.Disabled = false
		animateScriptDisabled = false
	end
	
	-- Stop all playing animations
	local animTracks = humanoid:GetPlayingAnimationTracks()
	for i, track in pairs(animTracks) do
		track:Stop(0.1)
	end
end

local PlayerModule = require(player.PlayerScripts:WaitForChild("PlayerModule"))
local Controls = PlayerModule:GetControls()

-- Create GUI using the first script's style
local flyGui = createElement("ScreenGui", {Name = "FlyGui", ResetOnSpawn = false}, player:WaitForChild("PlayerGui"))

local mainFrame = createElement("Frame", {
	Name = "MainFrame",
	Size = UDim2.new(0, 200, 0, 105), -- Reduced height since no keybind button
	Position = UDim2.new(0.5, -100, 0.5, -52),
	BackgroundColor3 = Color3.fromRGB(0, 0, 0),
	BackgroundTransparency = 0.6,
	BorderSizePixel = 0,
	Active = true
}, flyGui)
createElement("UICorner", {CornerRadius = UDim.new(0, 10)}, mainFrame)

local titleLabel = createElement("TextLabel", {
	Name = "TitleLabel",
	Size = UDim2.new(1, -60, 0, 30),
	Position = UDim2.new(0, 5, 0, 5),
	BackgroundTransparency = 1,
	Text = "Superman Fly",
	Font = Enum.Font.GothamBold,
	TextSize = 12,
	TextColor3 = Color3.new(1, 1, 1),
	TextXAlignment = Enum.TextXAlignment.Center
}, mainFrame)

local toggleButton = createElement("TextButton", {
	Name = "ToggleButton",
	Size = UDim2.new(0, 190, 0, 25),
	Position = UDim2.new(0, 5, 0, 35),
	BackgroundColor3 = Color3.fromRGB(0, 0, 0),
	BackgroundTransparency = 0.6,
	Text = "FLY: OFF",
	Font = Enum.Font.GothamBold,
	TextSize = 12,
	TextColor3 = Color3.new(1, 1, 1),
	BorderSizePixel = 0
}, mainFrame)
createElement("UICorner", {CornerRadius = UDim.new(0, 5)}, toggleButton)

local speedFrame = createElement("Frame", {
	Name = "SpeedFrame",
	Size = UDim2.new(0, 190, 0, 25),
	Position = UDim2.new(0, 5, 0, 65),
	BackgroundTransparency = 1
}, mainFrame)

local speedLabel = createElement("TextLabel", {
	Name = "SpeedLabel",
	Size = UDim2.new(0, 50, 0, 25),
	Position = UDim2.new(0, 0, 0, 0),
	BackgroundTransparency = 1,
	Text = "SPEED: " .. tostring(flySpeed),
	Font = Enum.Font.GothamBold,
	TextSize = 12,
	TextColor3 = Color3.new(1, 1, 1),
	TextScaled = true
}, speedFrame)

local speedSlider = createElement("Frame", {
	Name = "SpeedSlider",
	Size = UDim2.new(0, 135, 0, 10),
	Position = UDim2.new(0, 55, 0, 8),
	BackgroundColor3 = Color3.fromRGB(50, 50, 50),
	BackgroundTransparency = 0.6,
	BorderSizePixel = 0
}, speedFrame)
createElement("UICorner", {CornerRadius = UDim.new(0, 5)}, speedSlider)

local speedKnob = createElement("Frame", {
	Name = "SpeedKnob",
	Size = UDim2.new(0, 15, 0, 10),
	Position = UDim2.new((flySpeed - 10) / 390, -7.5, 0, 0), -- Updated calculation for 400 max
	BackgroundColor3 = Color3.fromRGB(255, 255, 255),
	BackgroundTransparency = 0.2,
	BorderSizePixel = 0
}, speedSlider)
createElement("UICorner", {CornerRadius = UDim.new(0, 5)}, speedKnob)

local minimizeButton = createElement("TextButton", {
	Name = "MinimizeButton",
	Size = UDim2.new(0, 25, 0, 25),
	Position = UDim2.new(1, -55, 0, 5),
	BackgroundColor3 = Color3.fromRGB(0, 0, 0),
	BackgroundTransparency = 0.6,
	Text = "—",
	Font = Enum.Font.GothamBold,
	TextSize = 12,
	TextColor3 = Color3.new(1, 1, 1),
	BorderSizePixel = 0
}, mainFrame)
createElement("UICorner", {CornerRadius = UDim.new(0, 5)}, minimizeButton)

local closeButton = createElement("TextButton", {
	Name = "CloseButton",
	Size = UDim2.new(0, 25, 0, 25),
	Position = UDim2.new(1, -30, 0, 5),
	BackgroundColor3 = Color3.fromRGB(0, 0, 0),
	BackgroundTransparency = 0.6,
	Text = "X",
	Font = Enum.Font.GothamBold,
	TextSize = 12,
	TextColor3 = Color3.new(1, 1, 1),
	BorderSizePixel = 0
}, mainFrame)
createElement("UICorner", {CornerRadius = UDim.new(0, 5)}, closeButton)

-- Dragging functionality
titleLabel.InputBegan:Connect(function(input)
	if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
		dragging = true
		dragStartPos = mainFrame.Position
		dragStartMousePos = input.Position
	end
end)

UserInputService.InputChanged:Connect(function(input)
	if dragging and (input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch) then
		local delta = input.Position - dragStartMousePos
		mainFrame.Position = UDim2.new(dragStartPos.X.Scale, dragStartPos.X.Offset + delta.X, dragStartPos.Y.Scale, dragStartPos.Y.Offset + delta.Y)
	end
end)

UserInputService.InputEnded:Connect(function(input)
	if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
		dragging = false
		sliderDragging = false
	end
end)

-- Slider functionality
local function updateSlider(mousePos)
	local sliderPos = speedSlider.AbsolutePosition
	local sliderSize = speedSlider.AbsoluteSize
	local relativeX = mousePos.X - sliderPos.X
	local percentage = math.clamp(relativeX / sliderSize.X, 0, 1)
	
	flySpeed = math.floor(10 + (percentage * 390)) -- Speed range: 10-400
	speedLabel.Text = "SPEED: " .. tostring(flySpeed)
	speedKnob.Position = UDim2.new(percentage, -7.5, 0, 0)
end

speedSlider.InputBegan:Connect(function(input)
	if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
		sliderDragging = true
		updateSlider(input.Position)
	end
end)

speedKnob.InputBegan:Connect(function(input)
	if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
		sliderDragging = true
	end
end)

UserInputService.InputChanged:Connect(function(input)
	if sliderDragging and (input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch) then
		updateSlider(input.Position)
	end
end)

-- Minimize functionality
minimizeButton.MouseButton1Click:Connect(function()
	isMinimized = not isMinimized
	
	local tweenInfo = TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	
	if isMinimized then
		local tween = TweenService:Create(mainFrame, tweenInfo, {
			Size = UDim2.new(0, 200, 0, 35)
		})
		tween:Play()
		
		toggleButton.Visible = false
		speedFrame.Visible = false
		minimizeButton.Text = "+"
	else
		local tween = TweenService:Create(mainFrame, tweenInfo, {
			Size = UDim2.new(0, 200, 0, 105)
		})
		tween:Play()
		
		wait(0.1)
		toggleButton.Visible = true
		speedFrame.Visible = true
		minimizeButton.Text = "—"
	end
end)

-- Movement state tracking
local moveState = {
	forward = 0,
	backward = 0,
	left = 0,
	right = 0
}

-- Input connections storage
local inputConnections = {}

-- Flight functionality
local function toggleFlight()
	flying = not flying
	toggleButton.Text = flying and "FLY: ON" or "FLY: OFF"
	-- Keep button black with transparency change only
	toggleButton.BackgroundTransparency = flying and 0.4 or 0.6
	
	if flying then
		-- Make character jump before starting flight
		humanoid:ChangeState(Enum.HumanoidStateType.Jumping)
		wait(0.1) -- Small delay to let jump start
		
		Workspace.Gravity = 0
		humanoid.PlatformStand = true
		
		-- Start with idle animation
		lastDirection = "idle"
		PlayAnim(10714347256, 4, 0)
		
		local bg = Instance.new("BodyGyro")
		bg.Name = "FlyGyro"
		bg.P = 90000
		bg.maxTorque = Vector3.new(8999999488, 8999999488, 8999999488)
		bg.CFrame = rootPart.CFrame
		bg.Parent = rootPart
		
		local bv = Instance.new("BodyVelocity")
		bv.Name = "FlyVelocity"
		bv.Velocity = Vector3.new(0, 0.1, 0)
		bv.MaxForce = Vector3.new(8999999488, 8999999488, 8999999488)
		bv.Parent = rootPart
		
		-- Input handling for both PC and Mobile
		local function onInputBegan(input, gameProcessed)
			if gameProcessed then return end
			if input.UserInputType == Enum.UserInputType.Keyboard then
				if input.KeyCode == Enum.KeyCode.W then
					moveState.forward = 1
				elseif input.KeyCode == Enum.KeyCode.S then
					moveState.backward = 1
				elseif input.KeyCode == Enum.KeyCode.A then
					moveState.left = 1
				elseif input.KeyCode == Enum.KeyCode.D then
					moveState.right = 1
				end
			end
		end
		
		local function onInputEnded(input, gameProcessed)
			if input.UserInputType == Enum.UserInputType.Keyboard then
				if input.KeyCode == Enum.KeyCode.W then
					moveState.forward = 0
				elseif input.KeyCode == Enum.KeyCode.S then
					moveState.backward = 0
				elseif input.KeyCode == Enum.KeyCode.A then
					moveState.left = 0
				elseif input.KeyCode == Enum.KeyCode.D then
					moveState.right = 0
				end
			end
		end
		
		-- Store connections for cleanup
		inputConnections.inputBegan = UserInputService.InputBegan:Connect(onInputBegan)
		inputConnections.inputEnded = UserInputService.InputEnded:Connect(onInputEnded)
		
		RunService:BindToRenderStep("Fly", Enum.RenderPriority.Camera.Value, function(dt)
			local camera = Workspace.CurrentCamera
			
			-- Get movement from both touch controls and keyboard
			local moveVector = Controls:GetMoveVector()
			local fwd = moveState.forward - moveState.backward + (-moveVector.Z)
			local side = moveState.right - moveState.left + moveVector.X
			
			-- Check if we're actually moving (more sensitive detection)
			local isMoving = math.abs(fwd) > 0.05 or math.abs(side) > 0.05
			
			-- Update animations based on movement with proper state management
			local newDirection = "idle"
			
			if isMoving then
				if fwd > 0.05 then
					newDirection = "forward"
				elseif fwd < -0.05 then
					newDirection = "backward"
				elseif math.abs(side) > 0.05 then
					newDirection = "strafe"
				end
			end
			
			-- Only change animation if direction actually changed
			if newDirection ~= lastDirection then
				lastDirection = newDirection
				
				if newDirection == "forward" then
					PlayAnim(10714177846, 4.65, 0)
				elseif newDirection == "backward" then
					PlayAnim(10147823318, 4.11, 0)
				elseif newDirection == "strafe" then
					PlayAnim(10714177846, 4.65, 0)
				else -- idle
					PlayAnim(10714347256, 4, 0)
				end
			end
			
			-- Calculate movement
			local inputVec = (camera.CFrame.LookVector * fwd) + (camera.CFrame.RightVector * side)
			
			local targetVelocity
			if inputVec.Magnitude > 0 then
				targetVelocity = inputVec.Unit * flySpeed
				-- Add slight upward movement when going forward
				if fwd > 0 then
					targetVelocity = targetVelocity + Vector3.new(0, fwd * 0.2 * flySpeed, 0)
				end
			else
				-- Floating animation when idle - made more noticeable
				local t = tick()
				local floatOffset = math.sin(t * 3) * 2 -- Increased amplitude and frequency
				targetVelocity = Vector3.new(0, 0.1 + floatOffset, 0)
			end
			
			-- Less smooth movement - reduced lerp factor for velocity
			bv.Velocity = bv.Velocity:Lerp(targetVelocity, 0.25) -- Increased from 0.1 to 0.25
			
			-- Body rotation - less smooth
			local forwardTilt = 0
			local sideTilt = side * -45
			
			if fwd > 0.05 then
				forwardTilt = -90
			elseif fwd < -0.05 then
				forwardTilt = 45
			end
			
			local targetCFrame = camera.CFrame * CFrame.Angles(math.rad(forwardTilt), 0, math.rad(sideTilt))
			-- Less smooth rotation - increased lerp factor
			bg.CFrame = bg.CFrame:Lerp(targetCFrame, 0.2) -- Increased from 0.1 to 0.2
		end)
		
	else
		Workspace.Gravity = originalGravity
		humanoid.PlatformStand = false
		lastDirection = "none"
		moveState = {forward = 0, backward = 0, left = 0, right = 0}
		StopAnim()
		
		-- Clean up connections
		for name, connection in pairs(inputConnections) do
			if connection then
				connection:Disconnect()
			end
		end
		inputConnections = {}
		
		if rootPart:FindFirstChild("FlyGyro") then rootPart.FlyGyro:Destroy() end
		if rootPart:FindFirstChild("FlyVelocity") then rootPart.FlyVelocity:Destroy() end
		RunService:UnbindFromRenderStep("Fly")
	end
end

-- Connect toggle button
toggleButton.MouseButton1Click:Connect(toggleFlight)

-- Close button functionality
closeButton.MouseButton1Click:Connect(function()
	if flying then
		toggleFlight() -- Turn off fly if it's on
	end
	flyGui:Destroy()
end)

-- Character respawn handling
player.CharacterAdded:Connect(function(newCharacter)
	character = newCharacter
	humanoid = character:WaitForChild("Humanoid")
	rootPart = character:WaitForChild("HumanoidRootPart")
	animateScriptDisabled = false
	currentAnim = nil
	currentAnimTrack = nil
	lastDirection = "none"
	
	if flying then
		flying = false
		toggleButton.Text = "FLY: OFF"
		toggleButton.BackgroundTransparency = 0.6
		Workspace.Gravity = originalGravity
		
		-- Clean up connections
		for name, connection in pairs(inputConnections) do
			if connection then
				connection:Disconnect()
			end
		end
		inputConnections = {}
		
		RunService:UnbindFromRenderStep("Fly")
	end
end)
