local addedCommands = {
"!antikidnap - Prevents others from kidnapping you. (MIC UP)"
"!secretplace - teleports you to a secret place. (MIC UP)"
}

local removedCommands = {
}

local updatedCommands = {
}

local Players = game:GetService("Players")
local TweenService = game:GetService("TweenService")

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

local screenGui = Instance.new("ScreenGui")
screenGui.Name = "AKAdminLogs"
screenGui.Parent = playerGui

local mainFrame = Instance.new("Frame")
mainFrame.Name = "MainFrame"
mainFrame.Size = UDim2.new(0, 600, 0, 150) -- Reduced from 250 to 150
mainFrame.Position = UDim2.new(0.5, -300, 0, -150) -- Adjusted initial position
mainFrame.BackgroundColor3 = Color3.fromRGB(15, 15, 15)
mainFrame.BackgroundTransparency = 0.15
mainFrame.BorderSizePixel = 0
mainFrame.Parent = screenGui

local mainCorner = Instance.new("UICorner")
mainCorner.CornerRadius = UDim.new(0, 12)
mainCorner.Parent = mainFrame

local mainStroke = Instance.new("UIStroke")
mainStroke.Color = Color3.fromRGB(40, 40, 40)
mainStroke.Thickness = 1
mainStroke.Parent = mainFrame

local headerFrame = Instance.new("Frame")
headerFrame.Name = "HeaderFrame"
headerFrame.Size = UDim2.new(1, 0, 0, 45)
headerFrame.Position = UDim2.new(0, 0, 0, 0)
headerFrame.BackgroundColor3 = Color3.fromRGB(25, 25, 25)
headerFrame.BackgroundTransparency = 0.3
headerFrame.BorderSizePixel = 0
headerFrame.Parent = mainFrame

local headerCorner = Instance.new("UICorner")
headerCorner.CornerRadius = UDim.new(0, 12)
headerCorner.Parent = headerFrame

local headerMask = Instance.new("Frame")
headerMask.Size = UDim2.new(1, 0, 0, 12)
headerMask.Position = UDim2.new(0, 0, 1, -12)
headerMask.BackgroundColor3 = Color3.fromRGB(25, 25, 25)
headerMask.BackgroundTransparency = 0.3
headerMask.BorderSizePixel = 0
headerMask.Parent = headerFrame

local closeButton = Instance.new("TextButton")
closeButton.Name = "CloseButton"
closeButton.Size = UDim2.new(0, 25, 0, 25)
closeButton.Position = UDim2.new(1, -35, 0, 10)
closeButton.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
closeButton.BackgroundTransparency = 0.3
closeButton.BorderSizePixel = 0
closeButton.Text = "×"
closeButton.TextColor3 = Color3.fromRGB(255, 255, 255)
closeButton.TextSize = 16
closeButton.Font = Enum.Font.GothamBold
closeButton.Parent = headerFrame

local closeCorner = Instance.new("UICorner")
closeCorner.CornerRadius = UDim.new(0, 6)
closeCorner.Parent = closeButton

local titleLabel = Instance.new("TextLabel")
titleLabel.Name = "TitleLabel"
titleLabel.Size = UDim2.new(0, 80, 0, 16)
titleLabel.Position = UDim2.new(0, 15, 0, 8)
titleLabel.BackgroundTransparency = 1
titleLabel.Text = "AK ADMIN"
titleLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
titleLabel.TextSize = 14
titleLabel.Font = Enum.Font.GothamBold
titleLabel.TextXAlignment = Enum.TextXAlignment.Left
titleLabel.Parent = headerFrame

local subtitleLabel = Instance.new("TextLabel")
subtitleLabel.Name = "SubtitleLabel"
subtitleLabel.Size = UDim2.new(0, 80, 0, 12)
subtitleLabel.Position = UDim2.new(0, 15, 0, 24)
subtitleLabel.BackgroundTransparency = 1
subtitleLabel.Text = "UPDATE LOGS"
subtitleLabel.TextColor3 = Color3.fromRGB(160, 160, 160)
subtitleLabel.TextSize = 10
subtitleLabel.Font = Enum.Font.Gotham
subtitleLabel.TextXAlignment = Enum.TextXAlignment.Left
subtitleLabel.Parent = headerFrame

local contentFrame = Instance.new("Frame")
contentFrame.Name = "ContentFrame"
contentFrame.Size = UDim2.new(1, -16, 1, -55)
contentFrame.Position = UDim2.new(0, 8, 0, 50)
contentFrame.BackgroundTransparency = 1
contentFrame.Parent = mainFrame

local currentTween = nil

local function createSectionColumn(title, color, position, size)
    local column = Instance.new("Frame")
    column.Name = title .. "Column"
    column.Size = size
    column.Position = position
    column.BackgroundTransparency = 1
    column.Parent = contentFrame
    
    local header = Instance.new("TextLabel")
    header.Name = "Header"
    header.Size = UDim2.new(1, 0, 0, 22)
    header.Position = UDim2.new(0, 0, 0, 0)
    header.BackgroundTransparency = 1
    header.Text = title
    header.TextColor3 = color
    header.TextSize = 13
    header.Font = Enum.Font.GothamSemibold
    header.TextXAlignment = Enum.TextXAlignment.Left
    header.TextYAlignment = Enum.TextYAlignment.Center
    header.Parent = column
    
    local underline = Instance.new("Frame")
    underline.Size = UDim2.new(0, 30, 0, 1)
    underline.Position = UDim2.new(0, 0, 0, 21)
    underline.BackgroundColor3 = color
    underline.BackgroundTransparency = 0.5
    underline.BorderSizePixel = 0
    underline.Parent = column
    
    local scrollFrame = Instance.new("ScrollingFrame")
    scrollFrame.Name = "ScrollFrame"
    scrollFrame.Size = UDim2.new(1, -5, 1, -28)
    scrollFrame.Position = UDim2.new(0, 0, 0, 25)
    scrollFrame.BackgroundTransparency = 1
    scrollFrame.BorderSizePixel = 0
    scrollFrame.ScrollBarThickness = 3
    scrollFrame.ScrollBarImageColor3 = Color3.fromRGB(80, 80, 80)
    scrollFrame.ScrollBarImageTransparency = 0.5
    scrollFrame.Parent = column
    
    local listLayout = Instance.new("UIListLayout")
    listLayout.SortOrder = Enum.SortOrder.LayoutOrder
    listLayout.Padding = UDim.new(0, 2)
    listLayout.Parent = scrollFrame
    
    listLayout:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
        scrollFrame.CanvasSize = UDim2.new(0, 0, 0, listLayout.AbsoluteContentSize.Y + 5)
    end)
    
    return column, scrollFrame
end

local function createLogEntry(text, color)
    local entry = Instance.new("TextLabel")
    entry.Size = UDim2.new(1, 0, 0, 18)
    entry.BackgroundTransparency = 1
    entry.Text = "• " .. text
    entry.TextColor3 = color
    entry.TextSize = 11
    entry.Font = Enum.Font.Gotham
    entry.TextXAlignment = Enum.TextXAlignment.Left
    entry.TextYAlignment = Enum.TextYAlignment.Center
    entry.TextTransparency = 0.1
    entry.TextWrapped = true
    return entry
end

local function calculateOptimalHeight(addedCount, removedCount, updatedCount)
    local headerHeight = 45
    local contentPadding = 55 -- Space for content frame positioning and padding
    local sectionHeaderHeight = 25 -- Header + underline + spacing
    local entryHeight = 20 -- 18 for entry + 2 for padding
    local minContentHeight = 50 -- Minimum content height
    
    local totalEntries = addedCount + removedCount + updatedCount
    
    if totalEntries == 0 then
        return headerHeight + minContentHeight
    end
    
    -- Calculate content height needed
    local contentHeight = sectionHeaderHeight + (totalEntries * entryHeight) + 10 -- Extra padding
    contentHeight = math.max(contentHeight, minContentHeight)
    
    return headerHeight + contentHeight
end

local function addLogs(added, removed, updated)
    for _, child in pairs(contentFrame:GetChildren()) do
        if child:IsA("Frame") then
            child:Destroy()
        end
    end
    
    local processedLogs = {}
    
    if added then
        for _, command in pairs(added) do
            table.insert(processedLogs, "+" .. command)
        end
    end
    
    if removed then
        for _, command in pairs(removed) do
            table.insert(processedLogs, "-" .. command)
        end
    end
    
    if updated then
        for _, command in pairs(updated) do
            table.insert(processedLogs, "=" .. command)
        end
    end
    
    local addedCommandsList = {}
    local removedCommandsList = {}
    local updatedCommandsList = {}
    
    for _, log in pairs(processedLogs) do
        local symbol = string.sub(log, 1, 1)
        local command = string.sub(log, 2)
        
        if symbol == "+" then
            table.insert(addedCommandsList, command)
        elseif symbol == "-" then
            table.insert(removedCommandsList, command)
        elseif symbol == "=" then
            table.insert(updatedCommandsList, command)
        end
    end
    
    local sections = {}
    if #addedCommandsList > 0 then
        table.insert(sections, {
            title = #addedCommandsList == 1 and "Added Command" or "Added Commands",
            color = Color3.fromRGB(76, 175, 80),
            entryColor = Color3.fromRGB(129, 199, 132),
            commands = addedCommandsList
        })
    end
    if #removedCommandsList > 0 then
        table.insert(sections, {
            title = #removedCommandsList == 1 and "Removed Command" or "Removed Commands",
            color = Color3.fromRGB(244, 67, 54),
            entryColor = Color3.fromRGB(239, 118, 108),
            commands = removedCommandsList
        })
    end
    if #updatedCommandsList > 0 then
        table.insert(sections, {
            title = #updatedCommandsList == 1 and "Updated Command" or "Updated Commands",
            color = Color3.fromRGB(255, 193, 7),
            entryColor = Color3.fromRGB(255, 213, 79),
            commands = updatedCommandsList
        })
    end
    
    local newWidth = #sections > 0 and math.max(300, #sections * 200) or 300
    local newHeight = calculateOptimalHeight(#addedCommandsList, #removedCommandsList, #updatedCommandsList)
    
    if currentTween then
        currentTween:Cancel()
    end
    
    currentTween = TweenService:Create(
        mainFrame,
        TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
        {
            Size = UDim2.new(0, newWidth, 0, newHeight),
            Position = UDim2.new(0.5, -newWidth/2, mainFrame.Position.Y.Scale, mainFrame.Position.Y.Offset)
        }
    )
    currentTween:Play()
    
    if #sections > 0 then
        for i, section in pairs(sections) do
            local columnWidth = 1 / #sections
            local columnPosition = (i - 1) * columnWidth
            
            local column, scrollFrame = createSectionColumn(
                section.title,
                section.color,
                UDim2.new(columnPosition, 5, 0, 0),
                UDim2.new(columnWidth, -10, 1, 0)
            )
            
            for j, command in pairs(section.commands) do
                local entry = createLogEntry(command, section.entryColor)
                entry.LayoutOrder = j
                entry.Parent = scrollFrame
            end
        end
    else
        local placeholderLabel = Instance.new("TextLabel")
        placeholderLabel.Size = UDim2.new(1, 0, 1, 0)
        placeholderLabel.Position = UDim2.new(0, 0, 0, 0)
        placeholderLabel.BackgroundTransparency = 1
        placeholderLabel.Text = "No updates to display"
        placeholderLabel.TextColor3 = Color3.fromRGB(120, 120, 120)
        placeholderLabel.TextSize = 12
        placeholderLabel.Font = Enum.Font.Gotham
        placeholderLabel.TextXAlignment = Enum.TextXAlignment.Center
        placeholderLabel.TextYAlignment = Enum.TextYAlignment.Center
        placeholderLabel.Parent = contentFrame
    end
end

local function slideIn()
    if currentTween then
        currentTween:Cancel()
    end
    
    currentTween = TweenService:Create(
        mainFrame,
        TweenInfo.new(0.6, Enum.EasingStyle.Back, Enum.EasingDirection.Out),
        {Position = UDim2.new(0.5, -mainFrame.Size.X.Offset/2, 0, 50)}
    )
    currentTween:Play()
end

local function slideOut()
    if currentTween then
        currentTween:Cancel()
    end
    
    currentTween = TweenService:Create(
        mainFrame,
        TweenInfo.new(0.4, Enum.EasingStyle.Back, Enum.EasingDirection.In),
        {Position = UDim2.new(0.5, -mainFrame.Size.X.Offset/2, 0, -mainFrame.Size.Y.Offset)}
    )
    currentTween:Play()
    
    currentTween.Completed:Connect(function()
        screenGui:Destroy()
    end)
end

local closeButtonPressed = false
closeButton.MouseButton1Click:Connect(function()
    if closeButtonPressed then return end
    closeButtonPressed = true
    
    local pressDown = TweenService:Create(closeButton, TweenInfo.new(0.1), {Size = UDim2.new(0, 23, 0, 23)})
    local pressUp = TweenService:Create(closeButton, TweenInfo.new(0.1), {Size = UDim2.new(0, 25, 0, 25)})
    
    pressDown:Play()
    pressDown.Completed:Connect(function()
        pressUp:Play()
        pressUp.Completed:Connect(function()
            slideOut()
        end)
    end)
end)

closeButton.MouseEnter:Connect(function()
    if closeButtonPressed then return end
    local hoverTween = TweenService:Create(closeButton, TweenInfo.new(0.2), {BackgroundColor3 = Color3.fromRGB(220, 53, 69)})
    hoverTween:Play()
end)

closeButton.MouseLeave:Connect(function()
    if closeButtonPressed then return end
    local leaveTween = TweenService:Create(closeButton, TweenInfo.new(0.2), {BackgroundColor3 = Color3.fromRGB(40, 40, 40)})
    leaveTween:Play()
end)

local dragging = false
local dragStart = nil
local startPos = nil
local dragConnection = nil

headerFrame.InputBegan:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1 and not closeButtonPressed then
        dragging = true
        dragStart = input.Position
        startPos = mainFrame.Position
        
        if dragConnection then
            dragConnection:Disconnect()
        end
        
        dragConnection = input.Changed:Connect(function()
            if input.UserInputState == Enum.UserInputState.End then
                dragging = false
                if dragConnection then
                    dragConnection:Disconnect()
                    dragConnection = nil
                end
            end
        end)
    end
end)

headerFrame.InputChanged:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseMovement and dragging and not closeButtonPressed then
        local delta = input.Position - dragStart
        local newPosition = UDim2.new(
            startPos.X.Scale, 
            startPos.X.Offset + delta.X, 
            startPos.Y.Scale, 
            startPos.Y.Offset + delta.Y
        )
        mainFrame.Position = newPosition
    end
end)

wait(0.2)
addLogs(addedCommands, removedCommands, updatedCommands)
wait(0.1)
slideIn()
