-- Gui made by VR_official
-- Admin made by urmoml0l
-- enjoy skids.l

local ScreenGui_FREE = Instance.new("ScreenGui")
local main = Instance.new("Frame")
local UICorner = Instance.new("UICorner")
local ScrollingFrame = Instance.new("ScrollingFrame")
local UIGridLayout = Instance.new("UIGridLayout")
local boomboxraid = Instance.new("TextLabel")
local hub = Instance.new("TextLabel")
local emoji = Instance.new("TextLabel")
local crash = Instance.new("TextLabel")
local pltiger = Instance.new("TextLabel")
local f3x = Instance.new("TextLabel")
local IY = Instance.new("TextLabel")
local AFK = Instance.new("TextLabel")
local rejoin = Instance.new("TextLabel")
local serverhop = Instance.new("TextLabel")
local oof = Instance.new("TextLabel")
local gimmetools = Instance.new("TextLabel")
local FTAO = Instance.new("TextLabel")
local swordreach = Instance.new("TextLabel")
local Title = Instance.new("TextLabel")
local Title_2 = Instance.new("TextLabel")
local X = Instance.new("TextButton")
local UICorner_2 = Instance.new("UICorner")

--Properties:

ScreenGui_FREE.Name = "ScreenGui_FREE"
ScreenGui_FREE.Parent = game.CoreGui
ScreenGui_FREE.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

main.Name = "main"
main.Parent = ScreenGui_FREE
main.BackgroundColor3 = Color3.fromRGB(44, 44, 44)
main.BorderColor3 = Color3.fromRGB(0, 0, 0)
main.BorderSizePixel = 0
main.Position = UDim2.new(0.766267598, 0, 0.0950617269, 0)
main.Size = UDim2.new(0, 255, 0, 440)
main.Visible = false
main.Active = true
main.Draggable = true

UICorner.CornerRadius = UDim.new(0, 6)
UICorner.Parent = main

ScrollingFrame.Parent = main
ScrollingFrame.Active = true
ScrollingFrame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ScrollingFrame.BackgroundTransparency = 1.000
ScrollingFrame.BorderColor3 = Color3.fromRGB(0, 0, 0)
ScrollingFrame.BorderSizePixel = 0
ScrollingFrame.Position = UDim2.new(0, 0, 0.0741524473, 0)
ScrollingFrame.Size = UDim2.new(0, 256, 0, 407)

UIGridLayout.Parent = ScrollingFrame
UIGridLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center
UIGridLayout.SortOrder = Enum.SortOrder.LayoutOrder
UIGridLayout.CellPadding = UDim2.new(0.00999999978, 0, 0.00999999978, 0)
UIGridLayout.CellSize = UDim2.new(0, 200, 0, 50)

boomboxraid.Name = "boomboxraid"
boomboxraid.Parent = ScrollingFrame
boomboxraid.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
boomboxraid.BackgroundTransparency = 1.000
boomboxraid.BorderColor3 = Color3.fromRGB(208, 21, 255)
boomboxraid.BorderSizePixel = 0
boomboxraid.Position = UDim2.new(0, 0, 0.14678897, 0)
boomboxraid.Size = UDim2.new(0, 243, 0, 39)
boomboxraid.Font = Enum.Font.LuckiestGuy
boomboxraid.Text = "DOLLHOUSE ROLEPLAY VC            /BOOMBOXRAID"
boomboxraid.TextColor3 = Color3.fromRGB(255, 255, 255)
boomboxraid.TextScaled = true
boomboxraid.TextSize = 14.000
boomboxraid.TextWrapped = true

hub.Name = "hub"
hub.Parent = ScrollingFrame
hub.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
hub.BackgroundTransparency = 1.000
hub.BorderColor3 = Color3.fromRGB(208, 21, 255)
hub.BorderSizePixel = 0
hub.Position = UDim2.new(0, 0, 0.14678897, 0)
hub.Size = UDim2.new(0, 243, 0, 39)
hub.Font = Enum.Font.LuckiestGuy
hub.Text = "UNIVERSAL            /HUB"
hub.TextColor3 = Color3.fromRGB(255, 255, 255)
hub.TextSize = 21.000
hub.TextWrapped = true

emoji.Name = "emoji"
emoji.Parent = ScrollingFrame
emoji.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
emoji.BackgroundTransparency = 1.000
emoji.BorderColor3 = Color3.fromRGB(208, 21, 255)
emoji.BorderSizePixel = 0
emoji.Position = UDim2.new(0, 0, 0.14678897, 0)
emoji.Size = UDim2.new(0, 243, 0, 39)
emoji.Font = Enum.Font.LuckiestGuy
emoji.Text = "UNIVERSAL            /EMOJI"
emoji.TextColor3 = Color3.fromRGB(255, 255, 255)
emoji.TextSize = 21.000
emoji.TextWrapped = true

crash.Name = "crash"
crash.Parent = ScrollingFrame
crash.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
crash.BackgroundTransparency = 1.000
crash.BorderColor3 = Color3.fromRGB(208, 21, 255)
crash.BorderSizePixel = 0
crash.Position = UDim2.new(0, 0, 0.14678897, 0)
crash.Size = UDim2.new(0, 243, 0, 39)
crash.Font = Enum.Font.LuckiestGuy
crash.Text = "DOLLHOUSE ROLEPLAY VC                              /CRASH"
crash.TextColor3 = Color3.fromRGB(255, 255, 255)
crash.TextScaled = true
crash.TextSize = 18.000
crash.TextWrapped = true

pltiger.Name = "pltiger"
pltiger.Parent = ScrollingFrame
pltiger.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
pltiger.BackgroundTransparency = 1.000
pltiger.BorderColor3 = Color3.fromRGB(208, 21, 255)
pltiger.BorderSizePixel = 0
pltiger.Position = UDim2.new(0, 0, 0.14678897, 0)
pltiger.Size = UDim2.new(0, 243, 0, 39)
pltiger.Font = Enum.Font.LuckiestGuy
pltiger.Text = "PRISON LIFE                             /PLTIGER"
pltiger.TextColor3 = Color3.fromRGB(255, 255, 255)
pltiger.TextSize = 21.000
pltiger.TextWrapped = true

f3x.Name = "f3x"
f3x.Parent = ScrollingFrame
f3x.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
f3x.BackgroundTransparency = 1.000
f3x.BorderColor3 = Color3.fromRGB(208, 21, 255)
f3x.BorderSizePixel = 0
f3x.Position = UDim2.new(0, 0, 0.14678897, 0)
f3x.Size = UDim2.new(0, 243, 0, 39)
f3x.Font = Enum.Font.LuckiestGuy
f3x.Text = "SWORD FIGHT ON THE HEIGHTS                                    /F3X"
f3x.TextColor3 = Color3.fromRGB(255, 255, 255)
f3x.TextScaled = true
f3x.TextSize = 21.000
f3x.TextWrapped = true

IY.Name = "IY"
IY.Parent = ScrollingFrame
IY.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
IY.BackgroundTransparency = 1.000
IY.BorderColor3 = Color3.fromRGB(208, 21, 255)
IY.BorderSizePixel = 0
IY.Position = UDim2.new(0, 0, 0.14678897, 0)
IY.Size = UDim2.new(0, 243, 0, 39)
IY.Font = Enum.Font.LuckiestGuy
IY.Text = "UNIVERSAL                             /IY"
IY.TextColor3 = Color3.fromRGB(255, 255, 255)
IY.TextSize = 21.000
IY.TextWrapped = true

AFK.Name = "AFK"
AFK.Parent = ScrollingFrame
AFK.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
AFK.BackgroundTransparency = 1.000
AFK.BorderColor3 = Color3.fromRGB(208, 21, 255)
AFK.BorderSizePixel = 0
AFK.Position = UDim2.new(0, 0, 0.14678897, 0)
AFK.Size = UDim2.new(0, 243, 0, 39)
AFK.Font = Enum.Font.LuckiestGuy
AFK.Text = "UNIVERSAL                             /AFK"
AFK.TextColor3 = Color3.fromRGB(255, 255, 255)
AFK.TextSize = 21.000
AFK.TextWrapped = true

rejoin.Name = "rejoin"
rejoin.Parent = ScrollingFrame
rejoin.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
rejoin.BackgroundTransparency = 1.000
rejoin.BorderColor3 = Color3.fromRGB(208, 21, 255)
rejoin.BorderSizePixel = 0
rejoin.Position = UDim2.new(0, 0, 0.14678897, 0)
rejoin.Size = UDim2.new(0, 243, 0, 39)
rejoin.Font = Enum.Font.LuckiestGuy
rejoin.Text = "UNIVERSAL                             /rejoin"
rejoin.TextColor3 = Color3.fromRGB(255, 255, 255)
rejoin.TextSize = 21.000
rejoin.TextWrapped = true

serverhop.Name = "serverhop"
serverhop.Parent = ScrollingFrame
serverhop.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
serverhop.BackgroundTransparency = 1.000
serverhop.BorderColor3 = Color3.fromRGB(208, 21, 255)
serverhop.BorderSizePixel = 0
serverhop.Position = UDim2.new(0, 0, 0.14678897, 0)
serverhop.Size = UDim2.new(0, 243, 0, 39)
serverhop.Font = Enum.Font.LuckiestGuy
serverhop.Text = "UNIVERSAL                             /serverhop"
serverhop.TextColor3 = Color3.fromRGB(255, 255, 255)
serverhop.TextSize = 21.000
serverhop.TextWrapped = true

oof.Name = "oof"
oof.Parent = ScrollingFrame
oof.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
oof.BackgroundTransparency = 1.000
oof.BorderColor3 = Color3.fromRGB(208, 21, 255)
oof.BorderSizePixel = 0
oof.Position = UDim2.new(0, 0, 0.14678897, 0)
oof.Size = UDim2.new(0, 243, 0, 39)
oof.Font = Enum.Font.LuckiestGuy
oof.Text = "UNIVERSAL                             /oof"
oof.TextColor3 = Color3.fromRGB(255, 255, 255)
oof.TextSize = 21.000
oof.TextWrapped = true

gimmetools.Name = "gimmetools"
gimmetools.Parent = ScrollingFrame
gimmetools.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
gimmetools.BackgroundTransparency = 1.000
gimmetools.BorderColor3 = Color3.fromRGB(208, 21, 255)
gimmetools.BorderSizePixel = 0
gimmetools.Position = UDim2.new(0, 0, 0.14678897, 0)
gimmetools.Size = UDim2.new(0, 243, 0, 39)
gimmetools.Font = Enum.Font.LuckiestGuy
gimmetools.Text = "UNIVERSAL                             /gimmetools"
gimmetools.TextColor3 = Color3.fromRGB(255, 255, 255)
gimmetools.TextSize = 21.000
gimmetools.TextWrapped = true

FTAO.Name = "FTAO"
FTAO.Parent = ScrollingFrame
FTAO.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
FTAO.BackgroundTransparency = 1.000
FTAO.BorderColor3 = Color3.fromRGB(208, 21, 255)
FTAO.BorderSizePixel = 0
FTAO.Position = UDim2.new(0, 0, 0.14678897, 0)
FTAO.Size = UDim2.new(0, 243, 0, 39)
FTAO.Font = Enum.Font.LuckiestGuy
FTAO.Text = "FLING THINGS AND OTHERS                                        /FTAO"
FTAO.TextColor3 = Color3.fromRGB(255, 255, 255)
FTAO.TextScaled = true
FTAO.TextSize = 21.000
FTAO.TextWrapped = true

swordreach.Name = "sword reach"
swordreach.Parent = ScrollingFrame
swordreach.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
swordreach.BackgroundTransparency = 1.000
swordreach.BorderColor3 = Color3.fromRGB(208, 21, 255)
swordreach.BorderSizePixel = 0
swordreach.Position = UDim2.new(0, 0, 0.14678897, 0)
swordreach.Size = UDim2.new(0, 243, 0, 39)
swordreach.Font = Enum.Font.LuckiestGuy
swordreach.Text = "UNIVERSAL                             /SWORDREACH"
swordreach.TextColor3 = Color3.fromRGB(255, 255, 255)
swordreach.TextSize = 21.000
swordreach.TextWrapped = true

Title.Name = "Title"
Title.Parent = main
Title.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Title.BackgroundTransparency = 1.000
Title.BorderColor3 = Color3.fromRGB(0, 0, 0)
Title.BorderSizePixel = 0
Title.Position = UDim2.new(0.0822887421, 0, 0.0186989829, 0)
Title.Size = UDim2.new(0, 243, 0, 28)
Title.Font = Enum.Font.LuckiestGuy
Title.Text = "AK ADMIN"
Title.TextColor3 = Color3.fromRGB(255, 0, 4)
Title.TextScaled = true
Title.TextSize = 14.000
Title.TextWrapped = true

Title_2.Name = "Title"
Title_2.Parent = main
Title_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Title_2.BackgroundTransparency = 1.000
Title_2.BorderColor3 = Color3.fromRGB(0, 0, 0)
Title_2.BorderSizePixel = 0
Title_2.Position = UDim2.new(-0.312242508, 0, 0.0186989829, 0)
Title_2.Size = UDim2.new(0, 243, 0, 28)
Title_2.Font = Enum.Font.LuckiestGuy
Title_2.Text = "FREE"
Title_2.TextColor3 = Color3.fromRGB(0, 255, 8)
Title_2.TextScaled = true
Title_2.TextSize = 14.000
Title_2.TextWrapped = true

X.Name = "X"
X.Parent = ScreenGui_FREE
X.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
X.BackgroundTransparency = 0.500
X.BorderColor3 = Color3.fromRGB(0, 0, 0)
X.BorderSizePixel = 0
X.Position = UDim2.new(0.881565928, 0, 0.0979516134, 0)
X.Size = UDim2.new(0, 34, 0, 28)
X.Font = Enum.Font.FredokaOne
X.Text = "X"
X.TextColor3 = Color3.fromRGB(0, 0, 0)
X.TextScaled = true
X.TextSize = 14.000
X.TextStrokeTransparency = 0.000
X.TextWrapped = true
X.Active = true
X.Draggable = true

UICorner_2.Parent = X

-- Scripts:

local function ULHFBV_fake_script() -- ScreenGui_FREE.LocalScript 
	local script = Instance.new('LocalScript', ScreenGui_FREE)

	local SGui = script.Parent
	local Frame = SGui:WaitForChild("main")
	local Button = SGui:WaitForChild("X")
	
	Button.MouseButton1Up:Connect(function()
		Frame.Visible = not Frame.Visible
	end)
end
coroutine.wrap(ULHFBV_fake_script)()
