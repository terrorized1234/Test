loadstring(game:HttpGet("https://raw.githubusercontent.com/Alikhammass/MyAdmin/main/Ak%20Admin"))()
