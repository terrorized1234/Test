-- Professional Lighting Control GUI Script
local Players = game:GetService("Players")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local Light = game:GetService("Lighting")

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

-- GUI Variables
local screenGui
local mainFrame
local titleBar
local contentFrame
local closeButton
local switchFrame
local switchKnob
local switchLabel
local doNotAskButton

-- State variables
local isLightingEnabled = false
local originalLightingSettings = {}

-- Lighting effects storage
local lightingEffects = {}

-- Settings file name
local SETTINGS_FILE = "shader_settings.txt"

-- Check if user has enabled "do not ask again"
local function shouldAutoLoad()
    local success, result = pcall(function()
        return readfile(SETTINGS_FILE)
    end)
    
    if success and result then
        return result:find("do_not_ask=true") ~= nil
    end
    return false
end

-- Set "do not ask again" preference
local function setDoNotAsk()
    local success = pcall(function()
        writefile(SETTINGS_FILE, "do_not_ask=true\nuser_id=" .. tostring(player.UserId) .. "\ntimestamp=" .. tostring(os.time()))
    end)
    
    if not success then
        warn("Failed to save shader settings to file")
    end
end

-- Create GUI
local function createGUI()
    screenGui = Instance.new("ScreenGui")
    screenGui.Name = "LightingControlGUI"
    screenGui.ResetOnSpawn = false
    screenGui.Parent = playerGui

    -- Main Frame - wider but shorter
    mainFrame = Instance.new("Frame")
    mainFrame.Name = "MainFrame"
    mainFrame.Size = UDim2.new(0, 320, 0, 100)
    mainFrame.Position = UDim2.new(0.5, -160, 0.1, 0)
    mainFrame.BackgroundColor3 = Color3.fromRGB(30, 30, 35)
    mainFrame.BorderSizePixel = 0
    mainFrame.Parent = screenGui

    -- Add subtle shadow effect
    local shadow = Instance.new("Frame")
    shadow.Name = "Shadow"
    shadow.Size = UDim2.new(1, 6, 1, 6)
    shadow.Position = UDim2.new(0, -3, 0, -3)
    shadow.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
    shadow.BackgroundTransparency = 0.8
    shadow.BorderSizePixel = 0
    shadow.ZIndex = mainFrame.ZIndex - 1
    shadow.Parent = mainFrame

    local shadowCorner = Instance.new("UICorner")
    shadowCorner.CornerRadius = UDim.new(0, 12)
    shadowCorner.Parent = shadow

    -- Rounded corners for main frame
    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, 10)
    corner.Parent = mainFrame

    -- Title Bar
    titleBar = Instance.new("Frame")
    titleBar.Name = "TitleBar"
    titleBar.Size = UDim2.new(1, 0, 0, 30)
    titleBar.Position = UDim2.new(0, 0, 0, 0)
    titleBar.BackgroundColor3 = Color3.fromRGB(40, 40, 45)
    titleBar.BorderSizePixel = 0
    titleBar.Parent = mainFrame

    local titleCorner = Instance.new("UICorner")
    titleCorner.CornerRadius = UDim.new(0, 10)
    titleCorner.Parent = titleBar

    -- Fix title bar corners (only top corners)
    local titleCornerFix = Instance.new("Frame")
    titleCornerFix.Size = UDim2.new(1, 0, 0, 10)
    titleCornerFix.Position = UDim2.new(0, 0, 1, -10)
    titleCornerFix.BackgroundColor3 = Color3.fromRGB(40, 40, 45)
    titleCornerFix.BorderSizePixel = 0
    titleCornerFix.Parent = titleBar

    -- Title Label
    local titleLabel = Instance.new("TextLabel")
    titleLabel.Size = UDim2.new(1, -35, 1, 0)
    titleLabel.Position = UDim2.new(0, 15, 0, 0)
    titleLabel.BackgroundTransparency = 1
    titleLabel.Text = "Shader Settings"
    titleLabel.TextColor3 = Color3.fromRGB(220, 220, 225)
    titleLabel.TextSize = 14
    titleLabel.Font = Enum.Font.GothamMedium
    titleLabel.TextXAlignment = Enum.TextXAlignment.Left
    titleLabel.Parent = titleBar

    -- Close Button
    closeButton = Instance.new("TextButton")
    closeButton.Size = UDim2.new(0, 20, 0, 20)
    closeButton.Position = UDim2.new(1, -25, 0, 5)
    closeButton.BackgroundColor3 = Color3.fromRGB(60, 40, 40)
    closeButton.Text = "×"
    closeButton.TextColor3 = Color3.fromRGB(255, 255, 255)
    closeButton.TextSize = 14
    closeButton.Font = Enum.Font.GothamBold
    closeButton.BorderSizePixel = 0
    closeButton.Parent = titleBar

    local closeCorner = Instance.new("UICorner")
    closeCorner.CornerRadius = UDim.new(0, 3)
    closeCorner.Parent = closeButton

    -- Content Frame
    contentFrame = Instance.new("Frame")
    contentFrame.Name = "ContentFrame"
    contentFrame.Size = UDim2.new(1, -20, 1, -40)
    contentFrame.Position = UDim2.new(0, 10, 0, 35)
    contentFrame.BackgroundTransparency = 1
    contentFrame.Parent = mainFrame

    -- Main content container
    local mainContent = Instance.new("Frame")
    mainContent.Size = UDim2.new(1, 0, 0, 25)
    mainContent.Position = UDim2.new(0, 0, 0, 0)
    mainContent.BackgroundTransparency = 1
    mainContent.Parent = contentFrame

    -- Switch Label
    switchLabel = Instance.new("TextLabel")
    switchLabel.Size = UDim2.new(0, 120, 1, 0)
    switchLabel.Position = UDim2.new(0, 0, 0, 0)
    switchLabel.BackgroundTransparency = 1
    switchLabel.Text = "Enable Shaders"
    switchLabel.TextColor3 = Color3.fromRGB(200, 200, 205)
    switchLabel.TextSize = 13
    switchLabel.Font = Enum.Font.Gotham
    switchLabel.TextXAlignment = Enum.TextXAlignment.Left
    switchLabel.Parent = mainContent

    -- Switch Frame (the toggle switch)
    switchFrame = Instance.new("Frame")
    switchFrame.Size = UDim2.new(0, 45, 0, 20)
    switchFrame.Position = UDim2.new(1, -45, 0, 2.5)
    switchFrame.BackgroundColor3 = Color3.fromRGB(60, 60, 65)
    switchFrame.BorderSizePixel = 0
    switchFrame.Parent = mainContent

    local switchCorner = Instance.new("UICorner")
    switchCorner.CornerRadius = UDim.new(0, 10)
    switchCorner.Parent = switchFrame

    -- Switch Knob (the sliding part)
    switchKnob = Instance.new("Frame")
    switchKnob.Size = UDim2.new(0, 16, 0, 16)
    switchKnob.Position = UDim2.new(0, 2, 0, 2)
    switchKnob.BackgroundColor3 = Color3.fromRGB(180, 180, 185)
    switchKnob.BorderSizePixel = 0
    switchKnob.Parent = switchFrame

    local knobCorner = Instance.new("UICorner")
    knobCorner.CornerRadius = UDim.new(0, 8)
    knobCorner.Parent = switchKnob

    -- Make switch clickable
    local switchButton = Instance.new("TextButton")
    switchButton.Size = UDim2.new(1, 0, 1, 0)
    switchButton.Position = UDim2.new(0, 0, 0, 0)
    switchButton.BackgroundTransparency = 1
    switchButton.Text = ""
    switchButton.Parent = switchFrame

    -- "Do not ask again" button
    doNotAskButton = Instance.new("TextButton")
    doNotAskButton.Size = UDim2.new(0, 110, 0, 18)
    doNotAskButton.Position = UDim2.new(0, 0, 1, -20)
    doNotAskButton.BackgroundColor3 = Color3.fromRGB(50, 50, 55)
    doNotAskButton.Text = "Do not ask again"
    doNotAskButton.TextColor3 = Color3.fromRGB(160, 160, 165)
    doNotAskButton.TextSize = 10
    doNotAskButton.Font = Enum.Font.Gotham
    doNotAskButton.BorderSizePixel = 0
    doNotAskButton.Parent = contentFrame

    local doNotAskCorner = Instance.new("UICorner")
    doNotAskCorner.CornerRadius = UDim.new(0, 4)
    doNotAskCorner.Parent = doNotAskButton

    return switchButton
end

-- Store original lighting settings
local function storeOriginalSettings()
    originalLightingSettings.Brightness = Light.Brightness
    originalLightingSettings.ExposureCompensation = Light.ExposureCompensation
    originalLightingSettings.ClockTime = Light.ClockTime
end

-- Apply custom lighting
local function applyCustomLighting()
    -- Clear existing effects first
    for _, effect in pairs(lightingEffects) do
        if effect and effect.Parent then
            effect:Destroy()
        end
    end
    lightingEffects = {}

    -- Create new effects
    local Sky = Instance.new("Sky")
    local Bloom = Instance.new("BloomEffect")
    local ColorC = Instance.new("ColorCorrectionEffect")
    local SunRays = Instance.new("SunRaysEffect")

    -- Configure lighting properties
    Light.Brightness = 2.25
    Light.ExposureCompensation = 0.1
    Light.ClockTime = 17.55

    -- Configure skybox
    Sky.SkyboxBk = "http://www.roblox.com/asset/?id=144933338"
    Sky.SkyboxDn = "http://www.roblox.com/asset/?id=144931530"
    Sky.SkyboxFt = "http://www.roblox.com/asset/?id=144933262"
    Sky.SkyboxLf = "http://www.roblox.com/asset/?id=144933244"
    Sky.SkyboxRt = "http://www.roblox.com/asset/?id=144933299"
    Sky.SkyboxUp = "http://www.roblox.com/asset/?id=144931564"
    Sky.StarCount = 5000
    Sky.SunAngularSize = 5
    Sky.Parent = Light

    -- Configure bloom effect
    Bloom.Intensity = 0.3
    Bloom.Size = 10
    Bloom.Threshold = 0.8
    Bloom.Parent = Light

    -- Configure color correction
    ColorC.Brightness = 0
    ColorC.Contrast = 0.1
    ColorC.Saturation = 0.25
    ColorC.TintColor = Color3.fromRGB(255, 255, 255)
    ColorC.Parent = Light

    -- Configure sun rays
    SunRays.Intensity = 0.1
    SunRays.Spread = 0.8
    SunRays.Parent = Light

    -- Store references
    lightingEffects = {Sky, Bloom, ColorC, SunRays}
end

-- Clear all custom lighting
local function clearCustomLighting()
    for _, effect in pairs(lightingEffects) do
        if effect and effect.Parent then
            effect:Destroy()
        end
    end
    lightingEffects = {}
    
    -- Reset lighting properties
    Light.Brightness = originalLightingSettings.Brightness
    Light.ExposureCompensation = originalLightingSettings.ExposureCompensation
    Light.ClockTime = originalLightingSettings.ClockTime
end

-- Animate switch
local function animateSwitch(enabled)
    local knobTarget = enabled and UDim2.new(0, 27, 0, 2) or UDim2.new(0, 2, 0, 2)
    local frameColor = enabled and Color3.fromRGB(70, 130, 70) or Color3.fromRGB(60, 60, 65)
    local knobColor = enabled and Color3.fromRGB(255, 255, 255) or Color3.fromRGB(180, 180, 185)
    
    local knobTween = TweenService:Create(
        switchKnob,
        TweenInfo.new(0.2, Enum.EasingStyle.Quad),
        {Position = knobTarget, BackgroundColor3 = knobColor}
    )
    
    local frameTween = TweenService:Create(
        switchFrame,
        TweenInfo.new(0.2, Enum.EasingStyle.Quad),
        {BackgroundColor3 = frameColor}
    )
    
    knobTween:Play()
    frameTween:Play()
end

-- Make GUI draggable
local function makeDraggable(gui)
    local dragging = false
    local dragInput, mousePos, framePos

    local function update(input)
        local delta = input.Position - mousePos
        gui.Position = UDim2.new(framePos.X.Scale, framePos.X.Offset + delta.X, framePos.Y.Scale, framePos.Y.Offset + delta.Y)
    end

    titleBar.InputBegan:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
            dragging = true
            mousePos = input.Position
            framePos = gui.Position
            
            input.Changed:Connect(function()
                if input.UserInputState == Enum.UserInputState.End then
                    dragging = false
                end
            end)
        end
    end)

    titleBar.InputChanged:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch then
            dragInput = input
        end
    end)

    UserInputService.InputChanged:Connect(function(input)
        if input == dragInput and dragging then
            update(input)
        end
    end)
end

-- Button event handlers
local function setupEventHandlers(switchButton)
    -- Switch toggle
    switchButton.MouseButton1Click:Connect(function()
        isLightingEnabled = not isLightingEnabled
        animateSwitch(isLightingEnabled)
        
        if isLightingEnabled then
            applyCustomLighting()
        else
            clearCustomLighting()
        end
    end)

    -- Close button
    closeButton.MouseButton1Click:Connect(function()
        local closeTween = TweenService:Create(
            mainFrame,
            TweenInfo.new(0.2, Enum.EasingStyle.Quad),
            {Size = UDim2.new(0, 0, 0, 0), Position = UDim2.new(0.5, 0, 0.1, 50)}
        )
        closeTween:Play()
        
        closeTween.Completed:Connect(function()
            screenGui:Destroy()
            if isLightingEnabled then
                clearCustomLighting()
            end
        end)
    end)

    -- Do not ask again button
    doNotAskButton.MouseButton1Click:Connect(function()
        setDoNotAsk()
        applyCustomLighting() -- Enable shaders
        
        -- Visual feedback
        doNotAskButton.BackgroundColor3 = Color3.fromRGB(70, 130, 70)
        doNotAskButton.Text = "✓ Saved"
        
        wait(1)
        
        local closeTween = TweenService:Create(
            mainFrame,
            TweenInfo.new(0.2, Enum.EasingStyle.Quad),
            {Size = UDim2.new(0, 0, 0, 0), Position = UDim2.new(0.5, 0, 0.1, 50)}
        )
        closeTween:Play()
        
        closeTween.Completed:Connect(function()
            screenGui:Destroy()
        end)
    end)

    -- Hover effects for close button
    closeButton.MouseEnter:Connect(function()
        TweenService:Create(closeButton, TweenInfo.new(0.1), {BackgroundColor3 = Color3.fromRGB(120, 60, 60)}):Play()
    end)

    closeButton.MouseLeave:Connect(function()
        TweenService:Create(closeButton, TweenInfo.new(0.1), {BackgroundColor3 = Color3.fromRGB(60, 40, 40)}):Play()
    end)

    -- Hover effects for do not ask button
    doNotAskButton.MouseEnter:Connect(function()
        TweenService:Create(doNotAskButton, TweenInfo.new(0.1), {BackgroundColor3 = Color3.fromRGB(60, 60, 70)}):Play()
    end)

    doNotAskButton.MouseLeave:Connect(function()
        TweenService:Create(doNotAskButton, TweenInfo.new(0.1), {BackgroundColor3 = Color3.fromRGB(50, 50, 55)}):Play()
    end)
end

-- Initialize GUI with entrance animation
local function initialize()
    -- Check if user has "do not ask again" enabled
    if shouldAutoLoad() then
        storeOriginalSettings()
        applyCustomLighting()
        return
    end
    
    storeOriginalSettings()
    local switchButton = createGUI()
    makeDraggable(mainFrame)
    setupEventHandlers(switchButton)
    
    -- Entrance animation
    mainFrame.Size = UDim2.new(0, 0, 0, 0)
    mainFrame.Position = UDim2.new(0.5, 0, 0.1, 50)
    
    local entranceTween = TweenService:Create(
        mainFrame,
        TweenInfo.new(0.3, Enum.EasingStyle.Back, Enum.EasingDirection.Out),
        {Size = UDim2.new(0, 320, 0, 100), Position = UDim2.new(0.5, -160, 0.1, 0)}
    )
    entranceTween:Play()
end

-- Run the script
initialize()
