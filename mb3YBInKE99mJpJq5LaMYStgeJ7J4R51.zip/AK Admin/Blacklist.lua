local Players = game:GetService("Players")
local RbxAnalyticsService = game:GetService("RbxAnalyticsService")
local LocalPlayer = Players.LocalPlayer

-- HWID detection with fallback
local function getHwid()
    local success, hwid = pcall(function()
        return RbxAnalyticsService:GetClientId()
    end)
    return success and hwid or "Unknown"
end

-- Blacklisted HWIDs (add HWIDs here)
local BlacklistedHWIDs = {
    "D62636BA-829B-467C-9E8B-2AAD3EC42443",
    "68BC3554-6527-4BF6-AC90-0C53DBA2CB45"
}

-- Check if player is blacklisted
local function isBlacklisted(hwid)
    for _, blacklistedHwid in ipairs(BlacklistedHWIDs) do
        if hwid == blacklistedHwid then
            return true
        end
    end
    return false
end

-- Create blacklist screen
local function showBlacklistScreen()
    -- Create ScreenGui
    local screenGui = Instance.new("ScreenGui")
    screenGui.Name = "BlacklistScreen"
    screenGui.ResetOnSpawn = false
    screenGui.IgnoreGuiInset = true
    screenGui.DisplayOrder = 999999
    screenGui.Parent = LocalPlayer:WaitForChild("PlayerGui")
    
    -- Red transparent background
    local background = Instance.new("Frame")
    background.Name = "RedBackground"
    background.Size = UDim2.new(1, 0, 1, 0)
    background.Position = UDim2.new(0, 0, 0, 0)
    background.BackgroundColor3 = Color3.fromRGB(139, 0, 0)
    background.BackgroundTransparency = 0.2
    background.BorderSizePixel = 0
    background.Parent = screenGui
    
    -- Rapid flashing effect (seizure warning vibes)
    task.spawn(function()
        while true do
            background.BackgroundTransparency = 0
            background.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
            task.wait(0.05)
            background.BackgroundTransparency = 0.4
            background.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
            task.wait(0.05)
            background.BackgroundColor3 = Color3.fromRGB(139, 0, 0)
            task.wait(0.1)
        end
    end)
    
    -- Dark vignette overlay
    local vignette = Instance.new("ImageLabel")
    vignette.Size = UDim2.new(1, 0, 1, 0)
    vignette.Position = UDim2.new(0, 0, 0, 0)
    vignette.BackgroundTransparency = 1
    vignette.Image = "rbxasset://textures/ui/VignetteOverlay.png"
    vignette.ImageColor3 = Color3.fromRGB(0, 0, 0)
    vignette.ImageTransparency = 0.1
    vignette.Parent = background
    
    -- Static/noise effect
    local static = Instance.new("Frame")
    static.Size = UDim2.new(1, 0, 1, 0)
    static.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    static.BackgroundTransparency = 0.9
    static.BorderSizePixel = 0
    static.Parent = background
    
    task.spawn(function()
        while true do
            static.BackgroundTransparency = math.random(85, 98) / 100
            task.wait(0.03)
        end
    end)
    
    -- Multiple skull overlays
    for i = 1, 8 do
        local skull = Instance.new("TextLabel")
        skull.Size = UDim2.new(0.15, 0, 0.15, 0)
        skull.Position = UDim2.new(math.random(0, 85) / 100, 0, math.random(0, 85) / 100, 0)
        skull.BackgroundTransparency = 1
        skull.Text = "☠️"
        skull.TextColor3 = Color3.fromRGB(255, 0, 0)
        skull.TextScaled = true
        skull.TextTransparency = 0.3
        skull.Rotation = math.random(-30, 30)
        skull.Parent = background
        
        task.spawn(function()
            while true do
                skull.TextTransparency = math.random(20, 80) / 100
                task.wait(0.1)
            end
        end)
    end
    
    -- Warning frame container
    local warningFrame = Instance.new("Frame")
    warningFrame.Size = UDim2.new(0.75, 0, 0.5, 0)
    warningFrame.Position = UDim2.new(0.5, 0, 0.5, 0)
    warningFrame.AnchorPoint = Vector2.new(0.5, 0.5)
    warningFrame.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
    warningFrame.BackgroundTransparency = 0.1
    warningFrame.BorderSizePixel = 8
    warningFrame.BorderColor3 = Color3.fromRGB(255, 0, 0)
    warningFrame.Parent = background
    
    -- Frame shake effect
    task.spawn(function()
        local originalPos = warningFrame.Position
        while true do
            warningFrame.Position = UDim2.new(
                originalPos.X.Scale + math.random(-5, 5) / 1000,
                0,
                originalPos.Y.Scale + math.random(-5, 5) / 1000,
                0
            )
            task.wait(0.05)
        end
    end)
    
    -- Border rapid pulsing
    task.spawn(function()
        while true do
            warningFrame.BorderColor3 = Color3.fromRGB(255, 0, 0)
            warningFrame.BorderSizePixel = 8
            task.wait(0.05)
            warningFrame.BorderColor3 = Color3.fromRGB(139, 0, 0)
            warningFrame.BorderSizePixel = 12
            task.wait(0.05)
            warningFrame.BorderColor3 = Color3.fromRGB(255, 255, 255)
            task.wait(0.05)
        end
    end)
    
    -- Blood drip effect lines
    for i = 1, 15 do
        local drip = Instance.new("Frame")
        drip.Size = UDim2.new(0.01, 0, 0, 0)
        drip.Position = UDim2.new(math.random(0, 100) / 100, 0, 0, 0)
        drip.BackgroundColor3 = Color3.fromRGB(139, 0, 0)
        drip.BorderSizePixel = 0
        drip.Parent = background
        
        task.spawn(function()
            while true do
                drip.Size = UDim2.new(0.01, 0, 0, 0)
                drip:TweenSize(UDim2.new(0.01, 0, math.random(30, 100) / 100, 0), "Out", "Linear", math.random(5, 15) / 10, false)
                task.wait(math.random(10, 30) / 10)
            end
        end)
    end
    
    -- Top skull/warning with glitch
    local topWarning = Instance.new("TextLabel")
    topWarning.Size = UDim2.new(1, 0, 0.18, 0)
    topWarning.Position = UDim2.new(0, 0, 0.02, 0)
    topWarning.BackgroundTransparency = 1
    topWarning.Text = "☠️💀 SYSTEM COMPROMISED 💀☠️"
    topWarning.TextColor3 = Color3.fromRGB(255, 0, 0)
    topWarning.TextScaled = true
    topWarning.Font = Enum.Font.GothamBold
    topWarning.TextStrokeTransparency = 0
    topWarning.TextStrokeColor3 = Color3.fromRGB(0, 0, 0)
    topWarning.Parent = warningFrame
    
    task.spawn(function()
        local texts = {
            "☠️💀 SYSTEM COMPROMISED 💀☠️",
            "☠️💀 ACCESS DENIED 💀☠️",
            "☠️💀 FATAL ERROR 💀☠️",
            "☠️💀 NO ESCAPE 💀☠️"
        }
        while true do
            topWarning.Text = texts[math.random(1, #texts)]
            topWarning.Rotation = math.random(-3, 3)
            task.wait(0.3)
        end
    end)
    
    -- Main blacklist text with extreme effects
    local textLabel = Instance.new("TextLabel")
    textLabel.Name = "BlacklistText"
    textLabel.Size = UDim2.new(0.95, 0, 0.45, 0)
    textLabel.Position = UDim2.new(0.5, 0, 0.5, 0)
    textLabel.AnchorPoint = Vector2.new(0.5, 0.5)
    textLabel.BackgroundTransparency = 1
    textLabel.Text = "🚨 YOU ARE BLACKLISTED FROM AKADMIN 🚨"
    textLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
    textLabel.TextScaled = true
    textLabel.Font = Enum.Font.GothamBold
    textLabel.TextStrokeTransparency = 0
    textLabel.TextStrokeColor3 = Color3.fromRGB(255, 0, 0)
    textLabel.Parent = warningFrame
    
    -- Extreme text glitch effect
    task.spawn(function()
        local colors = {
            Color3.fromRGB(255, 255, 255),
            Color3.fromRGB(255, 0, 0),
            Color3.fromRGB(0, 0, 0),
            Color3.fromRGB(255, 0, 255)
        }
        while true do
            textLabel.TextColor3 = colors[math.random(1, #colors)]
            textLabel.Rotation = math.random(-2, 2)
            textLabel.Size = UDim2.new(0.95 + math.random(-5, 5) / 100, 0, 0.45, 0)
            task.wait(0.05)
        end
    end)
    
    -- Bottom countdown with intense styling
    local countdown = Instance.new("TextLabel")
    countdown.Size = UDim2.new(1, 0, 0.18, 0)
    countdown.Position = UDim2.new(0, 0, 0.8, 0)
    countdown.BackgroundTransparency = 1
    countdown.Text = "⚠️⚡ TERMINATING IN 10 ⚡⚠️"
    countdown.TextColor3 = Color3.fromRGB(255, 255, 0)
    countdown.TextScaled = true
    countdown.Font = Enum.Font.GothamBold
    countdown.TextStrokeTransparency = 0
    countdown.TextStrokeColor3 = Color3.fromRGB(255, 0, 0)
    countdown.Parent = warningFrame
    
    -- Countdown timer with effects
    task.spawn(function()
        for i = 10, 1, -1 do
            countdown.Text = "⚠️⚡ TERMINATING IN " .. i .. " ⚡⚠️"
            countdown.TextColor3 = i <= 3 and Color3.fromRGB(255, 0, 0) or Color3.fromRGB(255, 255, 0)
            task.wait(1)
        end
        countdown.Text = "💀 GAME OVER 💀"
        countdown.TextColor3 = Color3.fromRGB(255, 0, 0)
    end)
    
    -- Error messages flying across screen
    task.spawn(function()
        local errorMessages = {
            "ERROR: ACCESS DENIED",
            "FATAL: BLACKLIST DETECTED",
            "WARNING: UNAUTHORIZED USER",
            "CRITICAL: SYSTEM FAILURE",
            "ALERT: HWID BANNED"
        }
        while true do
            local errorText = Instance.new("TextLabel")
            errorText.Size = UDim2.new(0.4, 0, 0.05, 0)
            errorText.Position = UDim2.new(-0.5, 0, math.random(10, 90) / 100, 0)
            errorText.BackgroundTransparency = 1
            errorText.Text = errorMessages[math.random(1, #errorMessages)]
            errorText.TextColor3 = Color3.fromRGB(255, 0, 0)
            errorText.TextScaled = true
            errorText.Font = Enum.Font.Code
            errorText.TextTransparency = 0.3
            errorText.Parent = background
            errorText:TweenPosition(UDim2.new(1.5, 0, errorText.Position.Y.Scale, 0), "Out", "Linear", 2, false)
            task.delay(2, function() errorText:Destroy() end)
            task.wait(0.3)
        end
    end)
    
    -- Play alert sound (looped)
    local sound = Instance.new("Sound")
    sound.SoundId = "rbxasset://sounds/electronicpingshort.wav"
    sound.Volume = 10
    sound.Looped = true
    sound.Parent = screenGui
    sound:Play()
    
    -- Additional distorted sound
    local sound2 = Instance.new("Sound")
    sound2.SoundId = "rbxasset://sounds/button.wav"
    sound2.Volume = 8
    sound2.PlaybackSpeed = 0.3
    sound2.Looped = true
    sound2.Parent = screenGui
    sound2:Play()
    
    -- Crash after 10 seconds
    task.wait(10)
    
    -- Crash the game by creating infinite loop
    while true do
        Instance.new("Part", workspace)
    end
end

-- Main execution
local function main()
    local hwid = getHwid()
    
    if isBlacklisted(hwid) then
        showBlacklistScreen()
    else
        print("✅ HWID Check Passed - Not Blacklisted")
    end
end

-- Execute the script
main()
