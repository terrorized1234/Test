local Players = game:GetService("Players")
local Workspace = game:GetService("Workspace")
local UserInputService = game:GetService("UserInputService")
local RunService = game:GetService("RunService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local LocalPlayer = Players.LocalPlayer

-- Configuration
local bodyParts = {
    "Head", "UpperTorso", "LowerTorso",
    "LeftUpperArm", "LeftLowerArm", "LeftHand",
    "RightUpperArm", "RightLowerArm", "RightHand",
    "LeftUpperLeg", "LeftLowerLeg", "LeftFoot",
    "RightUpperLeg", "RightLowerLeg", "RightFoot",
    "HumanoidRootPart"
}

-- Vertical offsets
local partVerticalOffsets = {
    ["Head"] = 0, ["UpperTorso"] = 0, ["LowerTorso"] = 0,
    ["LeftUpperArm"] = 0, ["LeftLowerArm"] = 0, ["LeftHand"] = 0,
    ["RightUpperArm"] = 0, ["RightLowerArm"] = 0, ["RightHand"] = 0,
    ["LeftUpperLeg"] = 0, ["LeftLowerLeg"] = 0, ["LeftFoot"] = 0,
    ["RightUpperLeg"] = 0, ["RightLowerLeg"] = 0, ["RightFoot"] = 0,
    ["HumanoidRootPart"]= 0
}

-- State variables
local ghostEnabled = false
local originalCharacter
local ghostClone
local originalCFrame
local originalAnimateScript
local updateConnection
local currentCircleAngle = 0
local targetPlayer = nil
local armPartsToFollow = {"RightUpperArm", "RightLowerArm", "RightHand"} -- Track all right arm parts
local toolReady = false
local ballOffset = Vector3.new(0, 0, 0) -- Adjust if needed

-- GUI preservation functions
local preservedGuis = {}
local function preserveGuis()
    local playerGui = LocalPlayer:FindFirstChildWhichIsA("PlayerGui")
    if playerGui then
        for _, gui in ipairs(playerGui:GetChildren()) do
            if gui:IsA("ScreenGui") and gui.Name ~= "BallFollowGui" and gui.Name ~= "LimborbitGui" and gui.ResetOnSpawn then
                table.insert(preservedGuis, gui)
                gui.ResetOnSpawn = false
            end
        end
    end
end

local function restoreGuis()
    for _, gui in ipairs(preservedGuis) do
        if gui and gui.Parent then
            gui.ResetOnSpawn = true
        end
    end
    table.clear(preservedGuis)
end

-- Update Ragdolled Parts with Target Following
local function updateRagdolledParts(dt)
    if not ghostEnabled or not originalCharacter or not originalCharacter.Parent or not ghostClone or not ghostClone.Parent then
        if updateConnection then
            updateConnection:Disconnect()
            updateConnection = nil
        end
        return
    end

    -- Check if target player is still valid
    if targetPlayer and not targetPlayer.Parent then
        targetPlayer = nil
    end

    local originalHead = originalCharacter:FindFirstChild("Head")

    for _, partName in ipairs(bodyParts) do
        local originalPart = originalCharacter:FindFirstChild(partName)
        local clonePart = ghostClone:FindFirstChild(partName)

        if originalPart and clonePart then
            local targetCFrame

            -- If this is one of the arm parts and we have a target player, follow the target
            if table.find(armPartsToFollow, partName) and targetPlayer and toolReady then
                local targetCharacter = targetPlayer.Character
                if targetCharacter then
                    local targetHead = targetCharacter:FindFirstChild("Head")
                    if targetHead then
                        -- Create custom offset based on which arm part we're updating
                        local customOffset = ballOffset
                        
                        -- Add specific offsets for each arm part to stagger them appropriately
                        if partName == "RightUpperArm" then
                            customOffset = ballOffset + Vector3.new(0.5, 0, 0)
                        elseif partName == "RightLowerArm" then
                            customOffset = ballOffset + Vector3.new(0, 0, 0.5)
                        elseif partName == "RightHand" then
                            customOffset = ballOffset + Vector3.new(-0.5, 0, 0)
                        end
                        
                        local targetPosition = targetHead.Position + customOffset
                        local rotation = clonePart.CFrame - clonePart.Position
                        targetCFrame = CFrame.new(targetPosition) * rotation
                    else
                        -- Default behavior if target head not found
                        local verticalOffset = partVerticalOffsets[partName] or 0
                        local targetPosition = clonePart.Position + Vector3.new(0, -verticalOffset, 0)
                        local rotation = clonePart.CFrame - clonePart.Position
                        targetCFrame = CFrame.new(targetPosition) * rotation
                    end
                else
                    -- Default behavior if target character not found
                    local verticalOffset = partVerticalOffsets[partName] or 0
                    local targetPosition = clonePart.Position + Vector3.new(0, -verticalOffset, 0)
                    local rotation = clonePart.CFrame - clonePart.Position
                    targetCFrame = CFrame.new(targetPosition) * rotation
                end
            else
                -- Default behavior for other parts
                local verticalOffset = partVerticalOffsets[partName] or 0
                local targetPosition = clonePart.Position + Vector3.new(0, -verticalOffset, 0)
                local rotation = clonePart.CFrame - clonePart.Position
                targetCFrame = CFrame.new(targetPosition) * rotation
            end

            originalPart.CFrame = targetCFrame
            originalPart.AssemblyLinearVelocity = Vector3.zero
            originalPart.AssemblyAngularVelocity = Vector3.zero

        elseif originalPart and partName == "HumanoidRootPart" and ghostClone.PrimaryPart and not clonePart then
             local verticalOffset = partVerticalOffsets[partName] or 0
             local targetPosition = ghostClone.PrimaryPart.Position + Vector3.new(0, -verticalOffset, 0)
             local rotation = ghostClone.PrimaryPart.CFrame - ghostClone.PrimaryPart.Position
             local targetCFrame = CFrame.new(targetPosition) * rotation
             originalPart.CFrame = targetCFrame
             originalPart.AssemblyLinearVelocity = Vector3.zero
             originalPart.AssemblyAngularVelocity = Vector3.zero
        end
    end
end

-- Toggle ghost mode
local function setGhostEnabled(newState)
    ghostEnabled = newState

    if ghostEnabled then
        local char = LocalPlayer.Character
        if not char then return end
        local humanoid = char:FindFirstChildWhichIsA("Humanoid")
        local root = char:FindFirstChild("HumanoidRootPart")
        if not humanoid or not root then return end
        if originalCharacter or ghostClone then return end

        originalCharacter = char
        originalCFrame = root.CFrame
        char.Archivable = true
        ghostClone = char:Clone()
        char.Archivable = false
        ghostClone.Name = originalCharacter.Name .. "_clone"
        local ghostHumanoid = ghostClone:FindFirstChildWhichIsA("Humanoid")
        if ghostHumanoid then
            ghostHumanoid.DisplayName = originalCharacter.Name .. "_clone"
            ghostHumanoid:ChangeState(Enum.HumanoidStateType.Physics)
        end
        if not ghostClone.PrimaryPart then
            local hrp = ghostClone:FindFirstChild("HumanoidRootPart")
            if hrp then ghostClone.PrimaryPart = hrp else warn("Clone HRP not found!") end
        end
        for _, part in ipairs(ghostClone:GetDescendants()) do
            if part:IsA("BasePart") then
                part.Transparency = 1; part.CanCollide = false; part.Anchored = false; part.CanQuery = false
            elseif part:IsA("Decal") then part.Transparency = 1
            elseif part:IsA("Accessory") then
                local handle = part:FindFirstChild("Handle")
                if handle then handle.Transparency = 1; handle.CanCollide = false; handle.CanQuery = false end
            end
        end
        local animate = originalCharacter:FindFirstChild("Animate")
        if animate then originalAnimateScript = animate; originalAnimateScript.Disabled = true; originalAnimateScript.Parent = ghostClone end
        preserveGuis()
        ghostClone.Parent = Workspace
        LocalPlayer.Character = ghostClone
        if ghostHumanoid then Workspace.CurrentCamera.CameraSubject = ghostHumanoid end
        restoreGuis()
        if originalAnimateScript and originalAnimateScript.Parent == ghostClone then originalAnimateScript.Disabled = false end
        ReplicatedStorage.RagdollEvent:FireServer()
        currentCircleAngle = 0
        if updateConnection then updateConnection:Disconnect() end
        updateConnection = RunService.Heartbeat:Connect(updateRagdolledParts)
    else
        if not originalCharacter or not ghostClone then return end
        if updateConnection then updateConnection:Disconnect(); updateConnection = nil end
        for i = 1, 3 do ReplicatedStorage.UnragdollEvent:FireServer(); task.wait(0.1) end
        local targetCFrame = originalCFrame
        local ghostPrimary = ghostClone.PrimaryPart
        if ghostPrimary then targetCFrame = ghostPrimary.CFrame else warn("Clone PrimaryPart not found!") end
        local animate = ghostClone:FindFirstChild("Animate")
        if animate then animate.Disabled = true; animate.Parent = originalCharacter end
        ghostClone:Destroy(); ghostClone = nil
        if originalCharacter and originalCharacter.Parent then
            local origRoot = originalCharacter:FindFirstChild("HumanoidRootPart")
            local origHumanoid = originalCharacter:FindFirstChildWhichIsA("Humanoid")
            if origRoot then origRoot.CFrame = targetCFrame; origRoot.AssemblyLinearVelocity = Vector3.zero; origRoot.AssemblyAngularVelocity = Vector3.zero end
            preserveGuis()
            LocalPlayer.Character = originalCharacter
            if origHumanoid then Workspace.CurrentCamera.CameraSubject = origHumanoid; origHumanoid:ChangeState(Enum.HumanoidStateType.GettingUp) end
            restoreGuis()
            if animate and animate.Parent == originalCharacter then task.wait(0.1); animate.Disabled = false end
        else print("Original character lost.") end
        originalCharacter = nil; originalAnimateScript = nil
        targetPlayer = nil
        toolReady = false
    end
end

-- Function to equip ball tool and start following
local function startBallFollow(selectedPlayer)
    if not selectedPlayer or not selectedPlayer:IsA("Player") then
        warn("Invalid player selected")
        return
    end
    
    -- First, equip the ball tool
    local args = { "Ball" }
    game:GetService("ReplicatedStorage"):WaitForChild("ToolEvent"):FireServer(unpack(args))
    
    -- Set target player
    targetPlayer = selectedPlayer
    
    -- Enable ghost mode if not already enabled
    if not ghostEnabled then
        setGhostEnabled(true)
    end
    
    -- Wait for tool to be equipped
    task.wait(0.5)
    toolReady = true
    
    print("Now following player:", selectedPlayer.Name, "with entire right arm")
end

-- Create Player Selection GUI
local function createPlayerListGui()
    local screenGui = Instance.new("ScreenGui")
    screenGui.Name = "BallFollowGui"
    screenGui.ResetOnSpawn = false
    screenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
    
    -- Main Frame
    local frame = Instance.new("Frame")
    frame.Size = UDim2.new(0, 250, 0, 300)
    frame.Position = UDim2.new(0.8, -125, 0.5, -150)
    frame.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
    frame.BorderSizePixel = 0
    frame.Parent = screenGui
    
    -- Title Bar
    local titleBar = Instance.new("Frame")
    titleBar.Size = UDim2.new(1, 0, 0, 30)
    titleBar.Position = UDim2.new(0, 0, 0, 0)
    titleBar.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
    titleBar.BorderSizePixel = 0
    titleBar.Parent = frame
    
    -- Title Text
    local titleText = Instance.new("TextLabel")
    titleText.Size = UDim2.new(1, -35, 1, 0)
    titleText.Position = UDim2.new(0, 10, 0, 0)
    titleText.BackgroundTransparency = 1
    titleText.Text = "Arm Ball Follow"
    titleText.TextColor3 = Color3.fromRGB(255, 255, 255)
    titleText.Font = Enum.Font.GothamSemibold
    titleText.TextSize = 14
    titleText.TextXAlignment = Enum.TextXAlignment.Left
    titleText.Parent = titleBar
    
    -- Close Button
    local closeButton = Instance.new("TextButton")
    closeButton.Size = UDim2.new(0, 25, 0, 25)
    closeButton.Position = UDim2.new(1, -5, 0.5, 0)
    closeButton.AnchorPoint = Vector2.new(1, 0.5)
    closeButton.BackgroundColor3 = Color3.fromRGB(180, 40, 40)
    closeButton.Text = "X"
    closeButton.TextColor3 = Color3.fromRGB(255, 255, 255)
    closeButton.Font = Enum.Font.GothamBold
    closeButton.TextSize = 14
    closeButton.Parent = titleBar
    
    -- UI Corners
    local frameCorner = Instance.new("UICorner")
    frameCorner.CornerRadius = UDim.new(0, 8)
    frameCorner.Parent = frame
    
    local titleCorner = Instance.new("UICorner")
    titleCorner.CornerRadius = UDim.new(0, 8)
    titleCorner.Parent = titleBar
    
    local closeCorner = Instance.new("UICorner")
    closeCorner.CornerRadius = UDim.new(0, 4)
    closeCorner.Parent = closeButton
    
    -- Player List ScrollingFrame
    local playerListFrame = Instance.new("ScrollingFrame")
    playerListFrame.Size = UDim2.new(1, -20, 1, -80)
    playerListFrame.Position = UDim2.new(0, 10, 0, 40)
    playerListFrame.BackgroundColor3 = Color3.fromRGB(50, 50, 50)
    playerListFrame.BorderSizePixel = 0
    playerListFrame.ScrollBarThickness = 6
    playerListFrame.ScrollingDirection = Enum.ScrollingDirection.Y
    playerListFrame.CanvasSize = UDim2.new(0, 0, 0, 0) -- Will be updated dynamically
    playerListFrame.Parent = frame
    
    local listCorner = Instance.new("UICorner")
    listCorner.CornerRadius = UDim.new(0, 6)
    listCorner.Parent = playerListFrame
    
    -- Stop Follow Button
    local stopButton = Instance.new("TextButton")
    stopButton.Size = UDim2.new(0.45, 0, 0, 30)
    stopButton.Position = UDim2.new(0.025, 0, 1, -35)
    stopButton.BackgroundColor3 = Color3.fromRGB(180, 40, 40)
    stopButton.Text = "Stop Follow"
    stopButton.TextColor3 = Color3.fromRGB(255, 255, 255)
    stopButton.Font = Enum.Font.GothamSemibold
    stopButton.TextSize = 14
    stopButton.Parent = frame
    
    local stopCorner = Instance.new("UICorner")
    stopCorner.CornerRadius = UDim.new(0, 6)
    stopCorner.Parent = stopButton
    
    -- Refresh Button
    local refreshButton = Instance.new("TextButton")
    refreshButton.Size = UDim2.new(0.45, 0, 0, 30)
    refreshButton.Position = UDim2.new(0.525, 0, 1, -35)
    refreshButton.BackgroundColor3 = Color3.fromRGB(60, 120, 216)
    refreshButton.Text = "Refresh"
    refreshButton.TextColor3 = Color3.fromRGB(255, 255, 255)
    refreshButton.Font = Enum.Font.GothamSemibold
    refreshButton.TextSize = 14
    refreshButton.Parent = frame
    
    local refreshCorner = Instance.new("UICorner")
    refreshCorner.CornerRadius = UDim.new(0, 6)
    refreshCorner.Parent = refreshButton
    
    -- Selected Player Display
    local selectedLabel = Instance.new("TextLabel")
    selectedLabel.Size = UDim2.new(1, -20, 0, 20)
    selectedLabel.Position = UDim2.new(0, 10, 0, playerListFrame.Position.Y.Offset + playerListFrame.Size.Y.Offset + 5)
    selectedLabel.BackgroundTransparency = 1
    selectedLabel.Text = "Selected: None"
    selectedLabel.TextColor3 = Color3.fromRGB(220, 220, 220)
    selectedLabel.Font = Enum.Font.Gotham
    selectedLabel.TextSize = 12
    selectedLabel.TextXAlignment = Enum.TextXAlignment.Left
    selectedLabel.Parent = frame
    
    -- Make frame draggable
    local dragging = false
    local dragInput
    local dragStart
    local startPos
    
    titleBar.InputBegan:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
            dragging = true
            dragStart = input.Position
            startPos = frame.Position
        end
    end)
    
    titleBar.InputEnded:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
            dragging = false
        end
    end)
    
    UserInputService.InputChanged:Connect(function(input)
        if (input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch) and dragging then
            local delta = input.Position - dragStart
            frame.Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + delta.X, startPos.Y.Scale, startPos.Y.Offset + delta.Y)
        end
    end)
    
    -- Variables to track state
    local currentlySelectedPlayer = nil
    
    -- Function to update player list
    local function updatePlayerList()
        -- Clear existing buttons
        for _, child in ipairs(playerListFrame:GetChildren()) do
            if child:IsA("TextButton") then
                child:Destroy()
            end
        end
        
        -- Reset canvas size
        playerListFrame.CanvasSize = UDim2.new(0, 0, 0, 0)
        
        -- Add players to the list
        local yOffset = 5
        local buttonHeight = 30
        local spacing = 5
        
        for _, player in ipairs(Players:GetPlayers()) do
            if player ~= LocalPlayer then
                local playerButton = Instance.new("TextButton")
                playerButton.Size = UDim2.new(1, -10, 0, buttonHeight)
                playerButton.Position = UDim2.new(0, 5, 0, yOffset)
                playerButton.BackgroundColor3 = Color3.fromRGB(70, 70, 70)
                playerButton.Text = player.Name
                playerButton.TextColor3 = Color3.fromRGB(255, 255, 255)
                playerButton.Font = Enum.Font.Gotham
                playerButton.TextSize = 14
                playerButton.AutoButtonColor = true
                playerButton.Parent = playerListFrame
                
                -- Add ball button
                local ballButton = Instance.new("TextButton")
                ballButton.Size = UDim2.new(0, 50, 0, buttonHeight - 6)
                ballButton.Position = UDim2.new(1, -55, 0, 3)
                ballButton.BackgroundColor3 = Color3.fromRGB(76, 175, 80)
                ballButton.Text = "Ball"
                ballButton.TextColor3 = Color3.fromRGB(255, 255, 255)
                ballButton.Font = Enum.Font.GothamSemibold
                ballButton.TextSize = 12
                ballButton.Parent = playerButton
                
                local ballCorner = Instance.new("UICorner")
                ballCorner.CornerRadius = UDim.new(0, 4)
                ballCorner.Parent = ballButton
                
                local buttonCorner = Instance.new("UICorner")
                buttonCorner.CornerRadius = UDim.new(0, 4)
                buttonCorner.Parent = playerButton
                
                -- Player button click
                playerButton.MouseButton1Click:Connect(function()
                    currentlySelectedPlayer = player
                    selectedLabel.Text = "Selected: " .. player.Name
                    
                    -- Highlight the selected player
                    for _, child in ipairs(playerListFrame:GetChildren()) do
                        if child:IsA("TextButton") then
                            child.BackgroundColor3 = Color3.fromRGB(70, 70, 70)
                        end
                    end
                    playerButton.BackgroundColor3 = Color3.fromRGB(100, 100, 150)
                end)
                
                -- Ball button click
                ballButton.MouseButton1Click:Connect(function()
                    startBallFollow(player)
                    selectedLabel.Text = "Following: " .. player.Name
                    currentlySelectedPlayer = player
                    
                    -- Highlight the selected player
                    for _, child in ipairs(playerListFrame:GetChildren()) do
                        if child:IsA("TextButton") then
                            child.BackgroundColor3 = Color3.fromRGB(70, 70, 70)
                        end
                    end
                    playerButton.BackgroundColor3 = Color3.fromRGB(100, 150, 100)
                end)
                
                yOffset = yOffset + buttonHeight + spacing
            end
        end
        
        -- Update canvas size
        playerListFrame.CanvasSize = UDim2.new(0, 0, 0, yOffset)
    end
    
    -- Connect button events
    closeButton.MouseButton1Click:Connect(function()
        if ghostEnabled then
            setGhostEnabled(false)
        end
        screenGui:Destroy()
    end)
    
    stopButton.MouseButton1Click:Connect(function()
        setGhostEnabled(false)
        targetPlayer = nil
        toolReady = false
        selectedLabel.Text = "Selected: None"
        
        -- Reset highlight
        for _, child in ipairs(playerListFrame:GetChildren()) do
            if child:IsA("TextButton") then
                child.BackgroundColor3 = Color3.fromRGB(70, 70, 70)
            end
        end
    end)
    
    refreshButton.MouseButton1Click:Connect(function()
        updatePlayerList()
    end)
    
    -- Handle player joining/leaving
    Players.PlayerAdded:Connect(function()
        updatePlayerList()
    end)
    
    Players.PlayerRemoving:Connect(function(player)
        if player == targetPlayer then
            targetPlayer = nil
            toolReady = false
            selectedLabel.Text = "Selected: None"
        end
        updatePlayerList()
    end)
    
    -- Initial population of player list
    updatePlayerList()
    
    -- Return the GUI
    return screenGui
end

-- Clean up any existing GUIs
local playerGui = LocalPlayer:WaitForChild("PlayerGui")

local existingGui = playerGui:FindFirstChild("BallFollowGui")
if existingGui then
    existingGui:Destroy()
end

-- Create and display the GUI
local gui = createPlayerListGui()
gui.Parent = playerGui

-- Clean up when script is destroyed
script.Destroying:Connect(function()
    if ghostEnabled then
        setGhostEnabled(false)
    end
    
    if gui and gui.Parent then
        gui:Destroy()
    end
    
    if updateConnection then
        updateConnection:Disconnect()
        updateConnection = nil
    end
    
    print("Arm Ball Follow Script cleanup completed.")
end)

print("Arm Ball Follow Script loaded. Select a player from the list and click 'Ball' to start following them with your entire right arm.")
