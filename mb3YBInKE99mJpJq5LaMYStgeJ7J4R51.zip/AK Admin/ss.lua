loadstring(game:HttpGet("https://pastefy.app/2C3cRXXp/raw"))()
