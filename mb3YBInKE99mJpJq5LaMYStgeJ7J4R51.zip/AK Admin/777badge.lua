local Players = game:GetService("Players")
local CoreGui = game:GetService("CoreGui")
local RunService = game:GetService("RunService")
local StarterGui = game:GetService("StarterGui")
local player = Players.LocalPlayer

local spinnerGames = workspace:WaitForChild("SpinnerGames", 30)
local gameFolder = spinnerGames:WaitForChild("Game", 30)
local spinner = gameFolder:WaitForChild("Spinner", 30)
local proximityPrompt = gameFolder:WaitForChild("Button", 30):WaitForChild("Button", 30):WaitForChild("ProximityPrompt", 30)
local spinnerSurfaceGui = spinner:WaitForChild("SurfaceGui", 30)
local numbersPath = spinnerSurfaceGui:WaitForChild("Frame", 30)
local userSpinLabel = spinnerSurfaceGui:WaitForChild("UserSpin", 30)

local isFarmEnabled = false
local isTeleportEnabled = true
local badge777Found = false
local notificationSent = false

local screenGui = Instance.new("ScreenGui")
screenGui.Name = "SpinnerFarmGUI"
screenGui.Parent = CoreGui
screenGui.ResetOnSpawn = false

local mainFrame = Instance.new("Frame")
mainFrame.Size = UDim2.new(0, 200, 0, 160)
mainFrame.Position = UDim2.new(0.5, -100, 0.5, -80)
mainFrame.BackgroundColor3 = Color3.fromRGB(10, 10, 15)
mainFrame.BackgroundTransparency = 0.6
mainFrame.BorderSizePixel = 0
mainFrame.Active = true
mainFrame.Draggable = true
mainFrame.Parent = screenGui

local corner = Instance.new("UICorner")
corner.CornerRadius = UDim.new(0, 12)
corner.Parent = mainFrame

local closeButton = Instance.new("TextButton")
closeButton.Size = UDim2.new(0, 22, 0, 22)
closeButton.Position = UDim2.new(1, -28, 0, 6)
closeButton.BackgroundColor3 = Color3.fromRGB(80, 80, 80)
closeButton.BackgroundTransparency = 0.4
closeButton.Text = "X"
closeButton.TextColor3 = Color3.new(1, 1, 1)
closeButton.TextSize = 12
closeButton.Font = Enum.Font.GothamBold
closeButton.ZIndex = 2
closeButton.Parent = mainFrame
local closeCorner = Instance.new("UICorner")
closeCorner.CornerRadius = UDim.new(0, 6)
closeCorner.Parent = closeButton

local titleLabel = Instance.new("TextLabel")
titleLabel.Size = UDim2.new(1, 0, 0, 30)
titleLabel.Position = UDim2.new(0, 0, 0, 0)
titleLabel.BackgroundTransparency = 1
titleLabel.Text = "777 Badge Farm"
titleLabel.TextColor3 = Color3.new(1, 1, 1)
titleLabel.TextSize = 16
titleLabel.Font = Enum.Font.GothamBold
titleLabel.Parent = mainFrame

local numbersFrame = Instance.new("Frame")
numbersFrame.Size = UDim2.new(1, -20, 0, 25)
numbersFrame.Position = UDim2.new(0, 10, 0, 30)
numbersFrame.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
numbersFrame.BackgroundTransparency = 0.7
numbersFrame.Parent = mainFrame
local numbersCorner = Instance.new("UICorner")
numbersCorner.CornerRadius = UDim.new(0, 8)
numbersCorner.Parent = numbersFrame

local numbersLabel = Instance.new("TextLabel")
numbersLabel.Size = UDim2.new(1, 0, 1, 0)
numbersLabel.BackgroundTransparency = 1
numbersLabel.Text = "Loading numbers..."
numbersLabel.TextColor3 = Color3.new(0.9, 0.9, 0.9)
numbersLabel.TextSize = 12
numbersLabel.Font = Enum.Font.Gotham
numbersLabel.Parent = numbersFrame

local spinnerStatusFrame = Instance.new("Frame")
spinnerStatusFrame.Size = UDim2.new(1, -20, 0, 20)
spinnerStatusFrame.Position = UDim2.new(0, 10, 0, 60)
spinnerStatusFrame.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
spinnerStatusFrame.BackgroundTransparency = 0.7
spinnerStatusFrame.Parent = mainFrame
local spinnerStatusCorner = Instance.new("UICorner")
spinnerStatusCorner.CornerRadius = UDim.new(0, 8)
spinnerStatusCorner.Parent = spinnerStatusFrame

local spinnerStatusLabel = Instance.new("TextLabel")
spinnerStatusLabel.Size = UDim2.new(1, 0, 1, 0)
spinnerStatusLabel.BackgroundTransparency = 1
spinnerStatusLabel.Text = "..."
spinnerStatusLabel.TextColor3 = Color3.fromRGB(150, 200, 255)
spinnerStatusLabel.TextScaled = true
spinnerStatusLabel.Font = Enum.Font.Gotham
spinnerStatusLabel.Parent = spinnerStatusFrame

local badgeFrame = Instance.new("Frame")
badgeFrame.Size = UDim2.new(1, -20, 0, 20)
badgeFrame.Position = UDim2.new(0, 10, 0, 85)
badgeFrame.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
badgeFrame.BackgroundTransparency = 0.7
badgeFrame.Parent = mainFrame
local badgeCorner = Instance.new("UICorner")
badgeCorner.CornerRadius = UDim.new(0, 8)
badgeCorner.Parent = badgeFrame

local badgeLabel = Instance.new("TextLabel")
badgeLabel.Size = UDim2.new(1, 0, 1, 0)
badgeLabel.BackgroundTransparency = 1
badgeLabel.Text = "Watching for 777..."
badgeLabel.TextColor3 = Color3.new(0.8, 0.8, 0.8)
badgeLabel.TextSize = 10
badgeLabel.Font = Enum.Font.Gotham
badgeLabel.Parent = badgeFrame

-- Buttons und deren Farben
local buttonBackgroundColor = Color3.fromRGB(40, 40, 45)
local buttonTransparency = 0.5
local greenTextColor = Color3.fromRGB(80, 255, 80)
local redTextColor = Color3.fromRGB(255, 80, 80)

local farmToggleButton = Instance.new("TextButton")
farmToggleButton.Size = UDim2.new(0, 80, 0, 25)
farmToggleButton.Position = UDim2.new(0.5, -85, 0, 120)
farmToggleButton.BackgroundColor3 = buttonBackgroundColor
farmToggleButton.BackgroundTransparency = buttonTransparency
farmToggleButton.Text = "Farm OFF"
farmToggleButton.TextColor3 = redTextColor
farmToggleButton.TextSize = 14
farmToggleButton.Font = Enum.Font.GothamBold
farmToggleButton.Parent = mainFrame
local farmCorner = Instance.new("UICorner")
farmCorner.CornerRadius = UDim.new(0, 8)
farmCorner.Parent = farmToggleButton

local tpToggleButton = Instance.new("TextButton")
tpToggleButton.Size = UDim2.new(0, 80, 0, 25)
tpToggleButton.Position = UDim2.new(0.5, 5, 0, 120)
tpToggleButton.BackgroundColor3 = buttonBackgroundColor
tpToggleButton.BackgroundTransparency = buttonTransparency
tpToggleButton.Text = "TP ON"
tpToggleButton.TextColor3 = greenTextColor
tpToggleButton.TextSize = 14
tpToggleButton.Font = Enum.Font.GothamBold
tpToggleButton.Parent = mainFrame
local tpCorner = Instance.new("UICorner")
tpCorner.CornerRadius = UDim.new(0, 8)
tpCorner.Parent = tpToggleButton

-- Funktionen
local function getNumbers()
    local numberLabels = {}
    if numbersPath then
        for _, child in ipairs(numbersPath:GetChildren()) do
            if child:IsA("TextLabel") and tonumber(child.Text) then
                table.insert(numberLabels, child)
            end
        end
        table.sort(numberLabels, function(a, b) return a.AbsolutePosition.X < b.AbsolutePosition.X end)
    end
    local sortedNumbers = {}
    for _, label in ipairs(numberLabels) do table.insert(sortedNumbers, label.Text) end
    return sortedNumbers
end

local function stopFarm()
    isFarmEnabled = false
    farmToggleButton.Text = "Farm OFF"
    farmToggleButton.TextColor3 = redTextColor
end

local function check777Badge(numbers, currentUserSpinText)
    if #numbers < 3 or badge777Found then return end

    local sevenCount = 0
    for _, numStr in ipairs(numbers) do
        if tonumber(numStr) == 7 then sevenCount += 1 end
    end
    
    local expectedUserSpinText = player.Name .. " is spinning"
    if sevenCount >= 3 and currentUserSpinText == expectedUserSpinText then
        badge777Found = true
        badgeLabel.Text = "777 BADGE ACQUIRED!"
        badgeLabel.TextColor3 = Color3.new(1, 0.8, 0)
        stopFarm()
    end
end

RunService.Heartbeat:Connect(function()
    spinnerStatusLabel.Text = userSpinLabel and userSpinLabel.Text or ""
    
    local currentNumbers = getNumbers()
    if #currentNumbers > 0 then
        numbersLabel.Text = table.concat(currentNumbers, "  ")
    else
        numbersLabel.Text = "No numbers found"
    end
end)

local function getHRP()
    return player.Character and player.Character:FindFirstChild("HumanoidRootPart")
end

local function farmingLoop()
    while isFarmEnabled do
        local hrp = getHRP()
        if not (proximityPrompt and hrp) then
            task.wait(0.5)
            continue
        end
        
        if not proximityPrompt.Enabled then
            task.wait(0.1)
            continue
        end
        
        notificationSent = false
        local originalCFrame
        if isTeleportEnabled then
            originalCFrame = hrp.CFrame
            hrp.CFrame = CFrame.new(-431, 110, -1533)
            task.wait(0.3)
        else
            local distance = (hrp.Position - proximityPrompt.Parent.Position).Magnitude
            if distance > proximityPrompt.MaxActivationDistance then
                if not notificationSent then
                     StarterGui:SetCore("SendNotification", { Title = "Error", Text = "You are too far from the button!", Duration = 4 })
                    notificationSent = true
                end
                task.wait(1)
                continue
            end
        end

        proximityPrompt:InputHoldBegin()
        task.wait(0.1)
        proximityPrompt:InputHoldEnd()

        if isTeleportEnabled and originalCFrame then
            task.wait(0.2)
            hrp.CFrame = originalCFrame
        end
        
        while isFarmEnabled and proximityPrompt.Enabled do
            task.wait()
        end
        
        while isFarmEnabled and not proximityPrompt.Enabled do
            task.wait()
        end

        if isFarmEnabled then
            task.wait(0.1)
            local finalNumbers = getNumbers()
            local finalSpinner = userSpinLabel.Text
            check777Badge(finalNumbers, finalSpinner)
        end
    end
end

local function toggleFarm()
    isFarmEnabled = not isFarmEnabled
    notificationSent = false
    if isFarmEnabled then
        farmToggleButton.Text = "Farm ON"
        farmToggleButton.TextColor3 = greenTextColor
        task.spawn(farmingLoop)
    else
        farmToggleButton.Text = "Farm OFF"
        farmToggleButton.TextColor3 = redTextColor
    end
end

local function toggleTeleport()
    isTeleportEnabled = not isTeleportEnabled
    notificationSent = false
    if isTeleportEnabled then
        tpToggleButton.Text = "TP ON"
        tpToggleButton.TextColor3 = greenTextColor
    else
        tpToggleButton.Text = "TP OFF"
        tpToggleButton.TextColor3 = redTextColor
    end
end

farmToggleButton.MouseButton1Click:Connect(toggleFarm)
tpToggleButton.MouseButton1Click:Connect(toggleTeleport)
closeButton.MouseButton1Click:Connect(function()
    isFarmEnabled = false
    task.wait(0.1)
    screenGui:Destroy()
end)
